package com.viceboy.babble.ui.custom.behavior

import android.content.Context
import android.util.AttributeSet
import android.view.View
import android.widget.FrameLayout
import androidx.coordinatorlayout.widget.CoordinatorLayout
import androidx.core.view.ViewCompat
import com.google.android.material.bottomnavigation.BottomNavigationView

class CustomBottomNavBehavior :
    CoordinatorLayout.Behavior<BottomNavigationView> {

    constructor()
    constructor(context: Context, attrs: AttributeSet):super(context, attrs) {}

    override fun layoutDependsOn(
        parent: CoordinatorLayout,
        child: BottomNavigationView,
        dependency: View
    ): Boolean {
        return dependency is FrameLayout
    }

    override fun onStartNestedScroll(
        coordinatorLayout: CoordinatorLayout,
        child: BottomNavigationView,
        directTargetChild: View,
        target: View,
        axes: Int,
        type: Int
    ): Boolean {
        return axes == ViewCompat.SCROLL_AXIS_VERTICAL
    }

    override fun onNestedPreScroll(
        coordinatorLayout: CoordinatorLayout,
        child: BottomNavigationView,
        target: View,
        dx: Int,
        dy: Int,
        consumed: IntArray,
        type: Int
    ) {
        if (dy > 0)
            hideBottomNavigation(child)
        else if (dy < 0)
            showBottomNavigation(child)
    }

    private fun showBottomNavigation(child: BottomNavigationView) {
        child.animate().translationY(child.height.toFloat())
    }

    private fun hideBottomNavigation(child: BottomNavigationView) {
        child.animate().translationY(0f)
    }
}