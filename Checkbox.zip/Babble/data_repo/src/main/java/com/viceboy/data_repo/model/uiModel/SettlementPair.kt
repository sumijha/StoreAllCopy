package com.viceboy.data_repo.model.uiModel

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
data class SettlementPair(
    var id : Long,
    var fromUser : String,
    var toUser : String,
    var amount : Float
) : Parcelable