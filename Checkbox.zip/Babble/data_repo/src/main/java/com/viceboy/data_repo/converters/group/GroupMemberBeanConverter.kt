package com.viceboy.data_repo.converters.group

import com.viceboy.data_repo.converters.BaseDataConverterImpl
import com.viceboy.data_repo.model.dataModel.User
import com.viceboy.data_repo.model.uiModel.GroupMembers
import io.reactivex.BackpressureStrategy
import io.reactivex.Flowable
import javax.inject.Inject

interface GroupMemberBeanConverter {
    fun fromUserToGroupMember(
        user: User,
        currency: String?=null,
        symbol: String?=null,
        amount: Float?=0f
    ): GroupMembers
}

class GroupMemberBeanConverterImpl @Inject constructor(): BaseDataConverterImpl<User, GroupMembers>(),
    GroupMemberBeanConverter {
    override fun processConversionFromInToFlowableOut(inObject: User): Flowable<GroupMembers> =
        Flowable.create(
            {}, BackpressureStrategy.LATEST
        )

    override fun processConversionFromInToOut(inObject: User): GroupMembers {
        return GroupMembers(
            inObject.id,
            inObject.name,
            null,
            null,
            inObject.avatar_url,
            0f
        )
    }

    override fun fromUserToGroupMember(
        user: User,
        currency: String?,
        symbol: String?,
        amount: Float?
    ): GroupMembers {
        val member = processConversionFromInToOut(user)
        member.amountPaid = amount ?: 0f
        member.currency = currency
        member.currencySymbol = symbol
        return member
    }

}