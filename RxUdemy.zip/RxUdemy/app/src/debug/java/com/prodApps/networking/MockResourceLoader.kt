package com.prodApps.networking

import android.content.Context
import timber.log.Timber
import java.io.BufferedReader
import java.io.IOException
import java.io.InputStreamReader

class MockResourceLoader private constructor() {

    companion object {

        @JvmStatic
        fun getResponseString(
            context: Context,
            method: String,
            endpointParts: Array<String>
        ): String? {
            try {
                var currentPath = "mock"
                var mockList = context.assets.list(currentPath)

                for (endPoint in endpointParts) {
                    if (mockList!!.contains(endPoint)) {
                        currentPath = currentPath + "/" + endPoint
                        mockList = context.assets.list(currentPath)
                    }
                }

                //At this stage, our mock list will be the list of files in the matching directory
                //for the endpoint parts.
                var finalPath: String? = null
                for (path in mockList!!) {
                    if (path.contains(method.toLowerCase())) {
                        finalPath = currentPath + "/" + path
                        break
                    }
                }

                if (!finalPath.isNullOrEmpty()) {
                    return getResponseFromPath(context, finalPath)
                }
                return null
            } catch (e: IOException) {
                Timber.e("Error loading mock response from assets ")
                return null
            }
        }

        @JvmStatic
        private fun getResponseFromPath(context: Context, path: String): String {
            val sb = StringBuilder()
            try {
                val assetStream = context.assets.open(path)
                val reader = BufferedReader(InputStreamReader(assetStream))

                return reader.use {
                    it.readText()
                }
            } catch (e: IOException) {
                Timber.e(e, "Error Reading Mock Response")
            }
            return sb.toString()
        }
    }
}