package com.prodApps.networking

import com.prodApps.settings.DebugPreferences
import okhttp3.*
import javax.inject.Inject

/**
 * Implementiing Interceptor as it allows to manipulate a request before letting it to
 * proceed such as adding Authorization  Headers
 */
class MockInterceptor @Inject constructor(
    var mockResponseFactory: MockResponseFactory,
    var debugPreferences: DebugPreferences
) : Interceptor {

    override fun intercept(chain: Interceptor.Chain): Response {
        if (debugPreferences.useMockResponseEnabled()) {
            val mockResponse = mockResponseFactory.getMockResponse(chain.request())
            if (!mockResponse.isNullOrEmpty()) {
                return Response.Builder()
                    .message("")
                    .protocol(Protocol.HTTP_1_1)
                    .request(chain.request())
                    .code(200)
                    .body(ResponseBody.create(MediaType.parse("text/json"), mockResponse))
                    .build()
            }
        }
        return chain.proceed(chain.request())
    }

}