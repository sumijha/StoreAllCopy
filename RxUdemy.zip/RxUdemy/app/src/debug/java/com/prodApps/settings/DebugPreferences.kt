package com.prodApps.settings

import android.content.Context
import android.content.SharedPreferences
import javax.inject.Inject

class DebugPreferences @Inject constructor(var context: Context) {

    private var sharedPreferences: SharedPreferences =
        context.getSharedPreferences("debug_settings",Context.MODE_PRIVATE)

    private val MOCK_RESPONSE_KEY = "mock_response"

    fun useMockResponseEnabled():Boolean = sharedPreferences.getBoolean(MOCK_RESPONSE_KEY,false)

    fun setUserMockResponse(boolean: Boolean) = sharedPreferences.edit().putBoolean(MOCK_RESPONSE_KEY,boolean).apply()
}