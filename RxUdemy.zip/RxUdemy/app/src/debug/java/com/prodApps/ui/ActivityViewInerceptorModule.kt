package com.prodApps.ui

import dagger.Binds
import dagger.Module
import startupplan.srios.com.rxudemy.ui.ActivityViewInterceptor

@Module
abstract class ActivityViewInerceptorModule {

    @Binds
    abstract fun bindsActivityViewInterceptor(activityViewInterceptor: DebugActivityViewInterceptor): ActivityViewInterceptor
}