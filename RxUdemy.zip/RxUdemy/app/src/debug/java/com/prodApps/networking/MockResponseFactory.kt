package com.prodApps.networking

import android.content.Context
import okhttp3.Request
import javax.inject.Inject
import javax.inject.Named

class MockResponseFactory @Inject constructor(var context: Context,@Named("base_url")var baseUrl:String) {

    fun getMockResponse(request: Request): String? {
        val endpoints = getEndPoint(request).split("/")
        return MockResourceLoader.getResponseString(context,request.method(),endpoints.toTypedArray())
    }

    private fun getEndPoint(request: Request): String {
        val url = request.url().toString()
        val queryStart = url.indexOf("?")

        return if (queryStart == -1) {
            url.substring(baseUrl.length)
        } else url.substring(baseUrl.length, queryStart)
    }
}