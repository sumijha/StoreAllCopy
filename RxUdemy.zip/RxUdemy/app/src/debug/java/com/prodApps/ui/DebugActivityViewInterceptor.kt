package com.prodApps.ui

import android.app.Activity
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.Switch
import butterknife.ButterKnife
import butterknife.Unbinder
import com.jakewharton.rxbinding3.widget.checkedChanges
import com.prodApps.settings.DebugPreferences
import io.reactivex.disposables.CompositeDisposable
import startupplan.srios.com.rxudemy.R
import startupplan.srios.com.rxudemy.ui.ActivityViewInterceptor
import javax.inject.Inject

class DebugActivityViewInterceptor @Inject constructor(var debugPreferences: DebugPreferences) : ActivityViewInterceptor {

    private lateinit var mockResponseSwitch: Switch
    private lateinit var unbinder: Unbinder

    private val disposable = CompositeDisposable()

    override fun setContentView(activity: Activity, layoutRes: Int) {
        val debugLayout = LayoutInflater.from(activity).inflate(R.layout.debug_drawer, null)
        mockResponseSwitch = debugLayout.findViewById(R.id.sw_mock_responses)
        unbinder = ButterKnife.bind(this, debugLayout)
        initPrefs()

        val activityLayout = LayoutInflater.from(activity).inflate(layoutRes, null)
        debugLayout.findViewById<ViewGroup>(R.id.activity_layout_container).addView(activityLayout)
        activity.setContentView(debugLayout)
    }

    override fun clear() {
        super.clear()
        disposable.clear()
        unbinder.unbind()
    }

    private fun initPrefs() {
        if (debugPreferences.useMockResponseEnabled()) mockResponseSwitch.toggle()

        disposable.addAll(
            mockResponseSwitch.checkedChanges().subscribe {
                debugPreferences.setUserMockResponse(it)
            }
        )
    }
}