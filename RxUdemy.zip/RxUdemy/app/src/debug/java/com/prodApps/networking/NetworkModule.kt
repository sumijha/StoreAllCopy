package com.prodApps.networking

import dagger.Module
import dagger.Provides
import okhttp3.Call
import okhttp3.OkHttpClient
import javax.inject.Named
import javax.inject.Singleton

@Module
class NetworkModule {

    @Provides
    @Singleton
    fun providesOkHttp(mockInterceptor: MockInterceptor): Call.Factory =
        OkHttpClient.Builder().addInterceptor(mockInterceptor).build()

    @Provides
    @Named("base_url")
    @Singleton
    fun providesBaseUrl() = "https://api.github.com/"
}