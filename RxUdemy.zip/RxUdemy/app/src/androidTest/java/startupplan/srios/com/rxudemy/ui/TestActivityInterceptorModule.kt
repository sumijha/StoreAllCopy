package startupplan.srios.com.rxudemy.ui

import com.prodApps.ui.DebugActivityViewInterceptor
import dagger.Binds
import dagger.Module

@Module
abstract class TestActivityInterceptorModule {

    @Binds
    abstract fun bindsActivityViewInterceptor(activityViewInterceptor: DebugActivityViewInterceptor): ActivityViewInterceptor
}