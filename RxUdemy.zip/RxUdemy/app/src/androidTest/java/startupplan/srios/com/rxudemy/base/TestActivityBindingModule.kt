package startupplan.srios.com.rxudemy.base

import android.app.Activity
import dagger.Binds
import dagger.Module
import dagger.android.ActivityKey
import dagger.android.AndroidInjector
import dagger.multibindings.IntoMap
import startupplan.srios.com.rxudemy.home.MainActivity
import startupplan.srios.com.rxudemy.home.TestMainActivityComponent

/**
 * This is going to use TestMainActivity COmponent which we need to create
 */
@Module (subcomponents = [TestMainActivityComponent::class])
abstract class TestActivityBindingModule {

    @Binds
    @IntoMap
    @ActivityKey(MainActivity::class)
    abstract fun bindsMainActivityInjector(builder:TestMainActivityComponent.Builder):AndroidInjector.Factory<out Activity>
}