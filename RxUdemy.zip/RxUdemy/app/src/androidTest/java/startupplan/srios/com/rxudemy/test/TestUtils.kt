package startupplan.srios.com.rxudemy.test

import com.squareup.moshi.Moshi
import java.io.BufferedReader
import java.io.IOException
import java.io.InputStreamReader
import java.lang.reflect.Type
import javax.inject.Inject

class TestUtils @Inject constructor(var moshi: Moshi) {

    fun <T> loadJSON(path: String, type: Type): T {
        try {
            val json = getFileString(path)
            return moshi.adapter<T>(type).fromJson(path) as T
        } catch (e: IOException) {
            throw IllegalArgumentException("Could not Deserialize " + path + " into type " + type)
        }
    }

    fun <T> loadJSON(path: String, clazz: Class<T>): T {
        try {
            val json = getFileString(path)
            return moshi.adapter(clazz).fromJson(json) as T
        } catch (e: IOException) {
            throw IllegalArgumentException("Could not Deserialize " + path + " into class " + clazz)
        }
    }

    fun getFileString(path: String): String {
        try {
            val sb = StringBuilder()
            val reader = BufferedReader(
                InputStreamReader(
                    javaClass.classLoader.getResourceAsStream(path)
                )
            )
            return reader.use {
                it.readText()
            }
        } catch (e: IOException) {
            throw IllegalArgumentException("Could not read resource from path :" + path)
        }
    }
}