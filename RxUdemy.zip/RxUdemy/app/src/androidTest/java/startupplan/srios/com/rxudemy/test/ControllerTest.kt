package startupplan.srios.com.rxudemy.test

import android.content.Intent
import com.bluelinelabs.conductor.Controller
import org.junit.Rule
import startupplan.srios.com.rxudemy.home.MainActivity

abstract class ControllerTest {

    @get:Rule var testRule = ControllerTestRules(MainActivity::class.java)

    abstract fun controllerToLaunch(): Controller

    fun launch():Unit {
        testRule.launchActivity(null)
    }

    fun launch(intent:Intent) {
        testRule.launchActivity(intent)
    }

    init {
        testRule.screenNavigator.overrideInitialController(controllerToLaunch())
    }
}