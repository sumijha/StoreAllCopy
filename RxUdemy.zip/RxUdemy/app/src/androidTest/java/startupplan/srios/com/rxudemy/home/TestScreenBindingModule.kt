package startupplan.srios.com.rxudemy.home

import com.bluelinelabs.conductor.Controller
import dagger.Binds
import dagger.Module
import dagger.android.AndroidInjector
import dagger.multibindings.IntoMap
import startupplan.srios.com.rxudemy.diBase.ControllerKey
import startupplan.srios.com.rxudemy.ui.repoDetails.RepoDetailsComponent
import startupplan.srios.com.rxudemy.ui.repoDetails.RepoDetailsController
import startupplan.srios.com.rxudemy.ui.trending.TrendingRepoComponent

@Module (subcomponents = [TrendingRepoComponent::class,RepoDetailsComponent::class])
abstract class TestScreenBindingModule {

    @Binds
    @IntoMap
    @ControllerKey(TrendingRepoController::class)
    abstract fun provideMainScreenBindingModule(builder: TrendingRepoComponent.Builder): AndroidInjector.Factory<out Controller>

    @Binds
    @IntoMap
    @ControllerKey(RepoDetailsController::class)
    abstract fun bindsRepoDetailsInjector(builder: RepoDetailsComponent.Builder):AndroidInjector.Factory<out Controller>
}