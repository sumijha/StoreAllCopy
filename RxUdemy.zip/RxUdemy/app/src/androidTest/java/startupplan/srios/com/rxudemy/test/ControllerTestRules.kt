package startupplan.srios.com.rxudemy.test

import android.app.Activity
import androidx.test.rule.ActivityTestRule
import startupplan.srios.com.rxudemy.base.TestApplication
import startupplan.srios.com.rxudemy.data.RepoRepository
import startupplan.srios.com.rxudemy.data.TestRepoService
import startupplan.srios.com.rxudemy.ui.TestScreenNavigator

class ControllerTestRules<T : Activity>(var activityClass: Class<T>) :
    ActivityTestRule<T>(activityClass, true, false) {

     val screenNavigator: TestScreenNavigator =
        TestApplication.getAppComponent().screenNavigator()
     val repoService: TestRepoService = TestApplication.getAppComponent().repoService()
     val repoRepository: RepoRepository = TestApplication.getAppComponent().repoRepository()

    fun clearState() {
        repoService.clearErrorFlag()
        repoService.clearHoldFlag()
        repoRepository.clearCache()
    }

}