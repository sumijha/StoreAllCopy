package startupplan.srios.com.rxudemy.ui

import androidx.appcompat.app.AppCompatActivity
import com.bluelinelabs.conductor.Controller
import com.bluelinelabs.conductor.Router
import startupplan.srios.com.rxudemy.diBase.BaseActivity
import startupplan.srios.com.rxudemy.lifecycle.ActivityLifecycleTask
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class TestScreenNavigator @Inject constructor() :
    ScreenNavigator, ActivityLifecycleTask() {

    private val defaultScreenNavigator = DefaultScreenNavigator()
    private var overrideController: Controller? = null

    /**
     * Set the Controller to launch when the activity attaches to ScreenNavigator. This will be used
     * instead instead of the Controller passed to {@Link ScreenNavigator::initWithRouter(Router,Controller)}
     */
    fun overrideInitialController(controller: Controller) {
        overrideController = controller
    }


    override fun onCreate(activity: AppCompatActivity) {
        super.onCreate(activity)
        require(activity is BaseActivity) {"Instance should be a BaseActivity instance"}
        initRouter(activity.getRouter(),activity.initialScreen())
    }

    private fun initRouter(router: Router, controller: Controller) =
        defaultScreenNavigator.initRouter(router, overrideController ?: controller)

    override fun pop(): Boolean = defaultScreenNavigator.pop()

    override fun goToRepoDetails(repoOwner: String, repoName: String) =
        defaultScreenNavigator.goToRepoDetails(repoOwner, repoName)

    override fun onDestroy(activity: AppCompatActivity) {
        super.onDestroy(activity)
        defaultScreenNavigator.onDestroy(activity)
    }
}