package startupplan.srios.com.rxudemy.details

import android.os.SystemClock
import androidx.test.espresso.matcher.ViewMatchers
import com.bluelinelabs.conductor.Controller
import org.junit.Before
import org.junit.Test
import startupplan.srios.com.rxudemy.R
import startupplan.srios.com.rxudemy.test.ControllerTest
import startupplan.srios.com.rxudemy.ui.repoDetails.RepoDetailsController

class RepoDetailsControllerTest : ControllerTest() {

    @Before
    fun setUp() = testRule.clearState()

    override fun controllerToLaunch(): Controller {
        return RepoDetailsController.newInstance("ReactiveX", "RxJava")
    }

    @Test
    fun repoDetailSuccess() {
        launch()
        RepoDetailsRobot.init()
            .verifyLoadingVisibility(ViewMatchers.Visibility.GONE)
            .verifyName("RxJava")
            .verifyDescription("RxJava – Reactive Extensions for the JVM – a library for composing asynchronous and event-based programs using observable sequences for the Java VM.")
            .verifyCreatedDate("Jan 08,2013")
            .verifyUpdatedDate("Oct 06,2017")
    }

    @Test
    fun repoDetailsError() {
        testRule.repoService.setErrorFlags(testRule.repoService.FLAG_GET_REPO)
        launch()
        RepoDetailsRobot.init()
            .verifyLoadingVisibility(ViewMatchers.Visibility.GONE)
            .verifyContentVisibility(ViewMatchers.Visibility.GONE)
            .verifyErrorText(R.string.api_error_single_repo)
    }

    @Test
    fun contributorSuccess() {
        launch()
        SystemClock.sleep(2000)
        RepoDetailsRobot.init()
            .verifyContributorLoadingVisibility(ViewMatchers.Visibility.GONE)
            .verifyContributorErrorVisibility(ViewMatchers.Visibility.GONE)
            .verifyContributorShown("benjchristensen")
    }

    @Test
    fun contributorError() {
        testRule.repoService.setErrorFlags(testRule.repoService.FLAG_GET_CONTRIBUTORS)
        launch()
        RepoDetailsRobot.init()
            .verifyContributorLoadingVisibility(ViewMatchers.Visibility.GONE)
            .verifyContributorErrorText(R.string.api_error_contributors)
    }

    @Test
    fun repoSuccessContributorError() {
        testRule.repoService.setErrorFlags(testRule.repoService.FLAG_GET_CONTRIBUTORS)
        launch()
        RepoDetailsRobot.init()
            .verifyLoadingVisibility(ViewMatchers.Visibility.GONE)
            .verifyContributorLoadingVisibility(ViewMatchers.Visibility.GONE)
            .verifyContributorErrorText(R.string.api_error_contributors)
            .verifyErrorVisibility(ViewMatchers.Visibility.GONE)
    }

    @Test
    fun loadingRepo() {
        testRule.repoService.setHoldFlag(testRule.repoService.FLAG_GET_REPO)
        launch()
        RepoDetailsRobot.init()
            .verifyLoadingVisibility(ViewMatchers.Visibility.VISIBLE)
    }

    @Test
    fun loadingContributors() {
        testRule.repoService.setHoldFlag(testRule.repoService.FLAG_GET_CONTRIBUTORS)
        launch()
        RepoDetailsRobot.init()
            .verifyContributorLoadingVisibility(ViewMatchers.Visibility.VISIBLE)
    }
}