package startupplan.srios.com.rxudemy.base

import androidx.test.platform.app.InstrumentationRegistry
import startupplan.srios.com.rxudemy.diBase.AppComponent
import startupplan.srios.com.rxudemy.diBase.AppModule
import startupplan.srios.com.rxudemy.diBase.BaseApplication

/**
 * We need to provide different components in order to test diffenrt modules
 */
class TestApplication : BaseApplication() {

    private lateinit var testApplicationComponent: TestApplicationComponent

    override fun initComponent(): AppComponent {
        testApplicationComponent =  DaggerTestApplicationComponent.builder()
            .appModule(AppModule(this))
            .build()
        (InstrumentationRegistry.getInstrumentation().targetContext.applicationContext as BaseApplication).appComponent = testApplicationComponent
        return testApplicationComponent
    }

    companion object {
        fun getAppComponent(): TestApplicationComponent {
           return ((InstrumentationRegistry.getInstrumentation().targetContext.applicationContext as BaseApplication).appComponent) as TestApplicationComponent
        }
    }
}