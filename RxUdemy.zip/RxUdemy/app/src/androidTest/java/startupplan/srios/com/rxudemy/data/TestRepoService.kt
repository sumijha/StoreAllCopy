package startupplan.srios.com.rxudemy.data

import android.os.Handler
import android.os.Looper
import com.squareup.moshi.Types
import io.reactivex.Single
import startupplan.srios.com.rxudemy.model.Contributor
import startupplan.srios.com.rxudemy.model.Repo
import startupplan.srios.com.rxudemy.test.TestUtils
import java.io.IOException
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class TestRepoService @Inject constructor(var testUtils: TestUtils) : RepoService {

    val FLAG_TRENDING_REPOS = 1
    val FLAG_GET_REPO = 2
    val FLAG_GET_CONTRIBUTORS = 3

    private var errorFlag: Int? = null
    private var holdFlag: Int? = null


    /**
     * We are first checking if error flag is set or not and then we
     */
    override fun getContributors(url: String): Single<List<Contributor>> {
        if (errorFlag?.and(FLAG_GET_CONTRIBUTORS) ?: 1 == 0) {
            val response = testUtils.loadJSON<List<Contributor>>(
                "mock/repos/contributors/get_contributors.json",
                Types.newParameterizedType(List::class.java, Contributor::class.java)
            )
            if (holdFlag?.and(FLAG_GET_CONTRIBUTORS) ?: 0 == FLAG_GET_CONTRIBUTORS) {
                return holdingSingle(response, FLAG_GET_CONTRIBUTORS)
            }
            return Single.just(response)
        }
        return Single.error(IOException())
    }

    override fun getRepo(repoOwner: String, repoName: String): Single<Repo> {
        if (errorFlag?.and(FLAG_GET_REPO) ?: 1 == 0) {
            val response = testUtils.loadJSON(
                "mock/repos/get_repo.json",
                Repo::class.java
            )
            if (holdFlag?.and(FLAG_GET_REPO) ?: 0 == FLAG_GET_REPO) {
                return holdingSingle(response, FLAG_GET_REPO)
            }
            return Single.just(response)
        }
        return Single.error(IOException())
    }

    override fun getTrendingRepos(): Single<TrendingReposResponse> {
        if (errorFlag?.and(FLAG_TRENDING_REPOS) ?: 1 == 0) {
            val response = testUtils.loadJSON(
                "mock/search/get_trending_repos_response.json",
                TrendingReposResponse::class.java
            )
            if (holdFlag?.and(FLAG_TRENDING_REPOS) ?: 0 == FLAG_TRENDING_REPOS) {
                return holdingSingle(response, FLAG_TRENDING_REPOS)
            }
            return Single.just(response)
        }
        return Single.error(IOException())
    }

    fun setErrorFlags(errorFlags: Int) {
        errorFlag = errorFlags
    }

    fun clearErrorFlag() {
        errorFlag = 0
    }

    fun setHoldFlag(holdsFlag: Int) {
        holdFlag = holdsFlag
    }

    fun clearHoldFlag() {
        holdFlag = 0
    }

    private fun <T> holdingSingle(result: T, flag: Int): Single<T> {
        return Single.create {
            val handler = Handler(Looper.getMainLooper())
            val runnable = object : Runnable {
                override fun run() {
                    if ((holdFlag?.and(flag)) == flag) {
                        handler.postDelayed(this, 50)
                    } else {
                        it.onSuccess(result)
                    }
                }
            }
            runnable.run()
        }
    }


}