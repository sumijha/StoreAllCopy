package startupplan.srios.com.rxudemy.ui

import dagger.Binds
import dagger.Module
import dagger.multibindings.IntoSet
import startupplan.srios.com.rxudemy.lifecycle.ActivityLifecycleTask

@Module
abstract class TestNavigationModule {

    @Binds
    abstract fun bindScreenNavigator(navigator: TestScreenNavigator): ScreenNavigator

    //This will return an ActivityLifecycleTask, this will dagger to put this task into a set
    @Binds
    @IntoSet
    abstract fun bindScreenNavigatorTask(screenNavigator: TestScreenNavigator) : ActivityLifecycleTask
}