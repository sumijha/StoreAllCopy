package startupplan.srios.com.rxudemy.ui.trending

import android.os.SystemClock
import androidx.test.espresso.Espresso
import androidx.test.espresso.assertion.ViewAssertions.matches
import androidx.test.espresso.matcher.ViewMatchers
import androidx.test.espresso.matcher.ViewMatchers.withEffectiveVisibility
import androidx.test.runner.AndroidJUnit4
import com.bluelinelabs.conductor.Controller
import org.hamcrest.CoreMatchers.allOf
import org.junit.Test
import org.junit.runner.RunWith
import startupplan.srios.com.rxudemy.R
import startupplan.srios.com.rxudemy.test.ControllerTest


@RunWith(AndroidJUnit4::class)
class TrendingRepoControllerTest : ControllerTest() {

    override fun controllerToLaunch(): Controller = TrendingRepoController()

    /**
     *  Testing a Successfull API Call, we want a flag on API service to send an error or not
     */
    @Test
    fun loadRepos() {
        testRule.repoService.clearErrorFlag()
        testRule.repoService.setHoldFlag(testRule.repoService.FLAG_TRENDING_REPOS)
        launch()

        SystemClock.sleep(3000)
        // Validation Points
        //Checking if loading Indicator is gone on successfull API Call
        Espresso.onView(ViewMatchers.withId(R.id.loading_indicator))
            .check(matches(withEffectiveVisibility(ViewMatchers.Visibility.GONE)))

        //Checking if Error TV is not visible
        Espresso.onView(ViewMatchers.withId(R.id.tv_error))
            .check(matches(withEffectiveVisibility(ViewMatchers.Visibility.GONE)))

        //Checking if RecyclerView is  visible
        Espresso.onView(ViewMatchers.withId(R.id.repo_list))
            .check(matches(withEffectiveVisibility(ViewMatchers.Visibility.VISIBLE)))

        //We have muliple list items in recycler view tv_repo_name, so it will check if any if the item has text with RxJava who has Id (tv_repo_name)
        Espresso.onView(
            allOf(
                ViewMatchers.withId(R.id.tv_repo_name),
                ViewMatchers.withText("RxJava")
            )
        ).check(matches(withEffectiveVisibility(ViewMatchers.Visibility.VISIBLE)))
    }

    /**
     * Testing a ERROR Condition
     */
    @Test
    fun loadReposError() {
        testRule.repoService.setErrorFlags(testRule.repoService.FLAG_TRENDING_REPOS)
        launch()

        SystemClock.sleep(3000)

        Espresso.onView(ViewMatchers.withId(R.id.loading_indicator))
            .check(matches(withEffectiveVisibility(ViewMatchers.Visibility.GONE)))

        //Checking if RecyclerView is  not visible
        Espresso.onView(ViewMatchers.withId(R.id.repo_list))
            .check(matches(withEffectiveVisibility(ViewMatchers.Visibility.GONE)))


        //Checking if Error TV is not visible
        Espresso.onView(ViewMatchers.withId(R.id.tv_error))
            .check(matches(withEffectiveVisibility(ViewMatchers.Visibility.VISIBLE)))
    }
}