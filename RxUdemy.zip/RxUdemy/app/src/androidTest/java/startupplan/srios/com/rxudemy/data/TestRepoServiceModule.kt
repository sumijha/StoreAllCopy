package startupplan.srios.com.rxudemy.data

import dagger.Binds
import dagger.Module
import dagger.Provides
import io.reactivex.Scheduler
import io.reactivex.schedulers.Schedulers
import javax.inject.Named
import javax.inject.Singleton

@Module
abstract class TestRepoServiceModule {

    @Singleton
    @Binds
    abstract fun bindRepoService(repoService: TestRepoService): RepoService

    //Need to update in UI Test module
    //Trampoline : Task will be queued in main Thread
    @Module
    companion object {

        @JvmStatic
        @Provides
        @Named("network_scheduler")
        @Singleton
        fun provideNetworkScheduler(): Scheduler = Schedulers.trampoline()
    }

}