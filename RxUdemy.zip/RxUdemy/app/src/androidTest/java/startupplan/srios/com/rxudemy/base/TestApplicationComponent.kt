package startupplan.srios.com.rxudemy.base

import dagger.Component
import startupplan.srios.com.rxudemy.data.RepoRepository
import startupplan.srios.com.rxudemy.data.TestRepoService
import startupplan.srios.com.rxudemy.data.TestRepoServiceModule
import startupplan.srios.com.rxudemy.diBase.AppComponent
import startupplan.srios.com.rxudemy.diBase.AppModule
import startupplan.srios.com.rxudemy.network.ServiceModule
import startupplan.srios.com.rxudemy.ui.TestActivityInterceptorModule
import startupplan.srios.com.rxudemy.ui.TestNavigationModule
import startupplan.srios.com.rxudemy.ui.TestScreenNavigator
import startupplan.srios.com.rxudemy.ui.trending.TrendingRepoControllerTest
import javax.inject.Singleton

@Singleton
@Component(
    modules = [AppModule::class,
        TestActivityBindingModule::class,
        TestRepoServiceModule::class,
        ServiceModule::class,
        TestNavigationModule::class,
        TestActivityInterceptorModule::class]
)
interface TestApplicationComponent : AppComponent {
    fun inject(baseApplication: TrendingRepoControllerTest)
    fun screenNavigator(): TestScreenNavigator
    fun repoService(): TestRepoService
    fun repoRepository(): RepoRepository
}