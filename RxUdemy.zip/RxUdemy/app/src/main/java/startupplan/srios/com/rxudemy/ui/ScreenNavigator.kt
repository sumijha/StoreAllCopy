package startupplan.srios.com.rxudemy.ui

import com.bluelinelabs.conductor.Controller
import com.bluelinelabs.conductor.Router

interface ScreenNavigator {

    fun pop(): Boolean

    fun goToRepoDetails(repoOwner:String,repoName:String)
}