package startupplan.srios.com.rxudemy.ui.repoDetails

import dagger.Binds
import dagger.Module
import dagger.multibindings.IntoMap
import dagger.multibindings.IntoSet
import startupplan.srios.com.poweradapter.item.ItemRenderer
import startupplan.srios.com.poweradapter.item.RecyclerItem
import startupplan.srios.com.poweradapter.item.RenderKey
import startupplan.srios.com.rxudemy.lifecycle.ScreenLifecycleTask

@Module
abstract class RepoDetailScreenModule {

    @Binds
    @IntoSet
    abstract fun bindRepoDetailScreenModule(repoDetailsUiManager: RepoDetailsUiManager):ScreenLifecycleTask

    @Binds
    @IntoMap
    @RenderKey("Contributor")
    abstract fun bindContributorRenderer(contributorRenderer: ContributorRenderer):ItemRenderer<out RecyclerItem>
}