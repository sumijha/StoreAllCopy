package startupplan.srios.com.rxudemy.data

import dagger.Module
import dagger.Provides
import io.reactivex.Scheduler
import io.reactivex.schedulers.Schedulers
import retrofit2.Retrofit
import javax.inject.Named
import javax.inject.Singleton

@Module
class RepoServiceModule {

    @Provides
    @Singleton
    fun providesRepoService(retrofit: Retrofit): RepoService =
        retrofit.create(RepoService::class.java)

    //Need to update in UI Test module
    @Provides
    @Named("network_scheduler")
    @Singleton
    fun provideNetworkScheduler(): Scheduler = Schedulers.io()
}