package startupplan.srios.com.rxudemy.ui

import dagger.Binds
import dagger.Module
import dagger.multibindings.IntoSet
import startupplan.srios.com.rxudemy.lifecycle.ActivityLifecycleTask

/*
We need to add this to Activity Component so that it can
retrieve dependencies from this module
 */
@Module
abstract class NavigationModule {

    @Binds
    abstract fun provideScreenNavigator(navigator: DefaultScreenNavigator):ScreenNavigator

    //This will return an ActivityLifecycleTask, this will dagger to put this task into a set
    @Binds
    @IntoSet
    abstract fun bindScreenNavigatorTask(screenNavigator: DefaultScreenNavigator) : ActivityLifecycleTask
}