package startupplan.srios.com.rxudemy.ui

import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import startupplan.srios.com.rxudemy.R
import startupplan.srios.com.rxudemy.di.ActivityScope
import startupplan.srios.com.rxudemy.di.ScreenScope
import startupplan.srios.com.rxudemy.diBase.BaseActivity
import startupplan.srios.com.rxudemy.lifecycle.ActivityLifecycleTask
import startupplan.srios.com.rxudemy.ui.repoDetails.RepoDetailsFragment
import javax.inject.Inject

@ActivityScope
class DefaultScreenNavigator @Inject constructor() : ScreenNavigator, ActivityLifecycleTask() {

    private var mFragmentManager: FragmentManager? = null

    override fun onCreate(activity: AppCompatActivity) {
        init(activity.supportFragmentManager, (activity as BaseActivity).initialScreen())
    }

    override fun pop(): Boolean {
        return mFragmentManager != null && mFragmentManager?.popBackStackImmediate() ?: true
    }

    override fun goToRepoDetails(repoOwner: String, repoName: String) {
        val repoDetailsInstance = RepoDetailsFragment.newInstance(repoName, repoOwner)
        mFragmentManager?.beginTransaction()
            ?.replace(R.id.screen_container, repoDetailsInstance)
            ?.addToBackStack(null)
            ?.commit()
    }

    override fun onDestroy(activity: AppCompatActivity) {
        mFragmentManager = null
    }

    private fun init(fragmentManager: FragmentManager, rootScreen: Fragment) {
        mFragmentManager = fragmentManager
        if (mFragmentManager?.fragments?.size == 0) {
            mFragmentManager?.beginTransaction()
                ?.replace(R.id.screen_container, rootScreen)
                ?.commit()
        }
    }

}