package startupplan.srios.com.rxudemy.ui.trending

import com.jakewharton.rxrelay2.BehaviorRelay
import io.reactivex.Observable
import io.reactivex.functions.Action
import io.reactivex.functions.Consumer
import startupplan.srios.com.rxudemy.R
import startupplan.srios.com.rxudemy.di.ScreenScope
import startupplan.srios.com.rxudemy.model.Repo
import timber.log.Timber
import javax.inject.Inject

@ScreenScope
class TrendingRepoViewModel @Inject constructor() {

    /**
     * Relays to hold the state of ViewModel
     */
    private val reposRelay = BehaviorRelay.create<List<Repo>>()
    private val errorRelay = BehaviorRelay.create<Int>()
    private val loadingRelay = BehaviorRelay.create<Boolean>()

    fun loading():Observable<Boolean> = loadingRelay

    fun repos():Observable<List<Repo>> = reposRelay

    fun error():Observable<Int> = errorRelay

    fun loadingUpdated():Consumer<Boolean> = loadingRelay

    //Updating after implementing PowerADAPTER
    fun reposUpdated():Action {
        return Action { errorRelay.accept(-1)}
    }

    fun onError():Consumer<Throwable> = Consumer {
        Timber.e(it,"Error while loading Repos")
        errorRelay.accept(R.string.api_error_msg)
    }

}