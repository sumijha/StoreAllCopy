package startupplan.srios.com.rxudemy.model

import androidx.annotation.Nullable
import com.google.auto.value.AutoValue
import com.squareup.moshi.Json
import com.squareup.moshi.JsonAdapter
import com.squareup.moshi.Moshi
import startupplan.srios.com.poweradapter.item.RecyclerItem

@AutoValue
abstract class Contributor : RecyclerItem{

    abstract fun id(): Long

    abstract fun login(): String

    override fun getId(): Long = id()

    override fun renderKey(): String = "Contributor"

    @Nullable
    @Json(name = "avatar_url")
    abstract fun avatarUrl():String

    companion object {
        @JvmStatic
        fun jsonAdapter(moshi: Moshi):JsonAdapter<Contributor> = AutoValue_Contributor.MoshiJsonAdapter(moshi)
    }
}