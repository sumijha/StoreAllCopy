package startupplan.srios.com.rxudemy.ui.trending

import dagger.Subcomponent
import dagger.android.AndroidInjector
import startupplan.srios.com.rxudemy.di.ScreenComponent
import startupplan.srios.com.rxudemy.di.ScreenScope
import startupplan.srios.com.rxudemy.diBase.ScreenModule

@ScreenScope
@Subcomponent(modules = [ScreenModule::class, TrendingRepoScreenModule::class,RepoDataSourceModule::class])
interface TrendingRepoComponent : ScreenComponent<TrendingRepoFragment> {

    @Subcomponent.Builder
    abstract class Builder : AndroidInjector.Builder<TrendingRepoFragment>()
}