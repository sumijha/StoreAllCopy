package startupplan.srios.com.rxudemy.ui.repoDetails

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import com.bumptech.glide.Glide
import kotlinx.android.synthetic.main.view_user_list_item.view.*
import startupplan.srios.com.poweradapter.item.ItemRenderer
import startupplan.srios.com.rxudemy.R
import startupplan.srios.com.rxudemy.model.Contributor
import javax.inject.Inject

class ContributorRenderer @Inject constructor() : ItemRenderer<Contributor> {
    override fun layoutRes(): Int  = R.layout.view_user_list_item

    override fun createView(parent: ViewGroup): View {
        val view = LayoutInflater.from(parent.context).inflate(layoutRes(),parent,false)
        view.tag = ViewBinder(view)
        return view
    }

    override fun render(itemView: View, item: Contributor) = (itemView.tag as ViewBinder).bind(item)

    class ViewBinder(itemView: View) {
        private val userNameText = itemView.tv_user_name as TextView
        private val avatarImageView = itemView.iv_avatar as ImageView

        fun bind(contributor: Contributor) {
            userNameText.text = contributor.login()
            Glide.with(avatarImageView.context)
                .load(contributor.avatarUrl())
                .into(avatarImageView)
        }
    }
}