package startupplan.srios.com.rxudemy.ui.repoDetails

import dagger.BindsInstance
import dagger.Subcomponent
import dagger.android.AndroidInjector
import startupplan.srios.com.rxudemy.di.ScreenComponent
import startupplan.srios.com.rxudemy.di.ScreenScope
import startupplan.srios.com.rxudemy.diBase.ScreenModule
import javax.inject.Named

// We need to add this to MainScreenBindingModule
@ScreenScope
@Subcomponent(modules = [ScreenModule::class,RepoDetailScreenModule::class,ContributorDataSourceModule::class])
interface RepoDetailsComponent : ScreenComponent<RepoDetailsFragment> {

    @Subcomponent.Builder
    abstract class Builder: AndroidInjector.Builder<RepoDetailsFragment>() {

        // Instance used in Presenter
        @BindsInstance
        abstract fun bindRepoOwner(@Named("repo_owner") repoOwner:String)

        @BindsInstance
        abstract fun bindRepoName(@Named("repo_name") repoName:String)

        // To set the above qualifiers whenever an instance is launched for RepoDetailsController
        override fun seedInstance(instance: RepoDetailsFragment?) {
            bindRepoName(instance?.arguments?.getString(RepoDetailsController.REPO_NAME_KEY)?:"")
            bindRepoOwner(instance?.arguments?.getString(RepoDetailsController.REPO_OWNER_KEY)?:"")
        }
    }

}