package startupplan.srios.com.rxudemy.data

import io.reactivex.Maybe
import io.reactivex.Scheduler
import io.reactivex.Single
import startupplan.srios.com.rxudemy.model.Contributor
import startupplan.srios.com.rxudemy.model.Repo
import javax.inject.Inject
import javax.inject.Named
import javax.inject.Provider
import javax.inject.Singleton

@Singleton
class RepoRepository @Inject constructor(var repoRequestor: Provider<RepoRequestor>, @Named("network_scheduler") var scheduler: Scheduler) {

    private val cachedTrendingRepos = ArrayList<Repo>()
    private val cachedContributors = mutableMapOf<String, ArrayList<Contributor>>()

    /**
     * This method will return a Single item which uses a Maybe.Concat
     * IN THIS CASE if cachedTrendingRepos emits an item no other method call
     * will emits an item
     * @return SingleLisy<Repo> : Converted from Maybe.Concat
     */
    fun getTrendingRepos(): Single<List<Repo>> {
        return Maybe.concat(cachedTrendingRepos(), apiTrendingRepos())
            .firstOrError()
            .subscribeOn(scheduler)
    }


    /**
     * This method will return from the cached Contributors, if data exists or will return from the api call
     */
    fun getContributors(url: String): Single<List<Contributor>> {
        return Maybe.concat(cachedContributors(url), apiContributors(url))
            .firstOrError()
            .subscribeOn(scheduler)
    }

    /**
     * This method will return from the cachedTrendingRepo, if data exists or will return from the api call
     */
    fun getRepo(repoOwner: String, repoName: String): Single<Repo> {
        return Maybe.concat(cachedRepo(repoOwner, repoName), apiRepo(repoOwner, repoName))
            .firstOrError()
            .subscribeOn(scheduler)
    }

    private fun cachedContributors(url: String): Maybe<List<Contributor>> {
        return Maybe.create {
            if (cachedContributors.containsKey(url)) {
                cachedContributors[url]?.let { it1 -> it.onSuccess(it1) }
            }
            it.onComplete()
        }
    }

    private fun apiContributors(url: String): Maybe<List<Contributor>> {
        return repoRequestor.get().getContributors(url).doOnSuccess {
            cachedContributors[url] = it as ArrayList<Contributor>
        }.toMaybe()
    }

    /**
     * This method will return item if exists in cached array list
     * @return Maybe: As it can emit an item or complete without
     * emiting an item
     */
    private fun cachedTrendingRepos(): Maybe<List<Repo>> {
        return Maybe.create {
            if (cachedTrendingRepos.isNotEmpty()) {
                it.onSuccess(cachedTrendingRepos)
            }
            it.onComplete()
        }
    }

    /**
     * This method will return item from API Call
     */
    private fun apiTrendingRepos(): Maybe<List<Repo>> {
        return repoRequestor.get().getTrendingRepos().doOnSuccess {
            cachedTrendingRepos.clear()
            cachedTrendingRepos.addAll(it)
        }.toMaybe()
    }

    /**
     * This method will return the repos from API Call
     * Note: We aren't caching results because if user closes app from details page app gets kicked out of memory
     * However adding to TrendingRepocache doesn't make any sense
     */
    private fun apiRepo(repoOwner: String, repoName: String): Maybe<Repo> {
        return repoRequestor.get().getRepos(repoOwner, repoName)
            .toMaybe()
    }

    private fun cachedRepo(repoOwner: String, repoName: String): Maybe<Repo> {
        return Maybe.create {
            for (cachedRepo in cachedTrendingRepos) {
                if (cachedRepo.owner().login() == repoOwner) {
                    it.onSuccess(cachedRepo)
                    break
                }
                it.onComplete()
            }
        }
    }

    fun clearCache(): Unit {
        cachedContributors.clear()
        cachedTrendingRepos.clear()
    }

}