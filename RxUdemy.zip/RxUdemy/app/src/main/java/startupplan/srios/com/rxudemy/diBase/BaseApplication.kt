package startupplan.srios.com.rxudemy.diBase

import android.app.Application
import startupplan.srios.com.rxudemy.BuildConfig
import startupplan.srios.com.rxudemy.di.ActivityInjector
import timber.log.Timber
import javax.inject.Inject

open class BaseApplication : Application() {

    open var appComponent: AppComponent? = null

    @set:Inject
    internal var activityInjector: ActivityInjector? = null

    override fun onCreate() {
        super.onCreate()

        initComponent()
        appComponent?.inject(this)

        if (BuildConfig.DEBUG)
            Timber.plant(Timber.DebugTree())
    }

    open fun initComponent(): AppComponent? {
        if (appComponent == null)
            appComponent = DaggerAppComponent.builder()
                .appModule(AppModule(this)).build()
        return appComponent
    }

    fun getActivityInjector() = activityInjector
}