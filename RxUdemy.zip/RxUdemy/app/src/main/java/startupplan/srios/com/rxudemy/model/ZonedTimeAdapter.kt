package startupplan.srios.com.rxudemy.model

import com.squareup.moshi.FromJson
import com.squareup.moshi.ToJson
import org.threeten.bp.ZonedDateTime

/**
 * By Default, Moshi does not know how to serialize or deserialize the
 * data as its not a primitive type
 */
class ZonedTimeAdapter {

    @FromJson
    fun fromJson(json:String) = ZonedDateTime.parse(json)

    @ToJson
    fun toJson(value:ZonedDateTime)  = value.toString()?:null
}