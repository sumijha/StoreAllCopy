package startupplan.srios.com.rxudemy.ui.repoDetails

import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.Disposable
import kotlinx.android.synthetic.main.screen_repo_details.view.*
import startupplan.srios.com.poweradapter.adapter.RecyclerAdapter
import startupplan.srios.com.poweradapter.adapter.RecyclerDataSource
import startupplan.srios.com.rxudemy.R
import startupplan.srios.com.rxudemy.diBase.BaseFragment
import java.util.*
import javax.inject.Inject

class RepoDetailsFragment : BaseFragment() {

    private lateinit var repoNameText: TextView
    private lateinit var repoDescriptionText: TextView
    private lateinit var createdDateText: TextView
    private lateinit var updatedTextView: TextView
    private lateinit var contributorList: RecyclerView
    private lateinit var detailsLoadingView: View
    private lateinit var contributorLoadingView: View
    private lateinit var contentContainer: View
    private lateinit var erroTextView: TextView
    private lateinit var contributorErrorTextView: TextView

    @Inject
    lateinit var presenter: RepoDetailsPresenter

    @Inject
    lateinit var viewModel: RepoDetailViewModel

    @Inject
    lateinit var dataSource: RecyclerDataSource

    override fun onViewBound(view: View) {
        initView(view)
        contributorList.apply {
            layoutManager = LinearLayoutManager(view.context)
            adapter = RecyclerAdapter(dataSource)
        }

        super.onViewBound(view)
    }

    override fun layoutRes(): Int = R.layout.screen_repo_details

    // Creating Subscriptions since we have two Observables
    override fun subscription(): Array<Disposable?> {
        return arrayOf(
            viewModel.details()
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe {
                    if (it.loading()) {
                        detailsLoadingView.visibility = View.VISIBLE
                        contentContainer.visibility = View.GONE
                        erroTextView.visibility = View.GONE
                        erroTextView.text = null
                    } else {
                        if (it.isSuccess())
                            erroTextView.text = null
                        else
                            erroTextView.text = it.errorRes().toString()

                        detailsLoadingView.visibility = View.GONE
                        contentContainer.visibility =
                            if (it.isSuccess()) View.VISIBLE else View.GONE
                        erroTextView.visibility =
                            if (it.isSuccess()) View.GONE else View.VISIBLE
                        repoNameText.text = it.name()
                        repoDescriptionText.text = it.description()
                        createdDateText.text = it.createdDate()
                        updatedTextView.text = it.updatedDate()
                    }
                },
            viewModel.contributors()
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe {
                    if (it.loading()) {
                        contributorLoadingView.visibility = View.VISIBLE
                        contributorList.visibility = View.GONE
                        contributorErrorTextView.visibility = View.GONE
                        contributorErrorTextView.text = null
                    } else {
                        contributorLoadingView.visibility = View.GONE
                        if (it.isSuccess()) {
                            contributorErrorTextView.visibility = View.GONE
                            contributorErrorTextView.text = null
                            contributorList.visibility = View.VISIBLE
                            //(contributorList.adapter as ContributorAdapter).setData(it.contributors())
                        } else {
                            contributorErrorTextView.visibility = View.VISIBLE
                            contributorErrorTextView.text = it.errorRes().toString()
                        }
                    }
                }
        )
    }

    private fun initView(view: View) {
        repoNameText = view.tv_repo_name
        repoDescriptionText = view.tv_repo_description
        createdDateText = view.tv_creation_date
        updatedTextView = view.tv_updated_date
        contributorList = view.contributor_list
        detailsLoadingView = view.loading_indicator
        contributorLoadingView = view.contributor_loading_indicator
        contentContainer = view.content
        erroTextView = view.tv_error
        contributorErrorTextView = view.tv_contributors_error
    }

    companion object {
        const val REPO_NAME_KEY = "repo_name"
        const val REPO_OWNER_KEY = "repo_owner"

        fun newInstance(repoName: String, repoOwner: String): Fragment {
            return RepoDetailsFragment().apply {
                val bundle = Bundle().apply {
                    putString(REPO_NAME_KEY, repoName)
                    putString(REPO_OWNER_KEY, repoOwner)
                    putString("instance_id", UUID.randomUUID().toString())
                }
                arguments = bundle
            }

        }
    }

}