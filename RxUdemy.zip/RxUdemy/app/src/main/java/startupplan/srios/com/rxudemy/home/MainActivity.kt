package startupplan.srios.com.rxudemy.home

import androidx.fragment.app.Fragment
import startupplan.srios.com.rxudemy.R
import startupplan.srios.com.rxudemy.diBase.BaseActivity
import startupplan.srios.com.rxudemy.ui.trending.TrendingRepoFragment

class MainActivity : BaseActivity() {

    override fun initialScreen(): Fragment = TrendingRepoFragment.newInstance()

    override fun layoutRes(): Int = R.layout.activity_main
}
