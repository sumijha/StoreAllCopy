package startupplan.srios.com.rxudemy.ui.trending

import io.reactivex.android.schedulers.AndroidSchedulers
import startupplan.srios.com.poweradapter.adapter.RecyclerDataSource
import startupplan.srios.com.poweradapter.item.RecyclerItem
import startupplan.srios.com.rxudemy.data.RepoRepository
import startupplan.srios.com.rxudemy.di.ForScreen
import startupplan.srios.com.rxudemy.di.ScreenScope
import startupplan.srios.com.rxudemy.lifecycle.DisposableManager
import startupplan.srios.com.rxudemy.model.Repo
import startupplan.srios.com.rxudemy.ui.ScreenNavigator
import javax.inject.Inject

@ScreenScope
class TrendingRepoPresenter @Inject constructor(
    var viewModel: TrendingRepoViewModel,
    var repoRepository: RepoRepository,
    var screenNavigator: ScreenNavigator,
    var dataSource: RecyclerDataSource,
    @ForScreen var disposableManager: DisposableManager
) {

    init {
        loadRepos()
    }

    private fun loadRepos() {
        disposableManager.add(repoRepository.getTrendingRepos()
            .doOnSubscribe {
                viewModel.loadingUpdated().accept(true)
            } // We want to tell the ViewModel that repo is loading
            .doOnEvent { _, _ -> viewModel.loadingUpdated().accept(false) }
            // So on any event we want loading to stop and hence accept is false
            .doOnSuccess { viewModel.reposUpdated().run() }
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe(
                { dataSource.setData(it as ArrayList<RecyclerItem>) },
                { viewModel.onError().accept(it) })
        )
    }

    /**
     * Will navigate to Repo Details page
     * Note: Update Unit tests when any modification is done
     */
    fun onRepoClicked(repo: Repo) {
        screenNavigator.goToRepoDetails(repo.owner().login(), repo.name())
    }
}