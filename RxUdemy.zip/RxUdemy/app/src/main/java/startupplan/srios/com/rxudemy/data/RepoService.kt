package startupplan.srios.com.rxudemy.data

import io.reactivex.Single
import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.Url
import startupplan.srios.com.rxudemy.model.Contributor
import startupplan.srios.com.rxudemy.model.Repo

/**
 * Single will return one item or an error so its better to use
 * while handling network requests
 */
interface RepoService {

    @GET("search/repositories?q=language&order=desc&sort=stars")
    fun getTrendingRepos(): Single<TrendingReposResponse>

    @GET("repos/{owner}/{name}")
    fun getRepo(@Path("owner") repoOwner: String, @Path("name") repoName: String): Single<Repo>

    @GET
    fun getContributors(@Url url:String):Single<List<Contributor>>
}