package startupplan.srios.com.rxudemy.ui.trending

import dagger.Binds
import dagger.Module
import dagger.Provides
import dagger.multibindings.IntoMap
import dagger.multibindings.IntoSet
import startupplan.srios.com.poweradapter.adapter.RecyclerDataSource
import startupplan.srios.com.poweradapter.item.ItemRenderer
import startupplan.srios.com.poweradapter.item.RecyclerItem
import startupplan.srios.com.poweradapter.item.RenderKey
import startupplan.srios.com.rxudemy.di.ScreenScope
import startupplan.srios.com.rxudemy.lifecycle.ScreenLifecycleTask

@Module
abstract class TrendingRepoScreenModule {

    @Binds
    @IntoSet
    abstract fun bindsTrendingRepoScreen(trendingRepoUiManager: TrendingRepoUiManager): ScreenLifecycleTask

    @Binds
    @IntoMap
    @RenderKey("Repo")
    abstract fun bindRepoRenderer(repoRenderer: RepoRenderer): ItemRenderer<out RecyclerItem>

}