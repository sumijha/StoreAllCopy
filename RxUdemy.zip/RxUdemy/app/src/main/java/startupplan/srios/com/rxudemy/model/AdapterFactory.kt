package startupplan.srios.com.rxudemy.model

import com.ryanharter.auto.value.moshi.MoshiAdapterFactory
import com.squareup.moshi.JsonAdapter

/**
 * Register a Moshi object we don't have a Type Adapter manually whenever we
 * create a new AutoValue Repo
 */
@MoshiAdapterFactory
abstract class AdapterFactory : JsonAdapter.Factory {

    companion object {
        @JvmStatic
        fun create():JsonAdapter.Factory = AutoValueMoshi_AdapterFactory()
    }
}