package startupplan.srios.com.rxudemy.ui.repoDetails

import dagger.Module
import dagger.Provides
import startupplan.srios.com.poweradapter.adapter.RecyclerDataSource
import startupplan.srios.com.poweradapter.item.ItemRenderer
import startupplan.srios.com.poweradapter.item.RecyclerItem
import startupplan.srios.com.rxudemy.di.ScreenScope

@Module
class ContributorDataSourceModule {

    @Provides
    @ScreenScope
    fun provideContributorDataSource(render:MutableMap<String,ItemRenderer<out RecyclerItem>>) = RecyclerDataSource(render)
}