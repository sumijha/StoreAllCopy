package startupplan.srios.com.rxudemy.home

import com.prodApps.ui.ActivityViewInerceptorModule
import dagger.Subcomponent
import dagger.android.AndroidInjector
import startupplan.srios.com.rxudemy.di.ActivityScope
import startupplan.srios.com.rxudemy.ui.NavigationModule

@ActivityScope
@Subcomponent(modules = [MainScreenBindingModule::class,NavigationModule::class,ActivityViewInerceptorModule::class])
interface MainActivityComponent : AndroidInjector<MainActivity>{

    @Subcomponent.Builder
    abstract class Builder : AndroidInjector.Builder<MainActivity>() {
        override fun seedInstance(instance: MainActivity?) {

        }
    }
}