package startupplan.srios.com.rxudemy.ui.repoDetails

import android.view.View
import androidx.appcompat.widget.Toolbar
import butterknife.BindView
import butterknife.ButterKnife
import butterknife.Unbinder
import startupplan.srios.com.rxudemy.R
import startupplan.srios.com.rxudemy.lifecycle.ScreenLifecycleTask
import startupplan.srios.com.rxudemy.ui.ScreenNavigator
import startupplan.srios.com.rxudemy.util.ButterKnifeUtil
import javax.inject.Inject
import javax.inject.Named

class RepoDetailsUiManager @Inject constructor(@Named("repo_name") var repoName: String, var screenNavigator: ScreenNavigator) :
    ScreenLifecycleTask() {

    @BindView(R.id.toolbar)
    lateinit var toolbar: Toolbar

    private lateinit var unbinder: Unbinder

    override fun onEnterScope(view: View) {
        unbinder = ButterKnife.bind(this, view)
        toolbar.apply {
            title = repoName
            setNavigationIcon(R.drawable.ic_back)
            setNavigationOnClickListener { screenNavigator.pop() }
        }
    }

    override fun onExitScope() {
        toolbar.setNavigationOnClickListener(null)
        ButterKnifeUtil.unbind(unbinder)
    }
}