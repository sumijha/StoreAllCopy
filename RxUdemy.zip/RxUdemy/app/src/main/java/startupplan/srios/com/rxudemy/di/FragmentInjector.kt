package startupplan.srios.com.rxudemy.di

import android.app.Activity
import androidx.fragment.app.Fragment
import dagger.android.AndroidInjector
import startupplan.srios.com.rxudemy.diBase.BaseActivity
import startupplan.srios.com.rxudemy.diBase.BaseFragment
import java.lang.IllegalArgumentException
import javax.inject.Inject
import javax.inject.Provider

class FragmentInjector @Inject constructor(var fragmentInjectors:MutableMap<Class<out Fragment>, Provider<AndroidInjector.Factory<out Fragment>>>) {

    private var cache: MutableMap<String, AndroidInjector<Fragment>> = HashMap()

    fun inject(fragment: Fragment) {
        require((fragment is BaseFragment)) { "Fragment is not an instance of BaseFragment" }

        val instanceId = fragment.arguments?.getString("instance_id").toString()
        if (cache.containsKey(instanceId)) {
            cache[instanceId]?.inject(fragment)
            return
        }

        val injectorFactory =
            (fragmentInjectors[fragment::class.java]?.get() as AndroidInjector.Factory<Fragment>)
        val injector = injectorFactory.create(fragment)

        cache[instanceId] = injector
        Injector.inject(fragment)
    }

    fun clearComponent(fragment: Fragment) {
        val injector = cache.remove(fragment.arguments?.getString("instance_id").toString())
        if (injector is ScreenComponent) {
            injector.disposableManager().dispose()
        }
    }

    companion object {
        fun get(activity: Activity): FragmentInjector {
            if (activity is BaseActivity) {
                return activity.getFragmentInjector()!!
            }
            throw IllegalArgumentException("activity is not an instance of Base Activity")
        }
    }

}