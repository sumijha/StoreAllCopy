package startupplan.srios.com.rxudemy.model

import com.google.auto.value.AutoValue
import com.squareup.moshi.JsonAdapter
import com.squareup.moshi.Moshi

/**
 * This provides with us with immutable objects and makes testing easy since two models
 * with same value have same hashcode. This is similar to Data class of Kotlin
 */
@AutoValue
abstract class User {
    abstract fun id(): Long

    abstract fun login(): String

    companion object {
        @JvmStatic
        fun jsonAdapter(moshi: Moshi): JsonAdapter<User> {
            return AutoValue_User.MoshiJsonAdapter(moshi)
        }
    }

}