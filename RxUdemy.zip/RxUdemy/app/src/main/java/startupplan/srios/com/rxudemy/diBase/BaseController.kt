package startupplan.srios.com.rxudemy.diBase

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.annotation.LayoutRes
import butterknife.ButterKnife
import butterknife.Unbinder
import com.bluelinelabs.conductor.Controller
import com.bluelinelabs.conductor.ControllerChangeHandler
import com.bluelinelabs.conductor.ControllerChangeType
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.disposables.Disposable
import startupplan.srios.com.rxudemy.di.Injector
import startupplan.srios.com.rxudemy.lifecycle.ScreenLifecycleTask
import javax.inject.Inject

abstract class BaseController() : Controller() {

    constructor(bundle: Bundle) : this() {
    }

    @Inject
    lateinit var screenLifecycleTask: Set<@JvmSuppressWildcards ScreenLifecycleTask>

    private var unbinder: Unbinder?=null

    private val disposable = CompositeDisposable()
    private var injected = false

    override fun onContextAvailable(context: Context) {
        if (!injected) {
            Injector.inject(this)
            injected = true
        }
        super.onContextAvailable(context)
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup): View {
        val view = inflater.inflate(layoutRes(),container,false)
        unbinder = ButterKnife.bind(view)
        onViewBound(view)
        disposable.addAll(*subscription())
        return view
    }


    override fun onDestroyView(view: View) {
        super.onDestroyView(view)
        unbinder?.unbind()
        unbinder = null
    }

    override fun onChangeStarted(
        changeHandler: ControllerChangeHandler,
        changeType: ControllerChangeType
    ) {
        for (task in screenLifecycleTask) {
            if (changeType.isEnter)
                task.onEnterScope(view!!)
            else
                task.onExitScope()
        }
        super.onChangeStarted(changeHandler, changeType)
    }

    // Don't use disposable.destroy
    override fun onDestroy() {
        super.onDestroy()
        for (task in screenLifecycleTask)
            task.onDestroy()
        disposable.clear()
    }

    protected open fun onViewBound(view:View) {

    }

    protected open fun subscription(): Array<Disposable?> = arrayOf(arrayOf<Disposable>()[0])


    @LayoutRes
    protected abstract fun layoutRes():Int
}