package startupplan.srios.com.rxudemy.ui

import android.app.Activity
import androidx.annotation.LayoutRes

interface ActivityViewInterceptor {

    fun setContentView(activity: Activity, @LayoutRes layoutRes: Int) {
        activity.setContentView(layoutRes)
    }

    fun clear() {

    }
}