package startupplan.srios.com.rxudemy.di

import javax.inject.Scope

/**
 * This scope will be used for Configuration changes in the Prsenter
 * such as Screen Orientation or Language Settings
 */
@Scope
@Retention(AnnotationRetention.RUNTIME)
annotation class ScreenScope