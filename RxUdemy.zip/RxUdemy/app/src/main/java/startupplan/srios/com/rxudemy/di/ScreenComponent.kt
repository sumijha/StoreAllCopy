package startupplan.srios.com.rxudemy.di

import dagger.android.AndroidInjector
import startupplan.srios.com.rxudemy.lifecycle.DisposableManager

interface ScreenComponent<T> : AndroidInjector<T> {

    @ForScreen
    fun disposableManager():DisposableManager
}