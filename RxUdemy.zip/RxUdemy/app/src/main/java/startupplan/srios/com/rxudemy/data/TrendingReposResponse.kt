package startupplan.srios.com.rxudemy.data

import com.google.auto.value.AutoValue
import com.squareup.moshi.Json
import com.squareup.moshi.JsonAdapter
import com.squareup.moshi.Moshi
import startupplan.srios.com.rxudemy.model.Repo

@AutoValue
abstract class TrendingReposResponse {

    @Json(name = "items")
    abstract fun repos():List<Repo>

    companion object {
        @JvmStatic
        fun jsonAdapter(moshi: Moshi):JsonAdapter<TrendingReposResponse> {
            return AutoValue_TrendingReposResponse.MoshiJsonAdapter(moshi)
        }
    }
}