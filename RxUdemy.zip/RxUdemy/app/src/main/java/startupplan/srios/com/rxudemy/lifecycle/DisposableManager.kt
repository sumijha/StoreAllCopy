package startupplan.srios.com.rxudemy.lifecycle

import io.reactivex.disposables.CompositeDisposable
import io.reactivex.disposables.Disposable
import javax.inject.Inject

class DisposableManager @Inject constructor(){

    private val compositeDisposable = CompositeDisposable()

    fun add(vararg disposable: Disposable) = compositeDisposable.addAll(*disposable)

    fun dispose() = compositeDisposable.clear()
}