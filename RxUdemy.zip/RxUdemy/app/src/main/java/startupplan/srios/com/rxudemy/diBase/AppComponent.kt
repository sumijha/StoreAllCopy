package startupplan.srios.com.rxudemy.diBase

import com.prodApps.networking.NetworkModule
import dagger.Component
import startupplan.srios.com.rxudemy.data.RepoServiceModule
import startupplan.srios.com.rxudemy.network.ServiceModule
import javax.inject.Singleton

@Singleton
@Component(modules = [AppModule::class,ActivityBindingModule::class,NetworkModule::class,RepoServiceModule::class,ServiceModule::class])
interface AppComponent {
    fun inject(baseApplication: BaseApplication)
}