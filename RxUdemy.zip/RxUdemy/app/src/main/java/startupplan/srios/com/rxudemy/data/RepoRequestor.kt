package startupplan.srios.com.rxudemy.data

import io.reactivex.Single
import io.reactivex.schedulers.Schedulers
import startupplan.srios.com.rxudemy.model.Contributor
import startupplan.srios.com.rxudemy.model.Repo
import javax.inject.Inject

/**
 * We are removing subscribeOn since we are using caching as there is no need to hit API on background thread in requestor
 * and hence we'll move the subscribe On to repository
 */
class RepoRequestor @Inject constructor(var service: RepoService) {

    fun getTrendingRepos(): Single<List<Repo>> = service.getTrendingRepos()
        .map {
            return@map it.repos()
        }

    fun getRepos(repoOwner: String, repoName: String): Single<Repo> {
        return service.getRepo(
            repoOwner, repoName
        ).subscribeOn(Schedulers.io())
    }

    fun getContributors(url: String): Single<List<Contributor>> = service
        .getContributors(url)
        .subscribeOn(Schedulers.io())
}
