package startupplan.srios.com.rxudemy.util

import butterknife.Unbinder
import timber.log.Timber

class ButterKnifeUtil {

    companion object {
        fun unbind(unbinder: Unbinder?) {
            try {
                unbinder?.unbind()
            } catch (e: IllegalStateException) {
                Timber.e(e, "Error Unbinding views")
            }
        }
    }
}