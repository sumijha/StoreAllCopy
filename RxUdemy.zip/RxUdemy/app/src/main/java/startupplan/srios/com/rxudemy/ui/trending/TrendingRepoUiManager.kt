package startupplan.srios.com.rxudemy.ui.trending

import android.view.View
import androidx.appcompat.widget.Toolbar
import butterknife.BindView
import butterknife.ButterKnife
import butterknife.Unbinder
import startupplan.srios.com.rxudemy.R
import startupplan.srios.com.rxudemy.lifecycle.ScreenLifecycleTask
import startupplan.srios.com.rxudemy.util.ButterKnifeUtil
import javax.inject.Inject

class TrendingRepoUiManager @Inject constructor() : ScreenLifecycleTask() {

    private lateinit var unbinder: Unbinder

    @BindView(R.id.toolbar) lateinit var toolbar: Toolbar

    override fun onEnterScope(view: View) {
        unbinder = ButterKnife.bind(this, view)
        toolbar.title = view.context.getString(R.string.screen_title_trending)
    }

    override fun onExitScope() {
        ButterKnifeUtil.unbind(unbinder)
    }
}