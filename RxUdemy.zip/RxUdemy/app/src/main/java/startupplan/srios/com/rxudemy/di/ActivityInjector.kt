package startupplan.srios.com.rxudemy.di

import android.app.Activity
import android.content.Context
import dagger.android.AndroidInjector
import startupplan.srios.com.rxudemy.diBase.BaseActivity
import startupplan.srios.com.rxudemy.diBase.BaseApplication
import javax.inject.Inject
import javax.inject.Provider

class ActivityInjector @Inject constructor(var activityInjector: MutableMap<Class<out Activity>, Provider<AndroidInjector.Factory<out Activity>>>) {

    private var cache: MutableMap<String, AndroidInjector<out Activity>> = HashMap()

    fun inject(activity: Activity) {
        require(activity is BaseActivity) { "Activity must extend Base Activity" }

        val instanceId = activity.getInstanceId()

        if (cache.containsKey(instanceId)) {
            (cache[instanceId] as AndroidInjector<Activity>).inject(activity)
            return
        }

        val injectorFactory =
            activityInjector[activity::class.java]?.get() as AndroidInjector.Factory<Activity>
        val injector = injectorFactory.create(activity)

        cache[instanceId] = injector
        injector.inject(activity)
    }

    fun clear(activity: Activity) {
        require((activity is BaseActivity)) { "Activity must extend Base Activity" }
        cache.remove(activity.getInstanceId())
    }

    companion object {
        fun get(context: Context) =
            (context.applicationContext as BaseApplication).getActivityInjector()
    }
}