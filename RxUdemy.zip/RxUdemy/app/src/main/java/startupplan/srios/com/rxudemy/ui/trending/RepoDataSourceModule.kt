package startupplan.srios.com.rxudemy.ui.trending

import dagger.Module
import dagger.Provides
import startupplan.srios.com.poweradapter.adapter.RecyclerDataSource
import startupplan.srios.com.poweradapter.item.ItemRenderer
import startupplan.srios.com.poweradapter.item.RecyclerItem
import startupplan.srios.com.rxudemy.di.ScreenScope

@Module
class RepoDataSourceModule {

    @Provides
    @ScreenScope
    fun provideRecyclerDataSource(render: MutableMap<String, ItemRenderer<out RecyclerItem>>) =
        RecyclerDataSource(render)
}