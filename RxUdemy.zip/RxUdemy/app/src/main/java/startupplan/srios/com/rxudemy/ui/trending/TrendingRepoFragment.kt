package startupplan.srios.com.rxudemy.ui.trending


import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.View
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.Disposable
import startupplan.srios.com.poweradapter.adapter.RecyclerAdapter
import startupplan.srios.com.poweradapter.adapter.RecyclerDataSource
import startupplan.srios.com.rxudemy.R
import startupplan.srios.com.rxudemy.diBase.BaseFragment
import java.util.*
import javax.inject.Inject

class TrendingRepoFragment : BaseFragment() {
    lateinit var loadingView: View
    lateinit var errorText: TextView
    lateinit var reposList: RecyclerView

    @Inject
    lateinit var presenter: TrendingRepoPresenter

    @Inject
    lateinit var viewModel: TrendingRepoViewModel

    @Inject
    lateinit var recyclerDataSource: RecyclerDataSource

    override fun onViewBound(view: View) {
        initView(view)

        reposList.layoutManager = LinearLayoutManager(view.context)
        reposList.adapter = RecyclerAdapter(recyclerDataSource)
    }

    override fun layoutRes(): Int = R.layout.screen_trending_repos

    override fun subscription(): Array<Disposable?> {
        return arrayOf(
            viewModel.loading()
                .observeOn(AndroidSchedulers.mainThread())
                ?.subscribe {
                    loadingView.visibility = if (it) View.VISIBLE else View.GONE
                    reposList.visibility = if (it) View.GONE else View.VISIBLE
                    errorText.visibility = if (it) View.GONE else errorText.visibility
                },
            viewModel.error()
                .observeOn(AndroidSchedulers.mainThread())
                ?.subscribe {
                    if (it == -1) {
                        errorText.text = null
                        errorText.visibility = View.GONE
                    } else {
                        errorText.visibility = View.VISIBLE
                        reposList.visibility = View.GONE
                        errorText.text = it.toString()
                    }
                }
        )
    }

    private fun initView(view: View) {
        reposList = view.findViewById(R.id.repo_list)
        errorText = view.findViewById(R.id.tv_error)
        loadingView = view.findViewById(R.id.loading_indicator)
    }

    companion object {

        fun newInstance() : Fragment {
            return TrendingRepoFragment().apply {
                arguments = Bundle().apply {
                    putString("instance_id", UUID.randomUUID().toString())
                }
            }
        }
    }
}
