package startupplan.srios.com.rxudemy.di

import android.app.Activity
import com.bluelinelabs.conductor.Controller
import dagger.android.AndroidInjector
import startupplan.srios.com.rxudemy.diBase.BaseActivity
import startupplan.srios.com.rxudemy.diBase.BaseController
import java.lang.IllegalArgumentException
import javax.inject.Inject
import javax.inject.Provider

@ActivityScope
class ScreenInjector @Inject constructor(var screenInjectors:MutableMap<Class<out Controller>,Provider<AndroidInjector.Factory<out Controller>>>){

    private var cache:MutableMap<String,AndroidInjector<Controller>> = HashMap()

    fun inject(controller: Controller) {
        require((controller is BaseController)) { "Controller is not an instance of BaseController" }

        val instanceId = controller.instanceId
        if (cache.containsKey(instanceId)) {
            cache[instanceId]?.inject(controller)
            return
        }

        val injectorFactory = (screenInjectors[controller::class.java]?.get() as AndroidInjector.Factory<Controller>)
        val injector = injectorFactory.create(controller)

        cache[instanceId] = injector
        Injector.inject(controller)
    }

    fun clearComponent(controller: Controller) {
        val injector =  cache.remove(controller.instanceId)
        if (injector is ScreenComponent) {
            injector.disposableManager().dispose()
        }
    }

    companion object {
        fun get(activity: Activity): ScreenInjector {
            if (activity is BaseActivity) {
                return activity.getScreenInjector()!!
            }
            throw IllegalArgumentException("activity is not an instance of Base Activity")
        }
    }

}