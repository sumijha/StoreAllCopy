package startupplan.srios.com.rxudemy.lifecycle

import android.view.View

abstract class ScreenLifecycleTask {

    /**
     * Callback received when Screen/Controller is visible to user
     * @param view
     */
    open fun onEnterScope(view:View) {}

    /**
     * Callback received when a screen is popped or moved to backstack
     */
    open fun onExitScope() {}

    /**
     * Callback received when a screen is destroyed and not coming back. This will be used to dispose conneciton instances
     */
    open fun onDestroy() {}
}