package startupplan.srios.com.rxudemy.network

import com.prodApps.networking.NetworkModule
import com.squareup.moshi.Moshi
import dagger.Module
import dagger.Provides
import okhttp3.Call
import retrofit2.Retrofit
import retrofit2.adapter.rxjava2.RxJava2CallAdapterFactory
import retrofit2.converter.moshi.MoshiConverterFactory
import startupplan.srios.com.rxudemy.model.AdapterFactory
import startupplan.srios.com.rxudemy.model.ZonedTimeAdapter
import javax.inject.Named
import javax.inject.Singleton

@Module(includes = [NetworkModule::class])
class ServiceModule {

    @Provides
    @Singleton
    fun providesMoshi(): Moshi = Moshi.Builder()
        .add(AdapterFactory.create())
        .add(ZonedTimeAdapter())
        .build()

    @Provides
    @Singleton
    fun providesRetrofit(
        moshi: Moshi,
        callFactory: Call.Factory,
        @Named("base_url") baseUrl: String
    ): Retrofit = Retrofit.Builder()
        .callFactory(callFactory)
        .addConverterFactory(MoshiConverterFactory.create(moshi))
        .addCallAdapterFactory(RxJava2CallAdapterFactory.create())
        .baseUrl(baseUrl)
        .build()
}