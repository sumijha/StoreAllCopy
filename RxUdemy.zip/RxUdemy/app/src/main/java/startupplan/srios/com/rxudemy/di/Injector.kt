package startupplan.srios.com.rxudemy.di

import android.app.Activity
import androidx.fragment.app.Fragment
import com.bluelinelabs.conductor.Controller

class Injector {

    companion object {
        fun inject(activity: Activity) {
            ActivityInjector.get(activity)?.inject(activity)
        }

        fun clearComponent(activity: Activity) {
            ActivityInjector.get(activity)?.clear(activity)
        }

        fun inject(controller: Controller) {
            ScreenInjector.get(controller.activity!!).inject(controller)
        }

        fun clearComponent(controller: Controller) {
            ScreenInjector.get(controller.activity!!).clearComponent(controller)
        }

        fun inject(fragment: Fragment) {
            FragmentInjector.get(fragment.activity!!).inject(fragment)
        }

        fun clearComponent(fragment: Fragment) {
            FragmentInjector.get(fragment.activity!!).clearComponent(fragment)
        }
    }
}