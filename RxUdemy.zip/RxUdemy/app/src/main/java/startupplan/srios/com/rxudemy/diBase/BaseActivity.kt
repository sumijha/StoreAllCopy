package startupplan.srios.com.rxudemy.diBase

import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import androidx.annotation.LayoutRes
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import com.bluelinelabs.conductor.Conductor
import com.bluelinelabs.conductor.Controller
import com.bluelinelabs.conductor.ControllerChangeHandler
import com.bluelinelabs.conductor.Router
import startupplan.srios.com.rxudemy.R
import startupplan.srios.com.rxudemy.di.FragmentInjector
import startupplan.srios.com.rxudemy.di.Injector
import startupplan.srios.com.rxudemy.di.ScreenInjector
import startupplan.srios.com.rxudemy.lifecycle.ActivityLifecycleTask
import startupplan.srios.com.rxudemy.ui.ActivityViewInterceptor
import startupplan.srios.com.rxudemy.ui.ScreenNavigator
import java.lang.NullPointerException
import java.util.*
import javax.inject.Inject

/**
 * We have created a BaseActivity which will be extended by our other Activities
 * Using Instance ID we will retain the state of our activities
 */
abstract class BaseActivity : AppCompatActivity() {

    private lateinit var instanceID: String
    private lateinit var router: Router


    @set:Inject
    internal var fragmentInjector:FragmentInjector? = null

    @set:Inject
    internal var screenNavigator: ScreenNavigator? = null

    @set:Inject
    internal var activityViewInterceptor: ActivityViewInterceptor? = null

    @set:Inject
    lateinit var activityLifecycleTask: Set<@JvmSuppressWildcards ActivityLifecycleTask>

    @LayoutRes
    protected abstract fun layoutRes(): Int

    //abstract fun initialScreen(): Controller
    abstract fun initialScreen(): Fragment

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        instanceID =
            savedInstanceState?.get(INSTANCE_ID_KEY)?.toString() ?: UUID.randomUUID().toString()
        Injector.inject(this)

        //Replacing after implmenting debug drawer
        //setContentView(layoutRes())
        activityViewInterceptor?.setContentView(this, layoutRes())

        val screenContainer = findViewById<ViewGroup>(R.id.screen_container)
        screenContainer?:throw NullPointerException("Activity must have a View with Id: Screen Container")
        //Loop through activity Lifecycle task and call the method
        for (task in activityLifecycleTask) {
            task.onCreate(this)
        }
    }


    override fun onStart() {
        super.onStart()
        //Loop through activity Lifecycle task and call the method
        /*for (task in activityLifecycleTask) {
            task.onStart(this)
        }*/
    }

    override fun onResume() {
        super.onResume()
        //Loop through activity Lifecycle task and call the method
        for (task in activityLifecycleTask) {
            task.onResume(this)
        }
    }

    override fun onPause() {
        super.onPause()
        //Loop through activity Lifecycle task and call the method
        for (task in activityLifecycleTask) {
            task.onPause(this)
        }
    }

    override fun onStop() {
        super.onStop()
        //Loop through activity Lifecycle task and call the method
        for (task in activityLifecycleTask) {
            task.onStop(this)
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        outState.putString(INSTANCE_ID_KEY, instanceID)
        super.onSaveInstanceState(outState)
    }

    override fun onDestroy() {
        if (isFinishing) {
            Injector.clearComponent(this)
        }
        activityViewInterceptor?.clear()
        super.onDestroy()
        //Loop through activity Lifecycle task and call the method
        for (task in activityLifecycleTask) {
            task.onDestroy(this)
        }
    }

    override fun onBackPressed() {
        //If Screen Navigator didn't follow the pop then we need to call the super
        if (!screenNavigator?.pop()!!) {
            super.onBackPressed()
        }
    }

    fun getInstanceId() = instanceID

    fun getScreenInjector(): ScreenInjector? {
        return null
    }

    fun getFragmentInjector():FragmentInjector? {
        return fragmentInjector
    }

    internal fun getRouter() = router

    /**
     * This will be removed as we are clearing component from Fragment itself
     */
    /*private fun monitorBackStack() {
        router.addChangeListener(object : ControllerChangeHandler.ControllerChangeListener {
            override fun onChangeStarted(
                to: Controller?,
                from: Controller?,
                isPush: Boolean,
                container: ViewGroup,
                handler: ControllerChangeHandler
            ) {

            }

            // If user presses Back then push will be a false as it would be a pop from controller
            // is the ontroller from its popping
            override fun onChangeCompleted(
                to: Controller?,
                from: Controller?,
                isPush: Boolean,
                container: ViewGroup,
                handler: ControllerChangeHandler
            ) {
                if (isPush && from != null)
                    Injector.clearComponent(from)
            }

        })
    }*/

    companion object {
        //By using INSTANCE_ID, we are going to retain components in our activities
        private var INSTANCE_ID_KEY = "instance_id"
    }
}