package startupplan.srios.com.rxudemy.ui.repoDetails

import androidx.annotation.Nullable
import com.google.auto.value.AutoValue
import startupplan.srios.com.rxudemy.model.Contributor


@AutoValue
abstract class ContributorState {

    abstract fun loading(): Boolean

    @Nullable
    abstract fun contributors(): ArrayList<Contributor>

    @Nullable
    abstract fun errorRes(): Int?

    fun isSuccess(): Boolean {
        return errorRes() == null
    }

    @AutoValue.Builder
    abstract class Builder {

        abstract fun loading(loading: Boolean): Builder

        abstract fun contributors(contributor: ArrayList<Contributor>): Builder

        abstract fun errorRes(errorRes: Int?): Builder

        abstract fun build(): ContributorState

    }

    companion object {
        fun builder(): Builder = AutoValue_ContributorState.Builder()
    }
}
