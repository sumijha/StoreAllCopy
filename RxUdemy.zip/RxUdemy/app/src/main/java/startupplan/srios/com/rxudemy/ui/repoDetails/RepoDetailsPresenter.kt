package startupplan.srios.com.rxudemy.ui.repoDetails

import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.functions.Consumer
import startupplan.srios.com.poweradapter.adapter.RecyclerDataSource
import startupplan.srios.com.poweradapter.item.RecyclerItem
import startupplan.srios.com.rxudemy.data.RepoRepository
import startupplan.srios.com.rxudemy.di.ForScreen
import startupplan.srios.com.rxudemy.di.ScreenScope
import startupplan.srios.com.rxudemy.lifecycle.DisposableManager
import javax.inject.Inject
import javax.inject.Named

@ScreenScope
class RepoDetailsPresenter @Inject constructor(
    @Named("repo_owner") var repoOwner: String,
    @Named("repo_name") var repoName: String,
    @ForScreen var disposableManager: DisposableManager,
    repoRepository: RepoRepository,
    repoDetailViewModel: RepoDetailViewModel,
    var dataSource: RecyclerDataSource
) {

    init {
        disposableManager.add(repoRepository.getRepo(repoOwner, repoName)
            .doOnSuccess(repoDetailViewModel.processRepo())
            .doOnError(repoDetailViewModel.onDetailsError())
            .flatMap {
                repoRepository.getContributors(it.contributorsUrl())
                    .doOnError(repoDetailViewModel.onContributorsError())
            }
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe({
                dataSource.setData(it as ArrayList<RecyclerItem>)
                repoDetailViewModel.contributorsLoaded().accept(it)
            },{

            }))
    }
}