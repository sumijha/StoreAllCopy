package startupplan.srios.com.rxudemy.ui.repoDetails

import androidx.annotation.Nullable
import com.google.auto.value.AutoValue

/**
 * Here we are making some pieces nullable because they won't be always present
 */
@AutoValue
abstract class RepoDetailState {

    abstract fun loading():Boolean

    @Nullable
    abstract fun name():String

    @Nullable
    abstract fun description():String

    @Nullable
    abstract fun createdDate():String

    @Nullable
    abstract fun updatedDate():String

    @Nullable
    abstract fun errorRes():Int?

    fun isSuccess() : Boolean {
        return errorRes() == null
    }

    /**
     * Generate Builder for your object which will be used in ViewModel
     */
    @AutoValue.Builder
    abstract class Builder {

        abstract fun loading(loading:Boolean):Builder

        abstract fun name(name:String):Builder

        abstract fun description(desc:String):Builder

        abstract fun createdDate(createdDate:String):Builder

        abstract fun updatedDate(updatedDate:String):Builder

        abstract fun errorRes(errorRes:Int?):Builder

        abstract fun build():RepoDetailState
    }

    companion object {
        fun builder():Builder {
            return AutoValue_RepoDetailState.Builder()
        }
    }
}