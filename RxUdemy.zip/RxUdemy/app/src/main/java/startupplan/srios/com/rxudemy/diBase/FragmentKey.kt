package startupplan.srios.com.rxudemy.diBase

import androidx.fragment.app.Fragment
import com.bluelinelabs.conductor.Controller
import dagger.MapKey
import kotlin.reflect.KClass

@MapKey
@Target(AnnotationTarget.FUNCTION)
annotation class FragmentKey(val value: KClass<out Fragment>)