package startupplan.srios.com.rxudemy.model

import com.google.auto.value.AutoValue
import com.squareup.moshi.Json
import com.squareup.moshi.JsonAdapter
import com.squareup.moshi.Moshi
import org.threeten.bp.ZonedDateTime
import startupplan.srios.com.poweradapter.item.RecyclerItem

/**
 * Zoned DateTime are supported in API 26 (Android O), so we need a different library
 * for devices before API 26
 * Note: Method Names will corrospond to the keys in our Json, they are immutable so no setters
 */
@AutoValue
abstract class Repo : RecyclerItem{

    abstract fun id(): Long

    abstract fun name(): String

    abstract fun description(): String

    abstract fun owner(): User

    @Json(name = "stargazers_count")
    abstract fun stargazersCount(): Long

    @Json(name = "forks_count")
    abstract fun forksCount(): Long

    @Json(name = "contributors_url")
    abstract fun contributorsUrl(): String

    @Json(name = "created_at")
    abstract fun createdDate(): ZonedDateTime

    @Json(name = "updated_at")
    abstract fun updatedDate(): ZonedDateTime

    override fun renderKey(): String = "Repo"

    override fun getId(): Long  = id()

    companion object {
        @JvmStatic
        fun jsonAdapter(moshi: Moshi): JsonAdapter<Repo> = AutoValue_Repo.MoshiJsonAdapter(moshi)
    }
}