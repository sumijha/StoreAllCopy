package startupplan.srios.com.rxudemy.diBase

import dagger.Binds
import dagger.Module
import dagger.Provides
import dagger.multibindings.Multibinds
import startupplan.srios.com.rxudemy.di.ForScreen
import startupplan.srios.com.rxudemy.di.ScreenScope
import startupplan.srios.com.rxudemy.lifecycle.DisposableManager
import startupplan.srios.com.rxudemy.lifecycle.ScreenLifecycleTask

@Module
abstract class ScreenModule {

    @Multibinds
    abstract fun screenLifecycleTasks(): Set<ScreenLifecycleTask>

    @Binds
    @ScreenScope
    @ForScreen
    abstract fun providesDisposableManager(disposableManager: DisposableManager) : DisposableManager
}