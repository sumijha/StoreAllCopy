package startupplan.srios.com.rxudemy.diBase

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.annotation.LayoutRes
import androidx.fragment.app.Fragment
import butterknife.ButterKnife
import butterknife.Unbinder
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.disposables.Disposable
import startupplan.srios.com.rxudemy.di.Injector
import startupplan.srios.com.rxudemy.lifecycle.ScreenLifecycleTask
import javax.inject.Inject

abstract class BaseFragment : Fragment() {
    @Inject
    lateinit var screenLifecycleTask: Set<@JvmSuppressWildcards ScreenLifecycleTask>

    private var unbinder: Unbinder? = null
    private val disposable = CompositeDisposable()

    override fun onAttach(context: Context) {
        Injector.inject(this)
        super.onAttach(context)
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(layoutRes(), container, false)
        unbinder = ButterKnife.bind(view)
        onViewBound(view)
        disposable.addAll(*subscription())
        for (task in screenLifecycleTask)
            task.onEnterScope(view)
        return view
    }

    override fun onDestroyView() {
        disposable.clear()
        unbinder?.unbind()
        unbinder = null
        for (task in screenLifecycleTask)
            task.onExitScope()
        super.onDestroyView()
    }

    override fun onDestroy() {
        for (task in screenLifecycleTask)
            task.onDestroy()
        if (activity?.isChangingConfigurations == false)
            Injector.clearComponent(this)
        super.onDestroy()
    }

    protected open fun onViewBound(view: View) {
    }

    protected open fun subscription(): Array<Disposable?> = arrayOf(arrayOf<Disposable>()[0])

    @LayoutRes
    protected abstract fun layoutRes(): Int
}
