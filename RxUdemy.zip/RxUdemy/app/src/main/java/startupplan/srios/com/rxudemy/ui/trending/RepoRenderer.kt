package startupplan.srios.com.rxudemy.ui.trending

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import kotlinx.android.synthetic.main.view_repo_list_item.view.*
import startupplan.srios.com.poweradapter.item.ItemRenderer
import startupplan.srios.com.rxudemy.R
import startupplan.srios.com.rxudemy.model.Repo
import javax.inject.Inject
import javax.inject.Provider

/**
 * Note: We are using a Provider to inject TrendingRepoPresenter to inject our dependency in order
 * to avoid a dependency cycle as our Presenter is going to inject a data source but Data source requires
 * a String as key of renderer and we cannot provide data source without a renderer and now we are saying
 * renderer requires a Presenter
 * Using a provider we can delay the injection, unless its required
 */
class RepoRenderer @Inject constructor(var presenterProvider: Provider<TrendingRepoPresenter>): ItemRenderer<Repo> {

    override fun layoutRes(): Int = R.layout.view_repo_list_item

    override fun createView(parent: ViewGroup): View {
        val view = LayoutInflater.from(parent.context).inflate(layoutRes(), parent, false)
        view.tag = ViewBinder(view,presenterProvider.get())
        return view
    }

    override fun render(itemView: View, item: Repo) {
        (itemView.tag as ViewBinder).bind(item)
    }

    /**
     * Note: As of now we are using a presenter but if you have to use it in multiple screens do it
     * using a Click Listener interface
     */
    class ViewBinder(private val itemView: View, private val trendingRepoPresenter: TrendingRepoPresenter) {

        private val repoNameText = itemView.tv_repo_name
        private val repoDescriptionText = itemView.tv_repo_description
        private val forkCountText = itemView.tv_fork_count
        private val starCountText = itemView.tv_star_count

        fun bind(repo: Repo) {
            repoNameText.text = repo.name()
            repoDescriptionText.text = repo.description()
            forkCountText.text = repo.forksCount().toString()
            starCountText.text = repo.stargazersCount().toString()

            setItemClickListener(trendingRepoPresenter,repo)
        }

        private fun setItemClickListener(trendingRepoPresenter: TrendingRepoPresenter, repo: Repo) {
            itemView.setOnClickListener {
                trendingRepoPresenter.onRepoClicked(repo)
            }
        }
    }

}