package startupplan.srios.com.rxudemy.ui.repoDetails

import com.jakewharton.rxrelay2.BehaviorRelay
import io.reactivex.Observable
import io.reactivex.functions.Consumer
import org.threeten.bp.format.DateTimeFormatter
import startupplan.srios.com.rxudemy.R
import startupplan.srios.com.rxudemy.di.ScreenScope
import startupplan.srios.com.rxudemy.model.Contributor
import startupplan.srios.com.rxudemy.model.Repo
import timber.log.Timber
import javax.inject.Inject
import kotlin.reflect.jvm.internal.impl.load.kotlin.JvmType

@ScreenScope
class RepoDetailViewModel @Inject constructor() {

    private val DATE_FORMATTER = DateTimeFormatter.ofPattern("MMM dd,yyyy")

    private val detailStateRelay: BehaviorRelay<RepoDetailState> = BehaviorRelay.create()
    private val contributorStateRelay: BehaviorRelay<ContributorState> = BehaviorRelay.create()

    fun details(): Observable<RepoDetailState> = detailStateRelay

    fun contributors(): Observable<ContributorState> = contributorStateRelay

    fun processRepo(): Consumer<Repo> {
        return Consumer {
            detailStateRelay.accept(
                RepoDetailState.builder()
                    .loading(false)
                    .name(it.name())
                    .description(it.description())
                    .createdDate(it.createdDate().format(DATE_FORMATTER))
                    .updatedDate(it.updatedDate().format(DATE_FORMATTER))
                    .build()
            )
        }
    }

    //Removed :.contributors(it as ArrayList<Contributor>)
    fun contributorsLoaded():Consumer<List<Contributor>> {
        return Consumer {
            contributorStateRelay.accept(
                ContributorState.builder()
                    .loading(false)
                    .build()
            )
        }
    }

    fun onDetailsError():Consumer<Throwable> {
        return Consumer {
            Timber.e(it,"Error while loading Repos")
            detailStateRelay.accept(
                RepoDetailState.builder()
                    .loading(false)
                    .errorRes(R.string.api_error_single_repo)
                    .build()
            )
        }
    }

    fun onContributorsError():Consumer<Throwable> {
        return Consumer {
            Timber.e(it,"Error loading Contributors")
            contributorStateRelay.accept(
                ContributorState.builder()
                    .loading(false)
                    .errorRes(R.string.api_error_contributors)
                    .build()
            )
        }
    }

    /**
     * So Before any emthod call we are setting loading to true so that loading indicator is visible for both Contributors and RepoDetails
     */
    init {
        detailStateRelay.accept(
            RepoDetailState.builder()
                .loading(true)
                .build()
        )
        contributorStateRelay.accept(
            ContributorState.builder()
                .loading(true)
                .build()
        )
    }
}