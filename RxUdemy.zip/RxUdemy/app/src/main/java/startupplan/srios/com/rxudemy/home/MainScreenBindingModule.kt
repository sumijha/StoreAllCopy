package startupplan.srios.com.rxudemy.home

import androidx.fragment.app.Fragment
import dagger.Binds
import dagger.Module
import dagger.android.AndroidInjector
import dagger.multibindings.IntoMap
import startupplan.srios.com.rxudemy.diBase.FragmentKey
import startupplan.srios.com.rxudemy.ui.repoDetails.RepoDetailsComponent
import startupplan.srios.com.rxudemy.ui.repoDetails.RepoDetailsFragment
import startupplan.srios.com.rxudemy.ui.trending.TrendingRepoComponent
import startupplan.srios.com.rxudemy.ui.trending.TrendingRepoFragment

@Module(subcomponents = [TrendingRepoComponent::class, RepoDetailsComponent::class])
abstract class MainScreenBindingModule {

    /*@Binds
    @IntoMap
    @ControllerKey(TrendingRepoController::class)
    abstract fun bindsTrendingRepoInjector(builder: TrendingRepoComponent.Builder): AndroidInjector.Factory<out Controller>

    @Binds
    @IntoMap
    @ControllerKey(RepoDetailsController::class)
    abstract fun bindsRepoDetailsInjector(builder: RepoDetailsComponent.Builder):AndroidInjector.Factory<out Controller>*/

    @Binds
    @IntoMap
    @FragmentKey(TrendingRepoFragment::class)
    internal abstract fun bindsTrendingRepoInjector(builder: TrendingRepoComponent.Builder): AndroidInjector.Factory<out Fragment>

    @Binds
    @IntoMap
    @FragmentKey(RepoDetailsFragment::class)
    abstract fun bindsRepoDetailsInjector(builder: RepoDetailsComponent.Builder): AndroidInjector.Factory<out Fragment>
}