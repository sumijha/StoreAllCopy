package startupplan.srios.com.rxudemy.ui.listeners

import startupplan.srios.com.rxudemy.model.Repo

interface RepoClickListener {
    fun onRepoClicked(repo:Repo)
}