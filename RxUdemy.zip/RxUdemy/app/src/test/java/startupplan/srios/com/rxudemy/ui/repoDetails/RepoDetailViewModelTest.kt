package startupplan.srios.com.rxudemy.ui.repoDetails

import com.squareup.moshi.Types
import org.junit.Before
import org.junit.Test
import startupplan.srios.com.rxudemy.R
import startupplan.srios.com.rxudemy.model.Contributor
import startupplan.srios.com.rxudemy.model.Repo
import startupplan.srios.com.rxudemy.testUtils.TestUtils
import java.io.IOException

class RepoDetailViewModelTest {

    private lateinit var repoDetailViewModel: RepoDetailViewModel

    private val repo = TestUtils.loadJSON("mock/repos/get_repo.json", Repo::class.java)

    // When you are trying to serialize into list of something we need to follow below steps
    private val contributors = TestUtils.loadJSON<List<Contributor>>(
        "mock/repos/contributors/get_contributors.json",
        Types.newParameterizedType(List::class.java, Contributor::class.java)
    )

    @Before
    fun setUp() {
        repoDetailViewModel = RepoDetailViewModel()
    }

    @Test
    fun details() {
        repoDetailViewModel.processRepo().accept(repo)

        repoDetailViewModel.details().test().assertValue(
            RepoDetailState.builder()
                .loading(false)
                .name("RxJava")
                .description("RxJava – Reactive Extensions for the JVM – a library for composing asynchronous and event-based programs using observable sequences for the Java VM.")
                .createdDate("Jan 08,2013")
                .updatedDate("Oct 06,2017")
                .build()
        )
    }

    @Test
    fun onDetailsError() {
        repoDetailViewModel.onDetailsError().accept(IOException())

        repoDetailViewModel.details().test().assertValue(
            RepoDetailState.builder()
                .loading(false)
                .errorRes(R.string.api_error_single_repo)
                .build()
        )
    }

    @Test
    fun contributors() {
        repoDetailViewModel.contributorsLoaded().accept(contributors as ArrayList)

        repoDetailViewModel.contributors().test().assertValue(
            ContributorState.builder()
                .loading(false)
                .build()
        )
    }

    @Test
    fun onContributorsError() {
        repoDetailViewModel.onContributorsError().accept(IOException())

        repoDetailViewModel.contributors().test().assertValue(
            ContributorState.builder()
                .loading(false)
                .errorRes(R.string.api_error_contributors)
                .build()
        )
    }
}