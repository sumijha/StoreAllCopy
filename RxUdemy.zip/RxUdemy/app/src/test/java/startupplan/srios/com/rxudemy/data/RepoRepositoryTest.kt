package startupplan.srios.com.rxudemy.data

import io.reactivex.Single
import io.reactivex.plugins.RxJavaPlugins
import io.reactivex.schedulers.Schedulers
import org.junit.Before
import org.junit.Test
import org.mockito.ArgumentMatchers.anyString
import org.mockito.Mock
import org.mockito.Mockito
import org.mockito.MockitoAnnotations
import startupplan.srios.com.rxudemy.model.Repo
import startupplan.srios.com.rxudemy.testUtils.TestUtils
import javax.inject.Provider

class RepoRepositoryTest {

    /**
     * Note: We have to use below init block before each test since we have used Schedulers.io
     * which peforms our operation on background Thread which makes our test to fail. Using below
     * block of code before each test increases complexity of our UI test code. Hence we'll use custom
     * schedulers which will be injected in Repository provided by Service Module.
     */
    /*init {
        RxJavaPlugins.setIoSchedulerHandler {
            Schedulers.trampoline()
        }
    }*/

    @Mock
    var repoRequestorProvider: Provider<RepoRequestor>?=null

    @Mock
    var repoRequestor:RepoRequestor?=null

    private lateinit var repoRepository: RepoRepository
    private lateinit var trendingReposResponse: TrendingReposResponse
    private lateinit var rxJavaRepo:Repo
    private lateinit var otherRepo:Repo

    @Before
    fun setUp() {
        MockitoAnnotations.initMocks(this)
        Mockito.`when`(repoRequestorProvider?.get()).thenReturn(repoRequestor)

        trendingReposResponse = TestUtils.loadJSON("mock/search/get_trending_repos_response.json",TrendingReposResponse::class.java)
        Mockito.`when`(repoRequestor?.getTrendingRepos()).thenReturn(Single.just(trendingReposResponse.repos()))

        rxJavaRepo = trendingReposResponse.repos()[0]
        otherRepo = trendingReposResponse.repos()[1]

        repoRepository = RepoRepository(repoRequestorProvider!!,Schedulers.trampoline())
    }

    /**
     * In the first test we are first testing that our repo returns all the data from json file
     * Then in the next step we have mutated the list then again we are validaing if its returning the original
     * json that was previously returned since its already cached
     */
    @Test
    fun getTrendingRepos() {
        repoRepository.getTrendingRepos().test().assertValues(trendingReposResponse.repos())

        val modifiedList = arrayListOf<Repo>()
        modifiedList.addAll(trendingReposResponse.repos())
        modifiedList.removeAt(0)

        Mockito.`when`(repoRequestor?.getTrendingRepos()).thenReturn(Single.just(modifiedList))
        repoRepository.getTrendingRepos().test().assertValues(trendingReposResponse.repos())
    }

    /**
     * Now in order to test getRepo we are assuming that user has already seen trendingRepos
     * so we'll call subscribe so that it initializes our cache
     */
    @Test
    fun getRepo() {
        repoRepository.getTrendingRepos().subscribe()

        // Whenever getRepos is called by repoRequestor with anystring value it will return otherRepo
        Mockito.`when`(repoRequestor?.getRepos(anyString(), anyString())).thenReturn(Single.just(otherRepo))

        // This will return true since we have already that value in cache
        repoRepository.getRepo("ReactiveX","RxJava").test().assertValue(rxJavaRepo)
        // This will make a API call as no owner and login name exists in cache and repoRequestor return otherRepo
        repoRepository.getRepo("NotCached","NotCached").test().assertValue(otherRepo)
    }

    /**
     * Note: So, you might be wondering that why we haven't checked the getTrendingRepos() being called once
     * but its not the case since it returns a Maybe of cached and api calls. Even if the cached data exists
     * api method will be called but returned data from api won't have any significance
     */
}