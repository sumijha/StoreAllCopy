package startupplan.srios.com.rxudemy.ui.repoDetails

import com.squareup.moshi.Types
import io.reactivex.Single
import io.reactivex.android.plugins.RxAndroidPlugins
import io.reactivex.functions.Consumer
import io.reactivex.schedulers.Schedulers
import org.junit.Before
import org.junit.Test
import org.mockito.Mock
import org.mockito.Mockito
import org.mockito.Mockito.verify
import org.mockito.MockitoAnnotations
import startupplan.srios.com.poweradapter.adapter.RecyclerDataSource
import startupplan.srios.com.poweradapter.item.RecyclerItem
import startupplan.srios.com.rxudemy.data.RepoRepository
import startupplan.srios.com.rxudemy.lifecycle.DisposableManager
import startupplan.srios.com.rxudemy.model.Contributor
import startupplan.srios.com.rxudemy.model.Repo
import startupplan.srios.com.rxudemy.testUtils.TestUtils
import java.io.IOException

class RepoDetailsPresenterTest {

    // In JAVA its the static block of code
    init {
        RxAndroidPlugins.setInitMainThreadSchedulerHandler{
            Schedulers.trampoline()
        }
    }

    private val OWNER = "owner"
    private val NAME = "name"
    private val repo = TestUtils.loadJSON("mock/repos/get_repo.json", Repo::class.java)
    private val contributorsUrl = repo.contributorsUrl()
    private val contributors = TestUtils.loadJSON<List<Contributor>>(
        "mock/repos/contributors/get_contributors.json",
        Types.newParameterizedType(List::class.java, Contributor::class.java)
    )

    @Mock
    internal var repoRepository: RepoRepository? = null
    @Mock
    internal var repoDetailViewModel: RepoDetailViewModel? = null
    @Mock
    internal var repoConsumer: Consumer<Repo>? = null
    @Mock
    internal var contributorConsumer: Consumer<List<Contributor>>? = null
    @Mock
    internal var detailsErrorConsumer: Consumer<Throwable>? = null
    @Mock
    internal var contributorErrorConsumer: Consumer<Throwable>? = null
    @Mock
    internal var dataSource:RecyclerDataSource?=null

    @Before
    fun setUp() {
        MockitoAnnotations.initMocks(this)

        Mockito.`when`(repoDetailViewModel?.processRepo()).thenReturn(repoConsumer)
        Mockito.`when`(repoDetailViewModel?.contributorsLoaded()).thenReturn(contributorConsumer)
        Mockito.`when`(repoDetailViewModel?.onContributorsError())
            .thenReturn(contributorErrorConsumer)
        Mockito.`when`(repoDetailViewModel?.onDetailsError()).thenReturn(detailsErrorConsumer)

        Mockito.`when`(repoRepository?.getRepo(OWNER, NAME)).thenReturn(Single.just(repo))
        Mockito.`when`(repoRepository?.getContributors(contributorsUrl))
            .thenReturn(Single.just(contributors as ArrayList<Contributor>))
    }

    private fun initPresenter() {
        RepoDetailsPresenter(OWNER, NAME,Mockito.mock(DisposableManager::class.java), repoRepository!!, repoDetailViewModel!!,dataSource!!)
    }

    /**
     * This is a basic RepoDetails Test when a Repo DETAILS is initiated repoConsumer will be accepting repo
     */
    @Test
    fun repoDetails() {
        initPresenter()
        verify(repoConsumer)?.accept(repo)
    }

    /**
     * This a Error test so we need to override the behavior and return error instead of repo
     */
    @Test
    fun repoDetailsError() {
        val t = IOException()
        Mockito.`when`(repoRepository?.getRepo(OWNER, NAME)).thenReturn(Single.error(t))
        initPresenter()
        verify(detailsErrorConsumer)?.accept(t)
    }

    /**
     * Test if Contributors has loaded successfully
     */
    @Test
    fun contributors() {
        initPresenter()

        verify(dataSource)?.setData(contributors as ArrayList<out RecyclerItem>)
    }

    /**
     * Test if Contributors error was thrown
     */
    @Test
    fun contributorsError() {
        val t = IOException()
        Mockito.`when`(repoRepository?.getContributors(contributorsUrl)).thenReturn(Single.error(t))

        initPresenter()
        verify(contributorErrorConsumer)?.accept(t)
        //Test if Consumer error has not affected Repo Details Consumer
        verify(repoConsumer)?.accept(repo)
    }
}