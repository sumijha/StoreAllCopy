package startupplan.srios.com.rxudemy.testUtils

import com.squareup.moshi.Moshi
import startupplan.srios.com.rxudemy.model.AdapterFactory
import startupplan.srios.com.rxudemy.model.ZonedTimeAdapter
import java.io.BufferedReader
import java.io.IOException
import java.io.InputStreamReader
import java.lang.reflect.Type

class TestUtils {

    companion object {
        val INSTANCE = TestUtils()
        val TEST_MOSHI = initMoshi()

        fun initMoshi() = Moshi.Builder()
            .add(AdapterFactory.create())
            .add(ZonedTimeAdapter())
            .build()

        fun <T> loadJSON(path: String, type: Type): T {
            try {
                val json = getFileString(path)
                return TEST_MOSHI.adapter<T>(type).fromJson(json) as T
            } catch (e: IOException) {
                throw IllegalArgumentException("Could not Deserialize " + path + " into type " + type)
            }
        }

        fun <T> loadJSON(path: String, clazz: Class<T>): T {
            try {
                val json = getFileString(path)
                return TEST_MOSHI.adapter(clazz).fromJson(json) as T
            } catch (e: IOException) {
                throw IllegalArgumentException("Could not Deserialize " + path + " into class " + clazz)
            }
        }

        private fun getFileString(path: String): String {
            try {
                val reader = BufferedReader(
                    InputStreamReader(
                        INSTANCE.javaClass.classLoader.getResourceAsStream(path)
                    )
                )
                return reader.use {
                    it.readText()
                }
            } catch (e: IOException) {
                throw IllegalArgumentException("Could not read resource from path :" + path)
            }
        }

    }
}