package startupplan.srios.com.rxudemy.ui.trending

import org.junit.Test

import org.junit.Before
import startupplan.srios.com.rxudemy.R
import startupplan.srios.com.rxudemy.data.TrendingReposResponse
import startupplan.srios.com.rxudemy.testUtils.TestUtils
import java.io.IOException
import java.util.*

class TrendingRepoViewModelTest {

    private lateinit var trendingRepoViewModel: TrendingRepoViewModel

    @Before
    fun setUp() {
        trendingRepoViewModel = TrendingRepoViewModel()
    }

    @Test
    fun loading() {
        // This returns a TestObserver<Boolean>, So if you look at the test method it subscribe to test Observer
        val loadingObserver = trendingRepoViewModel.loading().test()
        trendingRepoViewModel.loadingUpdated().accept(true)
        trendingRepoViewModel.loadingUpdated().accept(false)

        loadingObserver.assertValues(true,false)
    }


    @Test
    fun error() {
        val errorObserver = trendingRepoViewModel.error().test()
        trendingRepoViewModel.onError().accept(IOException())
        trendingRepoViewModel.reposUpdated().run()

        errorObserver.assertValues(R.string.api_error_msg,-1)
    }
}