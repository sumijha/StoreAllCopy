package startupplan.srios.com.rxudemy.ui.trending

import io.reactivex.Single
import io.reactivex.android.plugins.RxAndroidPlugins
import io.reactivex.functions.Action
import io.reactivex.functions.Consumer
import io.reactivex.plugins.RxJavaPlugins
import io.reactivex.schedulers.Schedulers
import org.junit.Before
import org.junit.Test
import org.mockito.Mock
import org.mockito.Mockito
import org.mockito.Mockito.verify
import org.mockito.Mockito.verifyZeroInteractions
import org.mockito.MockitoAnnotations
import startupplan.srios.com.poweradapter.adapter.RecyclerDataSource
import startupplan.srios.com.poweradapter.item.RecyclerItem
import startupplan.srios.com.rxudemy.data.RepoRepository
import startupplan.srios.com.rxudemy.data.TrendingReposResponse
import startupplan.srios.com.rxudemy.lifecycle.DisposableManager
import startupplan.srios.com.rxudemy.model.Repo
import startupplan.srios.com.rxudemy.testUtils.TestUtils
import startupplan.srios.com.rxudemy.ui.ScreenNavigator
import java.io.IOException

class TrendingRepoPresenterTest {

    init {
        RxAndroidPlugins.setInitMainThreadSchedulerHandler{
            Schedulers.trampoline()
        }
    }

    /**
     * Below we have mocked our dependencies which are used in our Presenter
     * & have mocked consumer becuase our presenter uses these consumers
     */

    @Mock
    var repoRepository: RepoRepository? = null

    @Mock
    var viewModel: TrendingRepoViewModel? = null

    @Mock
    var onErrorConsumer: Consumer<Throwable>? = null

    @Mock
    var loadingConsumer: Consumer<Boolean>? = null

    @Mock
    var screenNavigator: ScreenNavigator? = null

    @Mock
    var dataSource: RecyclerDataSource? = null

    //We cannot initialize here as we have loadRepos inside init block
    private lateinit var presenter: TrendingRepoPresenter

    /**
     * So now our ViewModel is mocked when a method is called it won't throw a NullPointer Exception
     * If that method returns something like if loading updated is called we have to explicitly specify
     * that it has to return loadingConsumer
     */
    @Before
    fun setUp() {
        MockitoAnnotations.initMocks(this)
        Mockito.`when`(viewModel?.loadingUpdated()).thenReturn(loadingConsumer)
        Mockito.`when`(viewModel?.onError()).thenReturn(onErrorConsumer)
        Mockito.`when`(viewModel?.reposUpdated()).thenReturn(Action { })
    }

    @Test
    fun reposLoaded() {
        val repos = setUpSuccess()
        initializePresenter()

        //We can verify certain methods get called on it, Now we want to verify when presenter is created repoRequestor.getTrendingRepos is called
        verify(repoRepository)?.getTrendingRepos()
        //Now we want to verify onSuccessConsumer was called with following value
        verify(dataSource)?.setData(repos as ArrayList<RecyclerItem>)
        //Verify there was no interaction with onErrorConsumer
        verifyZeroInteractions(onErrorConsumer)
    }

    @Test
    fun reposLoadedError() {
        val error = setUpError()
        initializePresenter()

        verify(onErrorConsumer)?.accept(error)
        verifyZeroInteractions(dataSource)
    }

    /**
     * Now lets test loading is togged in both error and success state
     */
    @Test
    fun loadingSuccess() {
        setUpSuccess()
        initializePresenter()

        //Mockito has a method inorder which checks the values are loaded inorder
        val inorder = Mockito.inOrder(loadingConsumer)
        inorder.verify(loadingConsumer)?.accept(true)
        inorder.verify(loadingConsumer)?.accept(false)
    }

    @Test
    fun loadingError() {
        setUpError()
        initializePresenter()

        val inorder = Mockito.inOrder(loadingConsumer)
        inorder.verify(loadingConsumer)?.accept(true)
        inorder.verify(loadingConsumer)?.accept(false)
    }

    /*
    *Test if onRepoClicked mocks goTORepoDetails page correctly
     */
    @Test
    fun onRepoClicked() {
        val repo = TestUtils.loadJSON("mock/repos/get_repo.json", Repo::class.java)

        setUpSuccess()
        initializePresenter()

        presenter.onRepoClicked(repo)
        verify(screenNavigator)?.goToRepoDetails(repo.owner().login(), repo.name())
    }

    /**
     * Note: Method to initialize presenter so that we can call it before every tests
     */
    private fun initializePresenter() {
        presenter = TrendingRepoPresenter(
            viewModel!!,
            repoRepository!!,
            screenNavigator!!,
            dataSource!!,
            Mockito.mock(DisposableManager::class.java)
        )
    }

    /**
     * Note: We need to setup Sucess since when Presenter will be initialized getTrendingRepos will be mocked
     * which returns repo object
     */
    private fun setUpSuccess(): List<Repo> {
        val response = TestUtils.loadJSON(
            "mock/search/get_trending_repos_response.json",
            TrendingReposResponse::class.java
        )
        val repos = response.repos()
        Mockito.`when`(repoRepository?.getTrendingRepos()).thenReturn(Single.just(repos))

        return repos
    }

    private fun setUpError(): Throwable {
        val error = IOException()
        Mockito.`when`(repoRepository?.getTrendingRepos()).thenReturn(Single.error(error))

        return error
    }
}
