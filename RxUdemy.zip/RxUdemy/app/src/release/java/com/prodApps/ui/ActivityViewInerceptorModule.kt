package com.prodApps.ui

import dagger.Module
import dagger.Provides

@Module class ActivityViewInerceptorModule {

    @Provides
    fun provideActivityViewInterceptor(): ReleaseActivityViewInterceptor {
        return ReleaseActivityViewInterceptor()
    }
}