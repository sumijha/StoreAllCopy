package com.prodApps.ui

import android.app.Activity
import startupplan.srios.com.rxudemy.ui.ActivityViewInterceptor
import javax.inject.Inject

class ReleaseActivityViewInterceptor : ActivityViewInterceptor {

}