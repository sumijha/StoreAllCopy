package startupplan.srios.com.poweradapter.adapter

import android.view.View
import android.view.ViewGroup
import androidx.annotation.VisibleForTesting
import junit.framework.Assert.assertEquals
import org.junit.Before
import org.junit.Test
import startupplan.srios.com.poweradapter.item.ItemRenderer
import startupplan.srios.com.poweradapter.item.RecyclerItem

/**
 * Note: Wwe cannot use setData for our testing as it uses Android framework
 * hence we have to create separate method in DataSource to seed data to our data source
 */
class RecyclerDataSourceTest {

    private val rendererOne = TestRenderer(1)
    private val rendererTWO = TestRenderer(2)
    private val itemOne = TestItem(1,"key1")
    private val itemTwo = TestItem(2,"key2")
    private val itemThree = TestItem(3,"key3")

    private lateinit var dataSource: RecyclerDataSource

    @Before
    fun setUp() {
        val items = arrayListOf(itemOne,itemTwo,itemThree)
        val map = mutableMapOf<String,ItemRenderer<out RecyclerItem>>()
        map[itemOne.key] = rendererOne
        map[itemTwo.key] = rendererTWO

        dataSource = RecyclerDataSource(map)
        dataSource.seedData(items)
    }

    @Test
    fun rendererForType() {
        assertEquals(rendererOne,dataSource.rendererForType(rendererOne.layoutRes()))
        assertEquals(rendererTWO,dataSource.rendererForType(rendererTWO.layoutRes()))
    }

    @Test
    fun viewResourceForPosition() {
        assertEquals(rendererOne.layoutRes(),1)
        assertEquals(rendererTWO.layoutRes(),2)
    }

    @Test
    fun getCount() {
        assertEquals(3,dataSource.getCount())
    }

    @Test
    fun getItem() {
        assertEquals(itemOne,dataSource.getItem(0))
        assertEquals(itemThree,dataSource.getItem(2))
    }

    //Instead of using Mockito we'll be using Test versions of Recycler Item and Item Renderer
    class TestItem(private var id: Long, var key: String) : RecyclerItem {
        override fun getId(): Long = id

        override fun renderKey(): String = key
    }

    class TestRenderer(private val layoutRes:Int):ItemRenderer<RecyclerItem> {
        override fun layoutRes(): Int = layoutRes

        override fun createView(parent: ViewGroup): View {
            return null!!
        }

        override fun render(itemView: View, item: RecyclerItem) {
            return null!!
        }

    }
}