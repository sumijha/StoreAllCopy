package startupplan.srios.com.poweradapter.adapter

import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import startupplan.srios.com.poweradapter.item.ItemRenderer
import startupplan.srios.com.poweradapter.item.RecyclerItem

class RecyclerViewHolder(parent: ViewGroup, var renderer: ItemRenderer<RecyclerItem>) :
    RecyclerView.ViewHolder(renderer.createView(parent)) {

    fun bind(item:RecyclerItem) = renderer.render(itemView,item)
}