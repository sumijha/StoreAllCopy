package startupplan.srios.com.poweradapter.adapter

import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView

/**
 * You can see here that all work is delegated to Data Source
 */
class RecyclerAdapter(var recyclerDataSource: RecyclerDataSource) :
    RecyclerView.Adapter<RecyclerViewHolder>() {

    init {
        setHasStableIds(true)
        recyclerDataSource.attachToAdapter(this)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerViewHolder =
        RecyclerViewHolder(parent, recyclerDataSource.rendererForType(viewType))

    override fun getItemCount(): Int = recyclerDataSource.getCount()

    override fun onBindViewHolder(holder: RecyclerViewHolder, position: Int) =
        holder.bind(recyclerDataSource.getItem(position))

    override fun getItemViewType(position: Int): Int =
        recyclerDataSource.viewResourceForPosition(position)!!

    override fun getItemId(position: Int): Long = recyclerDataSource.getItem(position).getId()
}