package startupplan.srios.com.poweradapter.item

import android.view.View
import android.view.ViewGroup
import androidx.annotation.LayoutRes

/**
 * Note: Its important to remember that we would have one renderer per renderer key
 * So One renderer may return separate View Instances
 */
interface ItemRenderer<T : RecyclerItem> {

    @LayoutRes
    fun layoutRes():Int

    fun createView(parent:ViewGroup):View

    fun render(itemView: View,item:T)
}