package startupplan.srios.com.poweradapter.adapter

import androidx.annotation.LayoutRes
import androidx.annotation.MainThread
import androidx.annotation.VisibleForTesting
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import startupplan.srios.com.poweradapter.item.ItemRenderer
import startupplan.srios.com.poweradapter.item.RecyclerItem
import java.lang.ref.WeakReference
import javax.inject.Inject

class RecyclerDataSource @Inject constructor(var renders: MutableMap<String, ItemRenderer<out RecyclerItem>>) {

    private val viewTypeToRendererKeyMap = mutableMapOf<Int, String>()
    private var data:ArrayList<RecyclerItem> = arrayListOf()
    private var adapterReference =
        WeakReference<RecyclerView.Adapter<out RecyclerView.ViewHolder>>(null)

    // Initially we have added layoutRes or View (Integer as key) in viewTypeToRendererKeyMap as Key and assigned renderer key as value to
    // the same
    init {
        for (entry in renders.entries) {
            viewTypeToRendererKeyMap[entry.value.layoutRes()] = entry.key
        }
    }

    /**
     * Item Renderer based on the View (Integer)
     */
    fun rendererForType(viewType: Int): ItemRenderer<RecyclerItem> =
        renders[viewTypeToRendererKeyMap[viewType]] as ItemRenderer<RecyclerItem>

    /**
     * This will return the layout resource for a particular position
     * @param position: Will take position as argument to decide the view type
     */
    @LayoutRes
    fun viewResourceForPosition(position: Int) = renders[data[position].renderKey()]?.layoutRes()

    fun getCount() = data.size

    fun getItem(position: Int) = data[position]

    fun attachToAdapter(adapter: RecyclerView.Adapter<out RecyclerView.ViewHolder>) {
        adapterReference = WeakReference(adapter)
    }

    @MainThread
    fun setData(newData : ArrayList<out RecyclerItem>) {
        val diffResult = DiffUtil.calculateDiff(RecyclerDiffCallback(data,newData))
        data.clear()
        data.addAll(newData)
        val adapter = adapterReference.get()
        if (adapter!=null)
            diffResult.dispatchUpdatesTo(adapter)
    }

    /**
     *Allow us to seed data without invoking DiffUtil which would throw an exception during unit testing
     */
    @VisibleForTesting
    fun seedData(data:ArrayList<out RecyclerItem>) {
        this.data.clear()
        this.data = data as ArrayList<RecyclerItem>
    }
}