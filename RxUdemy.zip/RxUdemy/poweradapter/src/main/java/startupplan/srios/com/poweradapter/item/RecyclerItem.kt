package startupplan.srios.com.poweradapter.item

interface RecyclerItem {
    fun getId(): Long
    fun renderKey(): String
}