package com.viceboy.babble.ui.screens.groupDetails

import androidx.recyclerview.widget.DiffUtil
import com.viceboy.babble.R
import com.viceboy.babble.databinding.ItemGroupDetailsPaymentListBinding
import com.viceboy.babble.ui.base.DataBoundStateListAdapter
import com.viceboy.data_repo.model.uiModel.GroupTransactions
import com.viceboy.data_repo.model.uiModel.TransactionLoadState


class PaymentDetailsAdapter :
    DataBoundStateListAdapter<TransactionLoadState, ItemGroupDetailsPaymentListBinding>(
        diffCallback = object : DiffUtil.ItemCallback<TransactionLoadState>() {
            override fun areItemsTheSame(
                oldItem: TransactionLoadState,
                newItem: TransactionLoadState
            ): Boolean =
                if (oldItem is GroupTransactions && newItem is GroupTransactions)
                    oldItem.id == newItem.id
                else
                    false

            override fun areContentsTheSame(
                oldItem: TransactionLoadState,
                newItem: TransactionLoadState
            ): Boolean =
                if (oldItem is GroupTransactions && newItem is GroupTransactions)
                    oldItem.groupId == newItem.groupId && oldItem.amount == newItem.amount
                else
                    false
        }
    ) {
    override val progressLayoutRes: Int = R.layout.layout_progress_data_load
    override val emptyDataLayoutRes: Int = R.layout.layout_no_transactions
    override val dataLayoutRes: Int = R.layout.item_group_details_payment_list

    override fun onSuccessDataBind(
        binding: ItemGroupDetailsPaymentListBinding,
        item: TransactionLoadState
    ) {
        binding.transaction = item as GroupTransactions
    }

}
