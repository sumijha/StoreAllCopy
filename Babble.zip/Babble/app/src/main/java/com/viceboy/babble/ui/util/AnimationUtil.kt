package com.viceboy.babble.ui.util

import android.view.View
import androidx.interpolator.view.animation.LinearOutSlowInInterpolator

object AnimationUtil {

    fun rotateViewInCircularMotion(v: View, startDelay: Long? = null) {
        val delay = startDelay ?: DEFAULT_DELAY
        val orientation = v.rotation - 180f
        v.animate().setStartDelay(delay).rotation(orientation).setDuration(ANIM_SHORT_DURATION)
            .setInterpolator(LinearOutSlowInInterpolator()).start()
    }

    fun hideViewByScale(v: View, startDelay: Long? = null) {
        v.animate().setStartDelay(startDelay ?: DEFAULT_DELAY).setDuration(ANIM_SHORT_DURATION)
            .scaleX(0f).scaleY(0f).withEndAction {
                v.visibility = View.GONE
            }
    }

    private const val DEFAULT_DELAY = 0L
    private const val ANIM_SHORT_DURATION = 300L
    private const val ANIM_LONG_DURATION = 1000L
}