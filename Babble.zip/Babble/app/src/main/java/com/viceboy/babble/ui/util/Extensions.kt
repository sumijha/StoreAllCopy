package com.viceboy.babble.ui.util

import android.animation.Animator
import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.app.Activity
import android.view.View
import android.view.ViewAnimationUtils
import android.view.animation.BounceInterpolator
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.Button
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.MutableLiveData
import com.viceboy.babble.R


fun Activity.setFullScreen() {
    (this as AppCompatActivity).supportActionBar?.hide()
    this.window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN
}

fun View.animateCircularReveal(
    animationDuration: Long,
    animatorListener: Animator.AnimatorListener?
) {
    val width = this.width
    val height = this.height
    val centerX = width / 2
    val centerY = height / 2
    val radius = width.coerceAtLeast(height).toFloat()
    ViewAnimationUtils.createCircularReveal(this, centerX, centerY, radius, 0f).apply {
        duration = animationDuration
        addListener(animatorListener)
        start()
    }
}

fun View.toggleVisibility() = also { view ->
    view.visibility = View.VISIBLE
    val animatorSet = AnimatorSet()
    animatorSet.playTogether(
        ObjectAnimator.ofFloat(view, View.TRANSLATION_Y, -(view.height / 2).toFloat(), 0f),
        ObjectAnimator.ofFloat(view, View.ALPHA, 0f, 1f)
    )
    animatorSet.apply {
        interpolator = DecelerateInterpolator()
        duration = 400
    }
    animatorSet.start()
}

fun View.animateButtonClick(
    enableProgress: MutableLiveData<Boolean>?,
    showAnimation: MutableLiveData<Boolean>?
) = also { view ->
    val textSize = (view as Button).textSizeInDP()
    val buttonWidth = view.width
    val va = ValueAnimator.ofInt(this.width, 0).apply {
        addUpdateListener {
            view.layoutParams.width = it.animatedValue as Int
            view.requestLayout()
        }
    }

    val va1 = ValueAnimator.ofFloat(0f, view.width / 2.toFloat()).apply {
        addUpdateListener {
            view.x = it.animatedValue as Float
            view.requestLayout()
        }
    }

    val val2 = ValueAnimator.ofFloat(textSize, 0f).apply {
        addUpdateListener {
            val currentWidth = view.width
            if (currentWidth < buttonWidth / 2)
                view.textSize = it.animatedValue as Float
            view.requestLayout()
        }
    }

    AnimatorSet().apply {
        duration = 500
        playTogether(va, va1, val2)
        addListener(animationListener({showAnimation?.value = false}, {
            enableProgress?.value = true
        }))
        start()
    }
}

fun ImageView.animateLogo() = also { view ->
    val height = resources.getDimension(R.dimen.login_logo_height)
    val width = resources.getDimension(R.dimen.login_logo_width)
    val animatorHeight = ValueAnimator.ofInt(5, height.toInt()).apply {
        addUpdateListener {
            view.layoutParams.height = it.animatedValue as Int
            view.requestLayout()
        }
    }

    val animatorWidth = ValueAnimator.ofInt(5, width.toInt()).apply {
        addUpdateListener {
            view.layoutParams.width = it.animatedValue as Int
            view.requestLayout()
        }
    }

    val animatorRotate = ValueAnimator.ofFloat(-90f,0f).apply {
        addUpdateListener {
            view.rotation = it.animatedValue as Float

        }
    }

    AnimatorSet().apply {
        duration = 800
        interpolator = BounceInterpolator()
        playTogether(animatorHeight, animatorWidth,animatorRotate)
        start()
    }
}

fun Button.textSizeInDP() = this.textSize / resources.displayMetrics.scaledDensity

private fun animationListener(
    onAnimationStart: () -> Unit,
    onAnimationEnd: () -> Unit
): Animator.AnimatorListener {
    return object : Animator.AnimatorListener {
        override fun onAnimationRepeat(animation: Animator?) {}

        override fun onAnimationEnd(animation: Animator?) {
            onAnimationEnd.invoke()
        }

        override fun onAnimationCancel(animation: Animator?) {}

        override fun onAnimationStart(animation: Animator?) {
            onAnimationStart.invoke()
        }
    }
}