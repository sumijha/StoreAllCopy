package com.viceboy.babble

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import com.viceboy.babble.ui.base.HasSplashScreen

abstract class BaseFragment : Fragment() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (this is HasSplashScreen) {
            (this.activity as AppCompatActivity).supportActionBar?.hide()
            this.addSplashView()
        }
    }
}
