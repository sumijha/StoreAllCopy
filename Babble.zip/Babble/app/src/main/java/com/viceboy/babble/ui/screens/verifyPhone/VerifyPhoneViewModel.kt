package com.viceboy.babble.ui.screens.verifyPhone

import androidx.lifecycle.*
import com.google.android.material.textfield.TextInputEditText
import com.jakewharton.rxbinding3.widget.textChanges
import com.viceboy.babble.ui.base.BaseViewModel
import com.viceboy.babble.ui.base.PhoneAuthProvider
import com.viceboy.babble.ui.state.ButtonState
import com.viceboy.babble.ui.state.OtpVerificationState
import com.viceboy.babble.ui.util.isMobileNoPattern
import com.viceboy.babble.ui.util.observeOnMainThread
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import timber.log.Timber
import java.util.concurrent.TimeUnit
import javax.inject.Inject

open class VerifyPhoneViewModel @Inject constructor(private val phoneAuthProvider: PhoneAuthProvider) :
    BaseViewModel<Int>() {

    private val progressContext = viewModelScope.coroutineContext + Dispatchers.Main

    private lateinit var phoneNumber: String

    /**
     * Mutable LiveDATA to send text to TextView
     */
    private val mutablePhoneNumberTextLiveData = MutableLiveData<String>()
    val phoneNumberTextLiveData: LiveData<String>
        get() = mutablePhoneNumberTextLiveData

    /**
     * Mutable LiveData to show resend SMS text link to request OTP again
     */
    private val mutableResendOtpTextLiveData = MutableLiveData<Boolean>()
    val resendOtpTextLiveData: LiveData<Boolean>
        get() = mutableResendOtpTextLiveData

    /**
     * Setting up Mutable LiveData to manage Phone Auth Provider LOADING, SUCCESS or FAILURE state
     */
    private val _mutablePhoneAuthManagerLiveData = MutableLiveData<OtpVerificationState<Any>>()
    val phoneAuthProviderLiveData: LiveData<OtpVerificationState<Any>>
        get() = _mutablePhoneAuthManagerLiveData

    /**
     * GetOtp Button MediatorLiveData to manage its state
     */
    private val mediatorGetOtpButtonStateManagerLiveData = MediatorLiveData<ButtonState>()
    val getOtpButtonStateManagerLiveData: LiveData<ButtonState>
        get() = mediatorGetOtpButtonStateManagerLiveData

    /**
     * Verify & SignUP Button MediatorLiveData to manage its state
     */
    private val mediatorVerifyOtpButtonStateManagerLiveData = MediatorLiveData<ButtonState>()
    val verifyOtpButtonStateManagerLiveData: LiveData<ButtonState>
        get() = mediatorVerifyOtpButtonStateManagerLiveData

    /**
     * Setting up Mutable LiveData to show Otp Progress Timer
     */
    private val mediatorEnableOtpProgressTimer = MediatorLiveData<Boolean>()
    val enableOtpProgressTimerLiveData: LiveData<Boolean>
        get() = mediatorEnableOtpProgressTimer


    /**
     * Setting up RxObservable to check phone number text changes
     */
    fun initTextChanges(textView: TextInputEditText) {
        compositeDisposable.add(
            textView.textChanges()
                .debounce(100, TimeUnit.MILLISECONDS)
                .observeOnMainThread()
                .subscribe({
                    phoneNumber = it.toString().split(" ")[1]
                    if (phoneNumber.isMobileNoPattern()) {
                        mutablePhoneNumberTextLiveData.value = it.toString()
                        mediatorGetOtpButtonStateManagerLiveData.value = ButtonState.ACTIVE
                    } else
                        mediatorGetOtpButtonStateManagerLiveData.value = ButtonState.DISABLE
                }, {
                    //TODO: Remove Junk Code
                    phoneNumber = "9877627323"
                    Timber.e(it.message)
                    mutablePhoneNumberTextLiveData.value = it.toString()
                    mediatorGetOtpButtonStateManagerLiveData.value = ButtonState.ACTIVE
                })
        )
    }

    /**
     * Method is called when GetOtp Button is clicked
     */
    fun onGetOtpButtonClicked() {
        onButtonClick(mediatorGetOtpButtonStateManagerLiveData)
    }

    /**
     * Method is called when GetOtp Button is clicked
     */
    fun onVerifyOtpButtonClicked() {
        onButtonClick(mediatorVerifyOtpButtonStateManagerLiveData)
    }

    /**
     * Add Sources to GetOtpButtonStateManagerLiveData
     */
    private fun addSourcesToGenerateOtpButtonMediatorLiveData() {
        mediatorGetOtpButtonStateManagerLiveData.apply {
            addSource(mediatorGetOtpButtonStateManagerLiveData) {
                if (it == ButtonState.INVISIBLE) {
                    requestOtp()
                }
            }

            addSource(_mutablePhoneAuthManagerLiveData) {
                if (it is OtpVerificationState.Failed) {
                    resetAnimationState()
                    value = ButtonState.ACTIVE
                }
            }

            addSource(onGenerateOtpAnimationEndLiveData) {
                value = if (it)
                    ButtonState.INVISIBLE
                else
                    ButtonState.ANIMATING
            }
        }
    }

    /**
     * Add Sources to ShowOtpProgressTimer MediatorLiveData to enable and disable progress
     */
    private fun addSourcesToShowOtpTimerMediatorLiveData() {
        mediatorEnableOtpProgressTimer.apply {
            addSource(_mutablePhoneAuthManagerLiveData) {
                value = it is OtpVerificationState.Loading
            }

            addSource(progressLiveData) {
                if (it == 60)
                    value = false
            }
        }
    }

    /**
     * Add Sources to verify Otp MediatorLiveData
     */
    private fun addSourcesToVerifyOtpButtonMediatorLiveData() {
        mediatorVerifyOtpButtonStateManagerLiveData.apply {
            addSource(_mutablePhoneAuthManagerLiveData) {
                if (it is OtpVerificationState.Sent)
                    value = ButtonState.ACTIVE
            }

            addSource(mediatorGetOtpButtonStateManagerLiveData) {
                value = if (it == ButtonState.INVISIBLE)
                    ButtonState.DISABLE
                else
                    ButtonState.INVISIBLE
            }
        }
    }

    /**
     * Setting up LiveDATA to show timer count and set progress on OTP Progress Timer
     */
    val progressLiveData = Transformations.switchMap(mediatorEnableOtpProgressTimer) {
        if (it) {
            mutableResendOtpTextLiveData.value = false
            liveData(progressContext) {
                for (i in 1..60) {
                    delay(1000)
                    emit(i)
                }
                mediatorEnableOtpProgressTimer.value = false
                mutableResendOtpTextLiveData.value = true
            }
        } else {
            liveData { }
        }
    }

    val showErrorMsgLiveData: LiveData<Boolean> =
        Transformations.map(_mutablePhoneAuthManagerLiveData) {
            it is OtpVerificationState.Failed
        }

    fun requestOtp() {
        _mutablePhoneAuthManagerLiveData.value = OtpVerificationState.Loading()
        compositeDisposable.add(
            phoneAuthProvider.authenticateUser(phoneNumber).subscribe(
                { data ->
                    _mutablePhoneAuthManagerLiveData.value =
                        OtpVerificationState.Sent(data)
                },
                { throwable ->
                    _mutablePhoneAuthManagerLiveData.value =
                        OtpVerificationState.Failed<Throwable>(throwable.message)
                },
                {
                    _mutablePhoneAuthManagerLiveData.value =
                        OtpVerificationState.Verified(null)
                })
        )
    }

    /**
     * Setting up generateOtp Click Animation Listener
     */
    private val onGenerateOtpAnimationEndLiveData = MutableLiveData<Boolean>(false)
    val getOtpButtonAnimatorListener = getAnimatorListenerObject(
        {onGenerateOtpAnimationEndLiveData.value = true},
        {onGenerateOtpAnimationEndLiveData.value = false}
    )

    /**
     * Setting up verifyOtp Click Animation Listener
     */
    private val onVerifyOtpAnimationEndLiveData = MutableLiveData<Boolean>(false)
    val verifyOtpButtonAnimatorListener = getAnimatorListenerObject(
        {onVerifyOtpAnimationEndLiveData.value = true},
        {onVerifyOtpAnimationEndLiveData.value = false}
    )

    init {
        addSourcesToGenerateOtpButtonMediatorLiveData()
        addSourcesToShowOtpTimerMediatorLiveData()
        addSourcesToVerifyOtpButtonMediatorLiveData()
    }

    override fun onCleared() {
        dispose()
        super.onCleared()
    }
}
