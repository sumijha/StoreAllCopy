package com.viceboy.babble.ui.screens.verifyPhone

import android.widget.TextView
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.google.android.material.textfield.TextInputEditText
import com.jakewharton.rxbinding3.widget.textChanges
import com.viceboy.babble.ui.base.BaseViewModel
import com.viceboy.babble.ui.util.isMobileNoPattern
import io.reactivex.android.schedulers.AndroidSchedulers
import java.util.concurrent.TimeUnit
import javax.inject.Inject

class VerifyPhoneViewModel @Inject constructor() : BaseViewModel<Int>() {

    private val _mutableEnableButtonLiveData = MutableLiveData<Boolean>(false)
    val enableButtonLiveData: LiveData<Boolean>
        get() = _mutableEnableButtonLiveData

    fun initTextChanges(textView: TextInputEditText) {
        compositeDisposable.add(
            textView.textChanges()
                .debounce(500, TimeUnit.MILLISECONDS)
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe {
                    _mutableEnableButtonLiveData.value = it.toString().isMobileNoPattern()
                }
        )
    }

    override fun onCleared() {
        dispose()
        super.onCleared()
    }
}