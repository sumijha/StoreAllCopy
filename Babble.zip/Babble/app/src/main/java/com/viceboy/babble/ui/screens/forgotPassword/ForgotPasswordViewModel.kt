package com.viceboy.babble.ui.screens.forgotPassword

import com.viceboy.babble.ui.base.BaseViewModel

class ForgotPasswordViewModel : BaseViewModel<Boolean>() {

}