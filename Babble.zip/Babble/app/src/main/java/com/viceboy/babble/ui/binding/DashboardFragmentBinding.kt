package com.viceboy.babble.ui.binding

import android.view.View
import android.view.animation.AnimationUtils
import androidx.databinding.BindingAdapter
import com.viceboy.babble.R

object DashboardFragmentBinding {

    @JvmStatic
    @BindingAdapter("animatorType", "animeFab")
    fun setFabAnimator(view: View, animatorType: String, animeFab: Boolean) {
        val animFabOpen = AnimationUtils.loadAnimation(view.context, R.anim.fab_menu_open)
        val animFabClose = AnimationUtils.loadAnimation(view.context, R.anim.fab_menu_close)
        val animFabRotate = AnimationUtils.loadAnimation(view.context, R.anim.fab_rotate_clock)
        val animFabRotateAnti =
            AnimationUtils.loadAnimation(view.context, R.anim.fab_rotate_anticlock)

        if (animeFab)
            when (animatorType) {
                "rotateClock" -> view.startAnimation(animFabRotate)

                "rotateAntiClock" -> view.startAnimation(animFabRotateAnti)

                "open" -> {
                    view.visibility = View.VISIBLE
                    view.startAnimation(animFabOpen)
                }

                "close" -> {
                    view.visibility = View.INVISIBLE
                    view.startAnimation(animFabClose)
                }
            }
    }
}