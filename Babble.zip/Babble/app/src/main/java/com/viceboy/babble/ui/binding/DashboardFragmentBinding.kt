package com.viceboy.babble.ui.binding

import android.view.View
import android.view.animation.AnimationUtils
import androidx.appcompat.widget.Toolbar
import androidx.appcompat.widget.Toolbar.OnMenuItemClickListener
import androidx.databinding.BindingAdapter
import com.google.android.material.appbar.AppBarLayout
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.viceboy.babble.R

object DashboardFragmentBinding {

    @JvmStatic
    @BindingAdapter("animatorType", "animeFab")
    fun setFabAnimator(view: View, animatorType: String, animeFab: Boolean) {
        val animFabOpen = AnimationUtils.loadAnimation(view.context, R.anim.fab_menu_open)
        val animFabClose = AnimationUtils.loadAnimation(view.context, R.anim.fab_menu_close)
        val animFabRotate = AnimationUtils.loadAnimation(view.context, R.anim.fab_rotate_clock)
        val animFabRotateAnti =
            AnimationUtils.loadAnimation(view.context, R.anim.fab_rotate_anticlock)

        if (animeFab)
            when (animatorType) {
                "rotateClock" -> view.post { view.startAnimation(animFabRotate) }

                "rotateAntiClock" -> view.post { view.startAnimation(animFabRotateAnti) }

                "open" -> {
                    view.visibility = View.VISIBLE
                    view.startAnimation(animFabOpen)
                }

                "close" -> {
                    view.visibility = View.INVISIBLE
                    view.startAnimation(animFabClose)
                }
            }
    }

    @JvmStatic
    @BindingAdapter("onMenuItemListener")
    fun setMenuItemListener(view: View, listener: OnMenuItemClickListener) {
        (view as Toolbar).setOnMenuItemClickListener(listener)
    }

    @JvmStatic
    @BindingAdapter("offSetChangeListener")
    fun setAppBarOffsetChangeListener(view: View, listener: AppBarLayout.OnOffsetChangedListener) {
        (view as AppBarLayout).addOnOffsetChangedListener(listener)
    }

    @JvmStatic
    @BindingAdapter("bottomSheetCallback")
    fun setBottomSheetCallback(
        view: View,
        bottomSheetCallback: BottomSheetBehavior.BottomSheetCallback
    ) {
        val bottomSheetBehavior = BottomSheetBehavior.from(view)
        bottomSheetBehavior.setBottomSheetCallback(bottomSheetCallback)
    }

    @JvmStatic
    @BindingAdapter("onFabMenuOpenedTouchListener")
    fun setFabMenuTouchListener(view: View, listener: View.OnTouchListener) {
        view.setOnTouchListener(listener)
    }
}