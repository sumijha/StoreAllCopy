package com.viceboy.babble.ui.base

import io.reactivex.Completable

interface AuthProvider {
    fun authenticateUser(username:String,password:String):Completable
}