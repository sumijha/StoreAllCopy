package com.viceboy.babble.ui.base

import io.reactivex.Completable
import io.reactivex.Observable

interface AuthProvider {
    fun authenticateUser(username:String,password:String):Completable
}

interface PhoneAuthProvider {
    fun authenticateUser(phoneNumber:String) : Observable<String>
    fun verifyOtp(receivedOtp:String,expectedOtp:String):Boolean
}