package com.viceboy.babble.ui.util

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import androidx.core.net.toUri
import androidx.exifinterface.media.ExifInterface
import timber.log.Timber
import java.io.*
import java.nio.ByteBuffer

object ImageUtil {

    fun compressImage(context: Context, file: File): File {
        val b: Bitmap?

        Timber.e("Original Image size is ${file.length()}")
        //Decode with inSample size
        val o2 = BitmapFactory.Options()
        o2.inSampleSize = 1

        val fis = FileInputStream(file)
        b = BitmapFactory.decodeStream(fis, null, o2)
        fis.close()

        // val decodeNewBitmap = decodeBitmap(b!!.convertToByteArray(),file.toUri(),1000,1000,orientation)
        val out = ByteArrayOutputStream()
        val newOut = ByteArrayOutputStream()
        try {
            b?.compress(Bitmap.CompressFormat.JPEG, 100, out)
        } catch (e: Exception) {
            Timber.e(e.message)
        }
        val decodedBitmap = decodeBitmap(out.toByteArray(), file.toUri(), 1000, 1000)
        try {
            decodedBitmap.compress(Bitmap.CompressFormat.JPEG, 100, newOut)
        } catch (e: Exception) {
            Timber.e(e.message)
        }

        val destFile = File(context.cacheDir, file.name)
        destFile.createNewFile()
        FileOutputStream(destFile).apply {
            write(newOut.toByteArray())
            flush()
            close()
        }

        if (destFile.length() >= file.length())
            return file

        Timber.e("Compressed Image size is ${destFile.length()}")
        return destFile
    }

    @Suppress("SameParameterValue")
    private fun decodeBitmap(
        source: ByteArray,
        uri: Uri,
        maxWidth: Int,
        maxHeight: Int
    ): Bitmap {
        var bitmap: Bitmap
        var orientation = 0
        try {
            val exif = ExifInterface(uri.path!!)
            val exifOrientation: Int = exif.getAttributeInt(
                ExifInterface.TAG_ORIENTATION,
                ExifInterface.ORIENTATION_NORMAL
            )
            when (exifOrientation) {
                ExifInterface.ORIENTATION_NORMAL -> Unit
                ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> orientation = 0
                ExifInterface.ORIENTATION_ROTATE_180 -> Unit
                ExifInterface.ORIENTATION_FLIP_VERTICAL -> orientation = 180
                ExifInterface.ORIENTATION_ROTATE_90 -> orientation = 90
                ExifInterface.ORIENTATION_TRANSPOSE -> orientation = 90
                ExifInterface.ORIENTATION_ROTATE_270 -> Unit
                ExifInterface.ORIENTATION_TRANSVERSE -> orientation = 270
            }

        } catch (e: IOException) {
            e.printStackTrace()
            orientation = 0
        }

        if (maxWidth < Int.MAX_VALUE || maxHeight < Int.MAX_VALUE) {
            val options = BitmapFactory.Options()
            options.inJustDecodeBounds = true
            BitmapFactory.decodeByteArray(source, 0, source.size, options)

            var outHeight = options.outHeight
            var outWidth = options.outWidth
            if (orientation % 180 != 0) {
                outHeight = options.outWidth
                outWidth = options.outHeight
            }
            options.inSampleSize = computeSampleSize(outWidth, outHeight, maxWidth, maxHeight)
            options.inJustDecodeBounds = false
            bitmap = BitmapFactory.decodeByteArray(source, 0, source.size, options)
        } else {
            bitmap = BitmapFactory.decodeByteArray(source, 0, source.size)
        }

        Matrix().apply {
            setRotate(orientation.toFloat())
            val temp = bitmap
            bitmap = Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, this, false)
            temp.recycle()
        }

        return bitmap
    }

    private fun computeSampleSize(
        outWidth: Int,
        outHeight: Int,
        maxWidth: Int,
        maxHeight: Int
    ): Int {
        var sampleSize = 1
        if (outHeight > maxHeight || outWidth > maxWidth) {
            while ((outHeight / sampleSize >= maxHeight)
                || (outWidth / sampleSize >= maxWidth)
            ) {
                sampleSize *= 2
            }
        }
        return sampleSize
    }

    /**
     * Convert bitmap to byte array using ByteBuffer.
     */
    fun Bitmap.convertToByteArray(): ByteArray {
        //minimum number of bytes that can be used to store this bitmap's pixels
        val size = this.byteCount

        //allocate new instances which will hold bitmap
        val buffer = ByteBuffer.allocate(size)
        val bytes = ByteArray(size)

        //copy the bitmap's pixels into the specified buffer
        this.copyPixelsToBuffer(buffer)

        //rewinds buffer (buffer position is set to zero and the mark is discarded)
        buffer.rewind()

        //transfer bytes from buffer into the given destination array
        buffer.get(bytes)

        //return bitmap's pixels
        return bytes
    }

}