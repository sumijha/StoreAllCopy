package com.viceboy.babble.ui.screens.signup

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.Fragment
import com.viceboy.babble.R
import com.viceboy.babble.databinding.FragmentSignupBinding
import com.viceboy.babble.di.Injectable
import kotlinx.android.synthetic.main.fragment_signup.view.*


class SignupFragment : Fragment(), Injectable {

    private lateinit var dataBinding: FragmentSignupBinding
    private lateinit var arrayCodes: Array<String>
    private lateinit var countryAdapter: ArrayAdapter<String>


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        dataBinding =
            DataBindingUtil.inflate(inflater, R.layout.fragment_signup, container, false)
        return dataBinding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        dataBinding.startAnimation = true
        arrayCodes = resources.getStringArray(R.array.country_arrays)
        countryAdapter = CountryCodeAdapter(
            context!!, android.R.layout.simple_list_item_1,
            arrayCodes.toList() as ArrayList<String>
        )
        //TODO:Fix this using Databinding
        view.autoTextViewCcp.setAdapter(countryAdapter)
       // view.autoTextViewCcp.threshold = 1
       /* view.btn_signup.setOnClickListener {
            it.animateButtonClick()
        }*/
    }
}
