package com.viceboy.babble.ui.screens.captureExpense


import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup

import com.viceboy.babble.R

/**
 * A simple [Fragment] subclass.
 */
class CaptureExpense : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_capture_expense, container, false)
    }


}
