package com.viceboy.babble.ui.screens.groupDetails

import com.viceboy.babble.ui.base.BaseViewModel
import javax.inject.Inject

class GroupDetailsViewModel @Inject constructor(): BaseViewModel<Boolean>() {
    // TODO: Implement the ViewModel
}
