package com.viceboy.babble.ui.util

object Constants {
    const val KEY_IMAGE_REQUEST_CODE = 100
    const val KEY_FROM_CAPTURE_FRAGMENT = "capture_fragment"
}