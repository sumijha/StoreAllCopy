@file:Suppress("IMPLICIT_CAST_TO_ANY")

package com.viceboy.babble.ui.binding

import android.view.View
import androidx.databinding.BindingAdapter
import com.google.android.material.textfield.TextInputEditText
import com.viceboy.babble.ui.util.animateButtonClick

object SignUpFragmentBindingAdapter {

    @JvmStatic
    @BindingAdapter("fieldType", "fieldName", "checkFlag", requireAll = false)
    fun setFieldValidation(
        view: View,
        fieldType: String,
        fieldName: String,
        checkFlag: Boolean
    ) {
        checkFlag.let {
            if (it && fieldType.contentEquals("required")) {
                val inputValue = (view as TextInputEditText).text.toString()
                val errorText = if (inputValue.isEmpty()) {
                    "$fieldName is a required field"
                } else {
                    when (fieldName) {
                        "Mobile Number" -> {
                            if (inputValue.length < 4)
                                "Invalid Mobile Number entered"
                            else null
                        }

                        "Email" -> {
                            if (inputValue.length < 4 || !inputValue.contains("@"))
                                "Invalid Email Address entered"
                            else null
                        }

                        "Password" -> {
                            if (inputValue.length < 5)
                                "Password length should be greater than 5 digits"
                            else null
                        }
                        else -> null
                    }
                }
                view.error = errorText
            }
        }
    }

    @JvmStatic
    @BindingAdapter("onClickWithValidFields")
    fun setActionOnSignUpClickWithValidFields(view: View,flag:Boolean) {
        if (flag)
            view.animateButtonClick()
    }
}