package com.viceboy.babble.ui.binding

import android.view.View
import android.view.ViewGroup
import android.widget.AutoCompleteTextView
import androidx.databinding.BindingAdapter
import androidx.interpolator.view.animation.FastOutSlowInInterpolator
import androidx.interpolator.view.animation.LinearOutSlowInInterpolator
import androidx.transition.Fade
import androidx.transition.TransitionManager
import com.viceboy.babble.R
import com.viceboy.babble.ui.screens.signup.CountryCodeAdapter
import kotlinx.android.synthetic.main.fragment_signup.view.*

object SignUpFragmentBindingAdapter {

    @JvmStatic
    @BindingAdapter("isVisibleFlag")
    fun animateVisibility(view: View, flag: Boolean) {
        if (flag) {
            TransitionManager.beginDelayedTransition(
                view.parent as ViewGroup,
                Fade().apply {
                    startDelay = 200
                    duration = 500
                    interpolator = LinearOutSlowInInterpolator()
                }
            )
            view.visibility = View.VISIBLE
        }
    }

    @JvmStatic
    @BindingAdapter("setAdapter")
    fun setAutoCompleteTextViewAdapter(view: AutoCompleteTextView,arrayCodes:ArrayList<String>) {
        val countryAdapter = CountryCodeAdapter(
            view.context!!, android.R.layout.simple_list_item_1,
            arrayCodes
        )
        view.setAdapter(countryAdapter)
    }
}