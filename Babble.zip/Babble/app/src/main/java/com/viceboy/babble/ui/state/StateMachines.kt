package com.viceboy.babble.ui.state

sealed class Resource<out T> {
    class Loading<out T> : Resource<T>()
    data class Success<out T>(val data: T?) : Resource<T>()
    data class Failure<out T>(val message: String?) : Resource<T>()
}

sealed class OtpVerificationState<out T> {
    class Loading<out T> : OtpVerificationState<T>()
    data class Sent<out T>(val data: String) : OtpVerificationState<T>()
    data class Verified<out T>(val data: T?) : OtpVerificationState<T>()
    data class Failed<out T>(val message: String?) : OtpVerificationState<T>()
}

/**
 * Enum Class to manage button state
 */
enum class ButtonState {
    DISABLE, ACTIVE, CLICKED, ANIMATING, INVISIBLE
}
