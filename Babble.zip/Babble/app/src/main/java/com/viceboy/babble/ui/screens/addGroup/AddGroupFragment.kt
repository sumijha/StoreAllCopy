package com.viceboy.babble.ui.screens.addGroup

import android.os.Bundle
import android.view.View
import android.widget.TextView
import android.widget.Toast
import androidx.lifecycle.Observer
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.mynameismidori.currencypicker.CurrencyPicker
import com.viceboy.babble.R
import com.viceboy.babble.databinding.FragmentAddGroupBinding
import com.viceboy.babble.di.Injectable
import com.viceboy.babble.ui.base.BaseFragment
import com.viceboy.babble.ui.state.Resource
import com.viceboy.babble.ui.state.SearchState
import com.viceboy.babble.ui.util.toEditable
import com.viceboy.babble.ui.util.toggleBottomNavVisibility


class AddGroupFragment : BaseFragment<AddGroupViewModel, FragmentAddGroupBinding>(), Injectable {

    private val emptyString = ""

    private var currentSearchState: SearchState? = null

    private lateinit var bottomNavigationView: BottomNavigationView
    private lateinit var onAddParticipantsFocusText: String
    private lateinit var onAddParticipantsFocusLostText: String
    private lateinit var participantEmail: String

    override fun layoutRes(): Int = R.layout.fragment_add_group

    override fun onCreateView() = Unit

    override val viewModelClass: Class<AddGroupViewModel> = AddGroupViewModel::class.java

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        initAddParticipantsFocusChangeHintText()
        setUpBottomNavVisibility()
        setUpAddParticipantsFocusChangeListener()
        setUpBinding()
        setUpCurrencyPicker()
        super.onViewCreated(view, savedInstanceState)
    }

    override fun onDestroy() {
        showBottomNavigation()
        super.onDestroy()
    }

    override fun observeLiveData(viewModel: AddGroupViewModel, binding: FragmentAddGroupBinding) {
        viewModel.mutableSearchParticipantsTextLiveData.observe(viewLifecycleOwner, Observer {
            participantEmail = it ?: emptyString
        })

        viewModel.listOfCheckedEventLiveData.observe(viewLifecycleOwner, Observer {
            when (it) {
                is Resource.Loading -> viewModel.setSearchState(SearchState.IN_PROGRESS)

                is Resource.Success -> {
                    binding.etAddParticipants.text = it.data?.name?.toEditable()
                    viewModel.setSearchState(SearchState.SUCCESS)
                }

                is Resource.Failure -> {
                    Toast.makeText(requireContext(), "${it.message}", Toast.LENGTH_SHORT).show()
                    viewModel.setSearchState(SearchState.FAILED)
                }
            }
            viewModel.resetSearchClickEvent()
        })

        viewModel.searchStateLiveData.observe(viewLifecycleOwner, Observer {
            currentSearchState = it
        })

        viewModel.mutableSearchParticipantsTextLiveData.observe(viewLifecycleOwner, Observer {
            currentSearchState?.let {searchState ->
                if (searchState == SearchState.SUCCESS) {
                    viewModel.resetSearchClickEvent()
                    viewModel.resetSearchStateEventLiveData()
                }
            }
        })
    }

    private fun initAddParticipantsFocusChangeHintText() {
        onAddParticipantsFocusText =
            requireContext().resources.getString(R.string.search_by_email)
        onAddParticipantsFocusLostText =
            requireContext().resources.getString(R.string.add_participants)
    }

    private fun setUpBinding() {
        binding.apply {
            lifecycleOwner = viewLifecycleOwner
            presenter = this@AddGroupFragment
            addGroupViewModel = viewModel
        }
    }

    private fun setUpAddParticipantsFocusChangeListener() {
        binding.etAddParticipants.setOnFocusChangeListener { _, hasFocus ->
            if (hasFocus)
                binding.etAddParticipants.hint = onAddParticipantsFocusText
            else
                binding.etAddParticipants.hint = onAddParticipantsFocusLostText
        }
    }

    private fun setUpBottomNavVisibility() {
        bottomNavigationView = requireActivity().findViewById(R.id.bottom_nav)
        if (bottomNavigationView.visibility == View.VISIBLE)
            bottomNavigationView.visibility = View.GONE
    }

    // Show bottom navigation when view is destroyed depending on previous screen
    private fun showBottomNavigation() {
        bottomNavigationView.toggleBottomNavVisibility(
            View.VISIBLE,
            bottomNavigationView
        )
    }

    private fun setUpCurrencyPicker() {
        binding.tvSelectCurrency.setOnClickListener {
            onCurrencyPickerClick(it as TextView, binding.tvCurrency, binding.tvCurrencySymbol)
        }
    }

    private fun onCurrencyPickerClick(
        currencyNameView: TextView,
        currencyCodeView: TextView,
        currencySymbolView: TextView
    ) {
        val title = "Select Currency"
        val picker = CurrencyPicker.newInstance(title)

        picker.setListener { name, code, symbol, _ ->
            currencyNameView.text = name
            currencyCodeView.text = code
            if (code == "INR")
                currencySymbolView.text = resources.getString(R.string.ruppee)
            else
                currencySymbolView.text = symbol
            picker.dismiss()
        }

        picker.show(requireFragmentManager(), "CURRENCY_PICKER")
    }
}
