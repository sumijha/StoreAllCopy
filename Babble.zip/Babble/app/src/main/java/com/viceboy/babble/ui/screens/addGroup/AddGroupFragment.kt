package com.viceboy.babble.ui.screens.addGroup

import android.os.Bundle
import android.view.View
import android.widget.TextView
import com.mynameismidori.currencypicker.CurrencyPicker
import com.viceboy.babble.R
import com.viceboy.babble.databinding.FragmentAddGroupBinding
import com.viceboy.babble.di.Injectable
import com.viceboy.babble.ui.base.BaseFragment


class AddGroupFragment : BaseFragment<AddGroupViewModel, FragmentAddGroupBinding>(), Injectable {

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.tvSelectCurrency.setOnClickListener {
            onCurrencyPickerClick(it as TextView, binding.tvCurrency, binding.tvCurrencySymbol)
        }
    }

    override fun observeLiveData(viewModel: AddGroupViewModel, binding: FragmentAddGroupBinding) {
        //TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }

    private fun onCurrencyPickerClick(
        currencyNameView: TextView,
        currencyCodeView: TextView,
        currencySymbolView: TextView
    ) {
        val picker = CurrencyPicker.newInstance("Select Currency")

        picker.setListener { name, code, symbol, _ ->
            currencyNameView.text = name
            currencyCodeView.text = code
            if (code == "INR")
                currencySymbolView.text = resources.getString(R.string.ruppee)
            else
                currencySymbolView.text = symbol
            picker.dismiss()
        }

        picker.show(activity?.supportFragmentManager!!, "CURRENCY_PICKER")
    }

    override fun layoutRes(): Int = R.layout.fragment_add_group

    override fun onCreateView() = Unit

    override val viewModelClass: Class<AddGroupViewModel> = AddGroupViewModel::class.java
}
