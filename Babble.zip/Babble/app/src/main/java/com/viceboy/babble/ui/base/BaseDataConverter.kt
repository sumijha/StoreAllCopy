package com.viceboy.babble.ui.base

interface BaseDataConverter<IN, OUT> {
    fun convertInToOut(inObject: IN): OUT
    fun convertOutToIn(outObject: OUT): IN
    fun convertListInToOut(inObjects: List<IN>): List<OUT>
    fun convertListOutToIn(outObjects: List<OUT>): List<IN>
}

abstract class BaseDataConverterImpl<IN, OUT> : BaseDataConverter<IN, OUT> {
    override fun convertInToOut(inObject: IN): OUT = processConversionFromInToOut(inObject)

    override fun convertOutToIn(outObject: OUT): IN = processConversionFromOutToIn(outObject)

    override fun convertListInToOut(inObjects: List<IN>): List<OUT> =
        inObjects.map { processConversionFromInToOut(it) }

    override fun convertListOutToIn(outObjects: List<OUT>): List<IN> =
        outObjects.map { processConversionFromOutToIn(it) }


    protected abstract fun processConversionFromInToOut(inObject: IN): OUT

    protected abstract fun processConversionFromOutToIn(inObject: OUT): IN
}