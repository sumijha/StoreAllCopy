package com.viceboy.babble.ui.screens.forgotPassword

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.animation.AlphaAnimation
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.widget.Toolbar
import androidx.coordinatorlayout.widget.CoordinatorLayout
import androidx.fragment.app.Fragment
import com.google.android.material.appbar.AppBarLayout
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.viceboy.babble.R
import com.viceboy.babble.databinding.FragmentForgotPasswordBinding
import com.viceboy.babble.ui.custom.CustomAvatarSwipeBehavior
import com.viceboy.babble.ui.dialog.DashboardBottomSheet
import kotlinx.android.synthetic.main.bottomsheet_dashboard_transactions.view.*
import kotlinx.android.synthetic.main.fragment_dashboard.*
import kotlinx.android.synthetic.main.fragment_dashboard.view.*
import kotlin.math.abs

class ForgotPasswordFragment : Fragment(), AppBarLayout.OnOffsetChangedListener {

    private lateinit var dataBinding: FragmentForgotPasswordBinding
    private lateinit var btnToolbarDetails: Button
    private lateinit var toolbarMain: Toolbar
    private lateinit var textUsername: TextView
    private lateinit var bottomSheet: LinearLayout
    private lateinit var bottomSheetBehavior: BottomSheetBehavior<LinearLayout>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setHasOptionsMenu(true)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        /*dataBinding = DataBindingUtil.inflate(inflater,R.layout.fragment_forgot_password,container,false)
        return dataBinding.root*/
        return inflater.inflate(R.layout.fragment_dashboard, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        textUsername = view.tvToolbar_username
        btnToolbarDetails = view.btnToolbar_viewDetails
        toolbarMain = view.toolbar_dashboard
        toolbarMain.inflateMenu(R.menu.dashboard_menu)
        toolbarMain.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                R.id.profile_menu -> {
                    Toast.makeText(context, "Profile clicked", Toast.LENGTH_SHORT).show()
                }
                else -> Toast.makeText(context, "Profile clicked", Toast.LENGTH_SHORT).show()
            }
            return@setOnMenuItemClickListener true
        }
       /* bottomSheet = view.layout_bottom_transactions as LinearLayout
        bottomSheetBehavior = BottomSheetBehavior.from(bottomSheet)
        bottomSheetBehavior.state = BottomSheetBehavior.STATE_EXPANDED
        bottomSheetBehavior.setBottomSheetCallback(object :
            BottomSheetBehavior.BottomSheetCallback() {
            override fun onSlide(p0: View, p1: Float) {
            }

            override fun onStateChanged(p0: View, p1: Int) {
                when (p1) {
                    BottomSheetBehavior.STATE_HIDDEN -> Toast.makeText(context,"HIDDEN",Toast.LENGTH_SHORT).show()

                    BottomSheetBehavior.STATE_COLLAPSED -> Toast.makeText(context,"COLLAPSED",Toast.LENGTH_SHORT).show()

                    BottomSheetBehavior.STATE_HALF_EXPANDED -> Toast.makeText(context,"STATE_HALF",Toast.LENGTH_SHORT).show()

                    BottomSheetBehavior.STATE_SETTLING -> Toast.makeText(context,"SETTLING",Toast.LENGTH_SHORT).show()

                    BottomSheetBehavior.STATE_DRAGGING -> Toast.makeText(context,"DRAGGING",Toast.LENGTH_SHORT).show()

                    BottomSheetBehavior.STATE_EXPANDED -> Toast.makeText(context,"EXPANDED",Toast.LENGTH_SHORT).show()
                }
            }

        })*/

        val coordinatorParams = civProfilePhoto.layoutParams as CoordinatorLayout.LayoutParams
        coordinatorParams.behavior = CustomAvatarSwipeBehavior(context!!)
        initAlphaAnimation(textUsername, 0, View.VISIBLE)
        view.app_bar_dashboard.addOnOffsetChangedListener(this)
        super.onViewCreated(view, savedInstanceState)
    }

    override fun onOffsetChanged(appBarLayout: AppBarLayout, offset: Int) {
        val maxScroll = appBarLayout.totalScrollRange.toFloat()
        val percentage = abs(offset.toFloat() / maxScroll)

        handleToolbarMenuVisibility(percentage)
        handleTitleVisibility(percentage)
        handleButtonResize(percentage)
    }

    private fun handleToolbarMenuVisibility(percentage: Float) {
        if (percentage > MIN_TOOLBAR_MENU_VISIBILITY) {
            toolbarMain.menu.setGroupVisible(R.id.toolbar_menu, true)
            toolbarMain.invalidate()
        } else {
            toolbarMain.menu.setGroupVisible(R.id.toolbar_menu, false)
            toolbarMain.invalidate()
        }
    }


    private fun handleButtonResize(percentage: Float) {
        btnToolbarDetails.scaleY = 1f - percentage
        btnToolbarDetails.scaleX = 1f - percentage
    }

    private fun handleTitleVisibility(percentage: Float) {
        if (percentage > MIN_AVATAR_PERCENTAGE_SIZE) {
            initAlphaAnimation(textUsername, ALPHA_ANIMATION_DURATION, View.VISIBLE)
        } else {
            initAlphaAnimation(textUsername, ALPHA_ANIMATION_DURATION, View.INVISIBLE)
        }
    }

    private fun initAlphaAnimation(view: View, animDuration: Long, visibility: Int) {
        if (visibility == View.INVISIBLE) {
            val alphaAnimation = AlphaAnimation(0f, 1f).apply {
                duration = animDuration
                fillAfter = true
            }
            view.startAnimation(alphaAnimation)
        } else {
            val alphaAnimation = AlphaAnimation(1f, 0f).apply {
                duration = animDuration
                fillAfter = true
            }
            view.startAnimation(alphaAnimation)
        }
    }

    companion object {
        private const val MIN_AVATAR_PERCENTAGE_SIZE = 0.8f
        private const val MIN_TOOLBAR_MENU_VISIBILITY = 0.9f
        private const val ALPHA_ANIMATION_DURATION: Long = 500
    }
}
