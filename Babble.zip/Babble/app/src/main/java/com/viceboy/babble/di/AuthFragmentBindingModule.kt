package com.viceboy.babble.di

import androidx.navigation.NavController
import androidx.navigation.Navigation
import com.viceboy.babble.AuthActivity
import com.viceboy.babble.R
import com.viceboy.babble.ui.screens.login.LoginFragment
import com.viceboy.babble.ui.screens.signup.SignUpFragment
import dagger.Module
import dagger.Provides
import dagger.android.ContributesAndroidInjector

@Module
abstract class AuthFragmentBindingModule {

    @ContributesAndroidInjector
    abstract fun contributeLoginFragment():LoginFragment

    @ContributesAndroidInjector
    abstract fun contributeRegisterFragment():SignUpFragment
}

@Module
class AuthModule {

    @Provides
    fun providesNavController(activity: AuthActivity):NavController = Navigation.findNavController(activity,
        R.id.navAuthHost)
}