package com.viceboy.babble.ui.screens.verifyPhone


import android.os.Bundle
import android.view.View
import androidx.lifecycle.Observer
import androidx.navigation.fragment.navArgs
import com.viceboy.babble.BaseFragment
import com.viceboy.babble.R
import com.viceboy.babble.databinding.FragmentVerifyPhoneBinding
import com.viceboy.babble.di.Injectable
import com.viceboy.babble.ui.state.OtpVerificationState
import kotlinx.android.synthetic.main.fragment_verify_phone.view.*
import timber.log.Timber


class VerifyPhoneFragment : BaseFragment<VerifyPhoneViewModel,FragmentVerifyPhoneBinding>(),Injectable {

    private val args by navArgs<VerifyPhoneFragmentArgs>()

    override fun layoutRes(): Int = R.layout.fragment_verify_phone

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        setUpBinding()
        viewModel.initTextChanges(view.etVerifyPhone)
        super.onViewCreated(view, savedInstanceState)
    }

    override fun observeLiveData(
        viewModel: VerifyPhoneViewModel,
        binding: FragmentVerifyPhoneBinding
    ) {
        with(viewModel) {
            phoneAuthProviderLiveData.observe(viewLifecycleOwner, Observer {state ->
                when (state) {
                    is OtpVerificationState.Sent -> {

                    }

                    is OtpVerificationState.Verified -> {

                    }

                    is OtpVerificationState.Failed -> {

                    }
                }
            })

            getOtpButtonStateManagerLiveData.observe(viewLifecycleOwner, Observer {
                binding.getOtpButtonState = it
            })

            verifyOtpButtonStateManagerLiveData.observe(viewLifecycleOwner, Observer {
                binding.verifyOtpButtonState = it
            })

            progressLiveData.observe(viewLifecycleOwner, Observer {
                Timber.e(it.toString())
            })
        }
    }

    override val viewModelClass: Class<VerifyPhoneViewModel> = VerifyPhoneViewModel::class.java

    private fun setUpBinding() {
        binding.apply {
            verifyViewModel = viewModel
            lifecycleOwner = viewLifecycleOwner
            user = args.userDetails
        }
    }
}
