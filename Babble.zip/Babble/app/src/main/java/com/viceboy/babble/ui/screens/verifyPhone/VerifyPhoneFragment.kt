package com.viceboy.babble.ui.screens.verifyPhone


import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.navigation.fragment.navArgs
import com.viceboy.babble.BaseFragment
import com.viceboy.babble.R
import com.viceboy.babble.databinding.FragmentVerifyPhoneBinding
import com.viceboy.babble.di.Injectable
import com.viceboy.babble.ui.util.toEditable
import kotlinx.android.synthetic.main.fragment_verify_phone.view.*


class VerifyPhoneFragment : BaseFragment<VerifyPhoneViewModel,FragmentVerifyPhoneBinding>(),Injectable {

    private val args by navArgs<VerifyPhoneFragmentArgs>()

    override fun layoutRes(): Int = R.layout.fragment_verify_phone

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        setUpBinding()
        viewModel.initTextChanges(view.etVerifyPhone)
        super.onViewCreated(view, savedInstanceState)
    }

    override fun observeLiveData(
        viewModel: VerifyPhoneViewModel,
        binding: FragmentVerifyPhoneBinding
    ) {
        with(viewModel) {
            enableButtonLiveData.observe(viewLifecycleOwner, Observer {
                binding.enableButtonClickable = it
            })
        }
    }

    override val viewModelClass: Class<VerifyPhoneViewModel> = VerifyPhoneViewModel::class.java

    private fun setUpBinding() {
        binding.apply {
            verifyViewModel = viewModel
            lifecycleOwner = viewLifecycleOwner
            user = args.userDetails
        }
    }
}
