package com.viceboy.babble.di

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.viceboy.babble.ui.base.ViewModelFactory
import com.viceboy.babble.ui.screens.login.LoginViewModel
import com.viceboy.babble.ui.screens.signup.SignUpViewModel
import dagger.Binds
import dagger.Module
import dagger.multibindings.IntoMap

@Module
abstract class ViewModelModule {

    @Binds
    @IntoMap
    @ViewModelKey(LoginViewModel::class)
    abstract fun bindsLoginViewModelModule(viewModel: LoginViewModel):ViewModel

    @Binds
    @IntoMap
    @ViewModelKey(SignUpViewModel::class)
    abstract fun bindsSignupViewModelModule(viewModel: SignUpViewModel):ViewModel

    @Binds
    abstract fun bindsViewModelFactory(viewModelFactory:ViewModelFactory):ViewModelProvider.Factory
}