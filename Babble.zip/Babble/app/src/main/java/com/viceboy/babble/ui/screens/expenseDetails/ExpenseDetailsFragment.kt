package com.viceboy.babble.ui.screens.expenseDetails


import android.graphics.drawable.Drawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.os.postDelayed
import androidx.lifecycle.Observer
import androidx.navigation.fragment.navArgs
import androidx.transition.TransitionInflater
import com.bumptech.glide.load.DataSource
import com.bumptech.glide.load.engine.GlideException
import com.bumptech.glide.request.RequestListener
import com.bumptech.glide.request.target.Target
import com.viceboy.babble.R
import com.viceboy.babble.databinding.FragmentExpenseDetailsBinding
import com.viceboy.babble.di.Injectable
import com.viceboy.babble.ui.base.BaseHomeFragment
import com.viceboy.babble.ui.state.Resource
import com.viceboy.data_repo.model.uiModel.GroupExpense

class ExpenseDetailsFragment :
    BaseHomeFragment<ExpenseDetailsViewModel, FragmentExpenseDetailsBinding>(), Injectable {

    private var groupExpense: GroupExpense? = null

    private val handler = Handler(Looper.getMainLooper())
    private val navArgs by navArgs<ExpenseDetailsFragmentArgs>()

    override fun layoutRes(): Int = R.layout.fragment_expense_details

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = super.onCreateView(inflater, container, savedInstanceState)
        setUpSharedElementTransition()
        return view
    }

    override fun onCreateView() {
        initGroupExpense()
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        setUpBinding()
        super.onViewCreated(view, savedInstanceState)
    }

    override fun observeLiveData(
        viewModel: ExpenseDetailsViewModel,
        binding: FragmentExpenseDetailsBinding
    ) {
        viewModel.expenseInfoLiveData.observe(viewLifecycleOwner, Observer {
            when (it) {
                is Resource.Success -> {
                    binding.expense = it.data
                }
            }
        })
    }

    override val viewModelClass: Class<ExpenseDetailsViewModel> =
        ExpenseDetailsViewModel::class.java

    override val hasBottomNavigationView: Boolean = false

    private fun initGroupExpense() {
        arguments?.let {
            groupExpense = navArgs.expense
            groupExpense?.let { viewModel.setGroupExpense(it) }
        }
    }

    private fun setUpSharedElementTransition() {
        sharedElementEnterTransition =
            TransitionInflater.from(context).inflateTransition(R.transition.update_expense_image)

        val listener = object : RequestListener<Drawable> {
            override fun onLoadFailed(
                e: GlideException?,
                model: Any?,
                target: Target<Drawable>?,
                isFirstResource: Boolean
            ): Boolean = false

            override fun onResourceReady(
                resource: Drawable?,
                model: Any?,
                target: Target<Drawable>?,
                dataSource: DataSource?,
                isFirstResource: Boolean
            ): Boolean {
                startPostponedEnterTransition()
                return false
            }
        }

        handler.postDelayed(1000) {
            startPostponedEnterTransition()
        }

        postponeEnterTransition()
        binding.imageRequestListener = listener
    }

    private fun setUpBinding() {
        binding.apply {
            lifecycleOwner = viewLifecycleOwner
        }
    }
}
