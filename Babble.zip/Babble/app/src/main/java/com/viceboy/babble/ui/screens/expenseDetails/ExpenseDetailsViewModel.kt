package com.viceboy.babble.ui.screens.expenseDetails

import com.viceboy.babble.ui.base.BaseViewModel

class ExpenseDetailsViewModel : BaseViewModel<Int>() {

}