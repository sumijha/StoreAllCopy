package com.viceboy.babble.ui.binding

object SignupFragmentBindingAdapter {

}