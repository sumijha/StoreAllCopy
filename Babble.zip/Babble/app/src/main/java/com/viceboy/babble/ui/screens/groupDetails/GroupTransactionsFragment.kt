package com.viceboy.babble.ui.screens.groupDetails

import android.content.Context
import android.os.Bundle
import android.view.View
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.DividerItemDecoration.VERTICAL
import com.viceboy.babble.R
import com.viceboy.babble.databinding.FragmentGroupTransactionsBinding
import com.viceboy.babble.di.Injectable
import com.viceboy.babble.ui.base.BaseHomeFragment
import com.viceboy.babble.ui.state.Resource
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import timber.log.Timber

class GroupTransactionsFragment :
    BaseHomeFragment<GroupDetailsViewModel, FragmentGroupTransactionsBinding>(),Injectable {

    private lateinit var refreshJob: Job
    private lateinit var paymentDetailsAdapter : PaymentDetailsAdapter

    private val job = Job()
    private val context = lifecycleScope.coroutineContext + Dispatchers.Main + job

    override fun layoutRes(): Int = R.layout.fragment_group_transactions

    override fun onCreateView() {
        initPaymentDetailsAdapter()
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        binding.rvTransactions.apply {
            rvGroupTabsRecyclerList.addItemDecoration(DividerItemDecoration(requireContext(),VERTICAL))
            rvGroupTabsRecyclerList.adapter = paymentDetailsAdapter
        }
        super.onViewCreated(view, savedInstanceState)
    }

    override fun observeLiveData(
        viewModel: GroupDetailsViewModel,
        binding: FragmentGroupTransactionsBinding
    ) {
        viewModel.groupTransactionsLiveData.observe(viewLifecycleOwner, Observer {
            when (it) {
                is Resource.Success -> paymentDetailsAdapter.submitList(it.data)
            }
        })

        viewModel.tabIndexLiveData.observe(viewLifecycleOwner, Observer {
            /*refreshJob = lifecycleScope.launch(context) {
                if (it == 1) {
                    binding.rvTransactions.apply {
                        rvGroupTabsRecyclerList.recycledViewPool.clear()
                        rvGroupTabsRecyclerList.adapter?.notifyDataSetChanged()
                        rvGroupTabsRecyclerList.adapter = paymentDetailsAdapter
                    }
                }
            }*/
            binding.rvTransactions.rvGroupTabsRecyclerList.adapter?.notifyDataSetChanged()
        })
    }

    private fun initPaymentDetailsAdapter() {
        paymentDetailsAdapter = PaymentDetailsAdapter()
    }

    override val viewModelClass: Class<GroupDetailsViewModel> = GroupDetailsViewModel::class.java
    override val hasBottomNavigationView: Boolean = false
}
