package com.viceboy.babble.ui.screens.signup

import androidx.lifecycle.*
import com.viceboy.babble.ui.base.SingleLiveEvent
import javax.inject.Inject

class SignUpViewModel @Inject constructor() : ViewModel() {

    private val listOfValidFields = mutableListOf<String>()
    private val listOfFields = listOf(
        KEY_NAME,
        KEY_EMAIL,
        KEY_PHONE,
        KEY_PASSWORD
    )

    /**
     * Mutable LiveData to setup two way data binding for Input fields
     */
    val editSignUpInputName = MutableLiveData<String>()
    val editSignUpInputEmail = MutableLiveData<String>()
    val editSignUpInputPhone = MutableLiveData<String>()
    val editSignUpPassword = MutableLiveData<String>()

    /**
     * Mediator LiveData to validate blank input fields
     */
    private val _hasAllFieldsFilled = MediatorLiveData<List<String>>()
    private val _hasAllRequiredFields = MediatorLiveData<Boolean>()
    val hasAllRequiredFields: LiveData<Boolean>
        get() = _hasAllRequiredFields


    /**
     * Setting up LiveData for Navigation
     */
    private val _navigateToLogin = MutableLiveData<SingleLiveEvent<Boolean>>()
    val navigateToLogin: LiveData<SingleLiveEvent<Boolean>>
        get() = _navigateToLogin

    fun setLoginNavigationFlag(destination: Boolean) {
        _navigateToLogin.value = SingleLiveEvent(destination)
    }

    /**
     * Setting up LiveData for SignUp Click Event
     */
    private val isSignUpClicked = MutableLiveData<Boolean>(false)
    val onClickEvent: LiveData<Boolean>
        get() = isSignUpClicked

    fun resetSignUpClickEvent() {
        isSignUpClicked.value = false
    }

    private val checkListForSignUp = listOf<String>(KEY_BUTTON_EVENT, KEY_FIELD_VALIDATED)
    private val mutableCheckListForSignUp = mutableListOf<String>()
    private val _hasClickedOnSignUp = MediatorLiveData<List<String>>()
    val isAllowedToCreateAccount: LiveData<Boolean> = Transformations.map(_hasClickedOnSignUp) {
        return@map it.containsAll(checkListForSignUp)
    }

    fun onSignUpButtonClick() {
        isSignUpClicked.value = true
    }

    init {

        // Adding LiveData as source for field validation
        _hasAllFieldsFilled.addSource(editSignUpInputEmail) {
            if (it.length >= 4 && it.contains("@"))
                listOfValidFields.add(KEY_EMAIL)
            else
                listOfValidFields.remove(KEY_EMAIL)
            _hasAllFieldsFilled.value = listOfValidFields

        }

        _hasAllFieldsFilled.addSource(editSignUpInputName) {
            if (it.length > 2)
                listOfValidFields.add(KEY_NAME)
            else
                listOfValidFields.remove(KEY_NAME)
            _hasAllFieldsFilled.value = listOfValidFields
        }

        _hasAllFieldsFilled.addSource(editSignUpInputPhone) {
            if (it.length >= 4)
                listOfValidFields.add(KEY_PHONE)
            else
                listOfValidFields.remove(KEY_PHONE)
            _hasAllFieldsFilled.value = listOfValidFields

        }

        _hasAllFieldsFilled.addSource(editSignUpPassword) {
            if (it.length > 5)
                listOfValidFields.add(KEY_PASSWORD)
            else
                listOfValidFields.remove(KEY_PASSWORD)
            _hasAllFieldsFilled.value = listOfValidFields
        }

        // Verifying if required fields has been filled
        _hasAllRequiredFields.addSource(_hasAllFieldsFilled) {
            _hasAllRequiredFields.value = it.containsAll(listOfFields)
        }

        // Adding required field LiveData and signup click LiveData to trigger Create Account on Click
        _hasClickedOnSignUp.addSource(_hasAllRequiredFields) {
            if (it)
                mutableCheckListForSignUp.add(KEY_FIELD_VALIDATED)
            else
                mutableCheckListForSignUp.removeAll(checkListForSignUp)
            _hasClickedOnSignUp.value = mutableCheckListForSignUp
        }

        _hasClickedOnSignUp.addSource(isSignUpClicked) {
            if (it) mutableCheckListForSignUp.add(KEY_BUTTON_EVENT)
            _hasClickedOnSignUp.value = mutableCheckListForSignUp
        }
    }

    override fun onCleared() {
        super.onCleared()
        _hasAllFieldsFilled.apply {
            removeSource(editSignUpInputEmail)
            removeSource(editSignUpInputName)
            removeSource(editSignUpInputPhone)
            removeSource(editSignUpPassword)
        }
        _hasAllRequiredFields.removeSource(_hasAllFieldsFilled)

        _hasClickedOnSignUp.apply {
            removeSource(isSignUpClicked)
            removeSource(_hasAllRequiredFields)
        }
    }

    companion object {
        private val KEY_EMAIL = "email"
        private val KEY_PHONE = "phone"
        private val KEY_NAME = "name"
        private val KEY_PASSWORD = "password"
        private val KEY_FIELD_VALIDATED = "fields_checked"
        private val KEY_BUTTON_EVENT = "button_clicked"
    }
}