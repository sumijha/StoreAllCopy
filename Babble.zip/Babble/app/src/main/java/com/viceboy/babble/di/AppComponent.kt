package com.viceboy.babble.di

import android.app.Application
import com.viceboy.babble.BaseApplication
import dagger.BindsInstance
import dagger.Component
import dagger.android.AndroidInjectionModule
import dagger.android.AndroidInjector
import javax.inject.Singleton

@Component (modules = [AndroidInjectionModule::class,ActivityBindingModule::class,ViewModelModule::class])
@Singleton
interface AppComponent : AndroidInjector<BaseApplication> {

    @Component.Builder
    interface Builder {
        @BindsInstance
        fun application(application:Application):Builder

        fun build():AppComponent
    }
}