package com.viceboy.babble.ui.screens.groupDetails

import androidx.recyclerview.widget.DiffUtil
import com.viceboy.babble.R
import com.viceboy.babble.databinding.ItemGroupDetailsMemberListBinding
import com.viceboy.babble.ui.base.DataBoundStateListAdapter
import com.viceboy.data_repo.model.uiModel.GroupMembers
import com.viceboy.data_repo.model.uiModel.MemberLoadState

class MemberDetailsAdapter :
    DataBoundStateListAdapter<MemberLoadState, ItemGroupDetailsMemberListBinding>(
        diffCallback = object : DiffUtil.ItemCallback<MemberLoadState>() {
            override fun areItemsTheSame(
                oldItem: MemberLoadState,
                newItem: MemberLoadState
            ): Boolean =
                if (oldItem is GroupMembers && newItem is GroupMembers)
                    oldItem.id == newItem.id
                else
                    false

            override fun areContentsTheSame(
                oldItem: MemberLoadState,
                newItem: MemberLoadState
            ): Boolean =
                if (oldItem is GroupMembers && newItem is GroupMembers)
                    oldItem.amountPaid == newItem.amountPaid && oldItem.avatarUrl == newItem.avatarUrl
                else
                    false
        }
    ) {
    override val progressLayoutRes: Int = R.layout.layout_progress_data_load

    override val emptyDataLayoutRes: Int = R.layout.layout_no_members
    override val dataLayoutRes: Int = R.layout.item_group_details_member_list

    override fun onSuccessDataBind(
        binding: ItemGroupDetailsMemberListBinding,
        item: MemberLoadState
    ) {
        binding.members = item as GroupMembers
    }

}