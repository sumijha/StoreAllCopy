package com.viceboy.babble.ui.screens.captureExpense

import com.viceboy.babble.ui.base.BaseViewModel
import javax.inject.Inject

class CaptureExpenseViewModel  constructor() : BaseViewModel<Int>() {

}