package com.viceboy.babble.ui.screens.captureExpense

import androidx.camera.core.FlashMode
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Transformations
import com.viceboy.babble.ui.base.BaseViewModel
import javax.inject.Inject

class CaptureExpenseViewModel @Inject constructor() : BaseViewModel<Int>() {

    private var flashModeIndex = 0
    private val mapOfFlashMode = mapOf(0 to FlashMode.AUTO, 1 to FlashMode.ON, 2 to FlashMode.OFF)

    private val mutableFlashModeLiveData = MutableLiveData<FlashMode>(mapOfFlashMode[0])
    val flashModeLiveData: LiveData<FlashMode>
        get() = mutableFlashModeLiveData
    val flashModeIndexLiveData = Transformations.map(mutableFlashModeLiveData) {
        return@map if (it == FlashMode.AUTO) 0 else if (it == FlashMode.ON) 1 else 2
    }

    private val mutableEnablingShutterButtonLiveData = MutableLiveData<Boolean>(true)
    val enablingShutterButtonLiveData: LiveData<Boolean>
        get() = mutableEnablingShutterButtonLiveData

    private val mutableEnablingSwitchCameraButtonLiveData = MutableLiveData<Boolean>(true)
    val enablingSwitchCameraButtonLiveData: LiveData<Boolean>
        get() = mutableEnablingSwitchCameraButtonLiveData

    fun onToggleFlashButtonClick() {
        if (flashModeIndex == 2) flashModeIndex = 0 else flashModeIndex += 1
        mutableFlashModeLiveData.value = mapOfFlashMode[flashModeIndex]
    }

    fun disableShutterButtonClick() {
        mutableEnablingShutterButtonLiveData.value = false
    }

    fun enableShutterButtonClick() {
        mutableEnablingShutterButtonLiveData.value = true
    }

    fun disableSwitchCameraButtonClick() {
        mutableEnablingSwitchCameraButtonLiveData.value = false
    }

    fun enableSwitchCameraButtonClick() {
        mutableEnablingSwitchCameraButtonLiveData.value = true
    }
}