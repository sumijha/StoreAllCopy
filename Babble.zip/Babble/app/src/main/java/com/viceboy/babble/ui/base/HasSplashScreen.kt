package com.viceboy.babble.ui.base

import android.animation.Animator
import android.os.Handler
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.fragment.app.FragmentActivity
import com.viceboy.babble.R
import com.viceboy.babble.ui.util.animateCircularReveal

interface HasSplashScreen {

    fun getFragmentActivity():FragmentActivity?

    fun afterSplashScreenAnimation()

    fun addSplashView() {
        val splashView = getSplashView()
        val layoutParams = ViewGroup.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        )
        getFragmentActivity()?.window?.addContentView(splashView, layoutParams)
        Handler().postDelayed(
            {
                splashView.animateCircularReveal(
                    600,
                    animatorListener(splashView)
                )
            }, 1000
        )
    }

    private fun removeView(view: View) {
        (view.parent as ViewGroup).removeView(getSplashView())
    }

    fun getSplashView() = ImageView(getFragmentActivity()?.applicationContext).apply {
        setBackgroundResource(R.drawable.bg_splash)
    }

    fun animatorListener(splashView: ImageView): Animator.AnimatorListener =
        object : Animator.AnimatorListener {
            override fun onAnimationRepeat(p0: Animator?) {}

            override fun onAnimationEnd(p0: Animator?) {
                splashView.visibility = View.GONE
                removeView(splashView)
                afterSplashScreenAnimation()
            }

            override fun onAnimationCancel(p0: Animator?) {
                removeView(splashView)
            }

            override fun onAnimationStart(p0: Animator?) {}
        }
}