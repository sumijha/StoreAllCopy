package com.viceboy.babble.ui.screens.login

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.viceboy.babble.ui.base.SingleLiveEvent
import javax.inject.Inject

class LoginViewModel @Inject constructor() : ViewModel() {

    val editEmailTextContent = MutableLiveData<String>()
    val editPasswordTextContent = MutableLiveData<String>()
    val isValidEmail = MutableLiveData<Boolean>(false)
    val isValidPassword = MutableLiveData<Boolean>(false)
    val isLoginClicked = MutableLiveData<Boolean>(false)
    val enableProgressBar = MutableLiveData<Boolean>(false)

    private val _newDestination = MutableLiveData<SingleLiveEvent<Int>>()
    val newDestination: LiveData<SingleLiveEvent<Int>>
        get() = _newDestination

    fun setDestinationId(destinationId: Int) {
        _newDestination.value = SingleLiveEvent(destinationId)
    }

    fun setLoginClickEvent(data: MutableLiveData<Boolean>) {
        data.value = true
    }

    fun resetLoginClickEvent() {
        isLoginClicked.value = false
    }
}