package com.viceboy.babble.ui.screens.login

import android.view.View
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.viceboy.babble.ui.base.SingleLiveEvent
import kotlinx.android.synthetic.main.fragment_login.view.*
import javax.inject.Inject

class LoginViewModel @Inject constructor() : ViewModel() {

    val isValidEmail = MutableLiveData<Boolean>(false)
    val isValidPassword = MutableLiveData<Boolean>(false)
    val loginClicked = MutableLiveData<Boolean>(false)
    val disableProgress = MutableLiveData<Boolean>(false)
    val enableProgressBar = MutableLiveData<Boolean>(false)

    private val _newDestination = MutableLiveData<SingleLiveEvent<Int>>()
    val newDestination: LiveData<SingleLiveEvent<Int>>
        get() = _newDestination

    val editEmailTextContent = MutableLiveData<String>()
    val editPasswordTextContent = MutableLiveData<String>()

    fun setDestinationId(destinationId: Int) {
        _newDestination.value = SingleLiveEvent(destinationId)
    }

    fun setLoginClickEvent(data: MutableLiveData<Boolean>) {
        data.value = true
    }
}