package com.viceboy.babble.ui.util

import io.reactivex.Completable
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.observers.DisposableCompletableObserver
import io.reactivex.schedulers.Schedulers

fun Completable.scheduleOnBackAndOutOnMain(): Completable {
    return this.subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread())
}

fun Completable.addToCompositeDisposable(
    compositeDisposable: CompositeDisposable,
    onComplete: () -> Unit,
    onError: (Throwable) -> Unit
) {
    compositeDisposable.add(this.subscribeWith(object : DisposableCompletableObserver() {
        override fun onComplete() {
            onComplete.invoke()
        }

        override fun onError(e: Throwable) {
            onError.invoke(e)
        }

    }))
}
