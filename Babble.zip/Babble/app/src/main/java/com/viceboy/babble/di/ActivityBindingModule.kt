package com.viceboy.babble.di

import com.viceboy.babble.AuthActivity
import com.viceboy.babble.MainActivity
import com.viceboy.babble.auth.AuthListenerModule
import com.viceboy.babble.auth.AuthProviderModule
import com.viceboy.babble.ui.base.AuthStateListener
import com.viceboy.babble.ui.util.PreferenceUtil
import dagger.Binds
import dagger.Module
import dagger.android.ContributesAndroidInjector

@Module
abstract class ActivityBindingModule {

    @MainActivityScope
    @ContributesAndroidInjector(modules = [MainFragmentBindingModule::class])
    abstract fun contributeMainActivity():MainActivity

    @AuthActivityScope
    @ContributesAndroidInjector(modules = [AuthFragmentBindingModule::class,AuthUtilsModule::class, AuthProviderModule::class, ViewModelModule::class])
    abstract fun contributeAuthActivity():AuthActivity
}