package com.viceboy.babble.di

import com.viceboy.babble.AuthActivity
import com.viceboy.babble.MainActivity
import dagger.Module
import dagger.android.ContributesAndroidInjector

@Module
abstract class ActivityBindingModule {

    @ContributesAndroidInjector
    abstract fun contributeMainActivity():MainActivity

    @ContributesAndroidInjector(modules = [AuthFragmentBindingModule::class,AuthModule::class])
    abstract fun contributeAuthActivity():AuthActivity
}