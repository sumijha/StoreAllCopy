package com.viceboy.babble.di

import com.viceboy.babble.AuthActivity
import com.viceboy.babble.MainActivity
import com.viceboy.babble.auth.AuthProviderModule
import dagger.Module
import dagger.android.ContributesAndroidInjector

@Module
abstract class ActivityBindingModule {

    @ContributesAndroidInjector
    abstract fun contributeMainActivity():MainActivity

    @AuthActivityScope
    @ContributesAndroidInjector(modules = [AuthFragmentBindingModule::class,AuthUtilsModule::class, AuthProviderModule::class, ViewModelModule::class])
    abstract fun contributeAuthActivity():AuthActivity
}