package com.viceboy.babble.ui.base

import android.os.Parcelable
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.databinding.ViewDataBinding
import androidx.recyclerview.widget.AsyncDifferConfig
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.viceboy.data_repo.model.uiModel.EmptyDataModel
import com.viceboy.data_repo.model.uiModel.ProgressModel
import java.util.concurrent.Executors

abstract class DataBoundStateListAdapter<T : Parcelable, V : ViewDataBinding>(diffCallback: DiffUtil.ItemCallback<T>) :
    ListAdapter<T, DataBoundStateViewHolder<V>>(
        AsyncDifferConfig.Builder<T>(diffCallback)
            .setBackgroundThreadExecutor(Executors.newSingleThreadExecutor())
            .build()
    ) {


    abstract val progressLayoutRes: Int

    abstract val emptyDataLayoutRes: Int

    abstract val dataLayoutRes: Int

    abstract fun onSuccessDataBind(binding: V, item: T)

    /**
     * Override this method in order to create multiple viewholders
     */
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): DataBoundStateViewHolder<V> {
        return when (viewType) {
            PROGRESS -> getProgressViewHolder(parent)
            SUCCESS -> getDataViewHolder(parent)
            FAILED -> getEmptyDataViewHolder(parent)
            else -> getDataViewHolder(parent)
        }
    }

    override fun getItemViewType(position: Int): Int {
        return when (getItem(position)) {
            is ProgressModel -> PROGRESS
            is EmptyDataModel -> FAILED
            else -> SUCCESS
        }
    }

    override fun onBindViewHolder(holder: DataBoundStateViewHolder<V>, position: Int) {
        when (holder) {
            is DataLoadViewHolder -> onSuccessDataBind(holder.binding, getItem(position))
        }
        holder.binding.executePendingBindings()
    }

    private fun getProgressViewHolder(parent: ViewGroup): DataBoundStateViewHolder<V> {
        val binding = DataBindingUtil.inflate<V>(
            LayoutInflater.from(parent.context),
            progressLayoutRes,
            parent,
            false
        )
        return ProgressStateViewHolder(binding)
    }

    private fun getEmptyDataViewHolder(parent: ViewGroup): DataBoundStateViewHolder<V> {
        val binding = DataBindingUtil.inflate<V>(
            LayoutInflater.from(parent.context),
            emptyDataLayoutRes,
            parent,
            false
        )
        return EmptyDataViewHolder(binding)
    }

    private fun getDataViewHolder(parent: ViewGroup): DataBoundStateViewHolder<V> {
        val binding = DataBindingUtil.inflate<V>(
            LayoutInflater.from(parent.context),
            dataLayoutRes,
            parent,
            false
        )
        return DataLoadViewHolder(binding)
    }
}

open class ProgressStateViewHolder<V : ViewDataBinding>(itemViewBinding: V) :
    DataBoundStateViewHolder<V>(itemViewBinding)

open class EmptyDataViewHolder<V : ViewDataBinding>(itemViewBinding: V) :
    DataBoundStateViewHolder<V>(itemViewBinding)

open class DataBoundStateViewHolder<V : ViewDataBinding>(val binding: V) :
    RecyclerView.ViewHolder(binding.root)

open class DataLoadViewHolder<V : ViewDataBinding>(itemBinding: V) :
    DataBoundStateViewHolder<V>(itemBinding)

private const val PROGRESS = 0
private const val SUCCESS = 1
private const val FAILED = 2
