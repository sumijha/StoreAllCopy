package com.viceboy.babble.ui.screens.dashboard

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.DiffUtil
import com.viceboy.babble.R
import com.viceboy.babble.databinding.ItemDashboardMemberTabBinding
import com.viceboy.babble.ui.base.DataBoundListAdapter
import com.viceboy.babble.ui.screens.dashboard.model.DashboardMembers

class MemberTabListAdapter : DataBoundListAdapter<DashboardMembers,ItemDashboardMemberTabBinding>(
    diffCallback = object : DiffUtil.ItemCallback<DashboardMembers>() {
        override fun areItemsTheSame(oldItem: DashboardMembers, newItem: DashboardMembers): Boolean = oldItem.id == newItem.id

        override fun areContentsTheSame(oldItem: DashboardMembers, newItem: DashboardMembers): Boolean = oldItem.name == newItem.name

    }
) {
    override fun inflateBinding(viewGroup: ViewGroup): ItemDashboardMemberTabBinding {
        return DataBindingUtil.inflate(
            LayoutInflater.from(viewGroup.context),
            R.layout.item_dashboard_member_tab,
            viewGroup,
            false
        )
    }

    override fun bind(binding: ItemDashboardMemberTabBinding, item: DashboardMembers) {
        TODO("Not yet implemented")
    }
}