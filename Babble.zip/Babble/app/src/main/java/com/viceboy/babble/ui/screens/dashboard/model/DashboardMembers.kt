package com.viceboy.babble.ui.screens.dashboard.model

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
data class DashboardMembers(
    val id : String,
    val name : String,
    var avatarImage : String?,
    var inGroups : List<String>?
) : Parcelable