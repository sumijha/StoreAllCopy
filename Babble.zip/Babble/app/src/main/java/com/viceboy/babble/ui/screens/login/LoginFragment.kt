package com.viceboy.babble.ui.screens.login

import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.Observer
import androidx.navigation.NavController
import com.viceboy.babble.BaseFragment
import com.viceboy.babble.R
import com.viceboy.babble.databinding.FragmentLoginBinding
import com.viceboy.babble.di.Injectable
import com.viceboy.babble.ui.base.EventObserver
import com.viceboy.babble.ui.base.HasSplashScreen
import com.viceboy.babble.ui.state.Resource
import javax.inject.Inject

class LoginFragment : BaseFragment<LoginViewModel, FragmentLoginBinding>(), Injectable,
    HasSplashScreen {

    @Inject
    lateinit var navController: NavController

    private var hasSplashAnimationEnded = false

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        setUpBinding()
    }

    override fun afterSplashScreenAnimation() {
        if (!hasSplashAnimationEnded)
            binding.startAnimation = true

        hasSplashAnimationEnded = true
    }

    override fun observeLiveData(viewModel: LoginViewModel, binding: FragmentLoginBinding) {
        with(viewModel) {
            onClickEventLiveData.observe(viewLifecycleOwner, Observer {
                binding.startFieldValidation = it
            })

            buttonStateManagerLiveData.observe(viewLifecycleOwner, Observer {
                binding.buttonState = it
            })

            loginStateLiveData.observe(viewLifecycleOwner, EventObserver { resource ->
                when (resource) {
                    is Resource.Loading -> {
                        binding.enableProgress = true
                    }

                    is Resource.Success -> {
                        binding.enableProgress = false
                        resetAnimationState()
                        Toast.makeText(
                            requireContext(),
                            "User is successfully logged in",
                            Toast.LENGTH_SHORT
                        ).show()
                        navController.navigate(LoginFragmentDirections.actionLoginFragmentToMainActivity())
                    }

                    is Resource.Failure -> {
                        binding.enableProgress = false
                        resetAnimationState()
                        Toast.makeText(
                            requireContext(),
                            "${resource.message}",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                }
            })

            navigateToDestinationLiveData.observe(viewLifecycleOwner, EventObserver {
                navController.navigate(it)
            })
        }
    }

    override fun getFragmentActivity(): FragmentActivity? = this.activity

    override val viewModelClass: Class<LoginViewModel> = LoginViewModel::class.java

    override fun layoutRes(): Int = R.layout.fragment_login

    private fun setUpBinding() {
        binding.apply {
            authViewModel = viewModel
            lifecycleOwner = viewLifecycleOwner
            signUpNavDirection = LoginFragmentDirections.actionLoginFragmentToRegisterFragment()
            forgotPwdNavDirection = LoginFragmentDirections.actionLoginFragmentToForgotPwdFragment()
            loginButtonAnimationListener = viewModel.onClickBtnAnimationListener
            loginWithAnime = viewModel.hasClickEventAndValidFieldLiveData
            if (hasSplashAnimationEnded) startAnimation = true
        }
    }
}
