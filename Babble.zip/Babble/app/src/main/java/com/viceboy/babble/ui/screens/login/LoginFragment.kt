package com.viceboy.babble.ui.screens.login

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.ViewModelProviders
import androidx.navigation.NavController
import com.viceboy.babble.BaseFragment
import com.viceboy.babble.R
import com.viceboy.babble.databinding.FragmentLoginBinding
import com.viceboy.babble.di.Injectable
import com.viceboy.babble.ui.base.EventObserver
import com.viceboy.babble.ui.base.HasSplashScreen
import javax.inject.Inject

class LoginFragment : BaseFragment(), Injectable, HasSplashScreen {
    @Inject
    lateinit var viewModelFactory: ViewModelProvider.Factory

    @Inject
    lateinit var navController: NavController

    private lateinit var dataBinding: FragmentLoginBinding
    private var hasSplashAnimationEnded = false

    private val loginViewModel by lazy {
        ViewModelProviders.of(this, viewModelFactory).get(LoginViewModel::class.java)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        dataBinding = DataBindingUtil.inflate(inflater, R.layout.fragment_login, container, false)
        return dataBinding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        setUpBinding()
        setUpUiBinding()
    }

    override fun afterSplashScreenAnimation() {
        if (!hasSplashAnimationEnded) {
            dataBinding.startAnimation = true
        }
        hasSplashAnimationEnded = true
    }

    override fun getFragmentActivity(): FragmentActivity? = this.activity

    private fun setUpBinding() {
        dataBinding.apply {
            authViewModel = loginViewModel
            lifecycleOwner = viewLifecycleOwner
        }
    }

    private fun setUpUiBinding() {
        dataBinding.apply {
            emailText = loginViewModel.editEmailTextContent
            passwordText = loginViewModel.editPasswordTextContent
            checkFieldValues = loginViewModel.isLoginClicked
            isValidEmail = loginViewModel.isValidEmail
            isValidPwd = loginViewModel.isValidPassword
            enableProgress = loginViewModel.enableProgressBar
            navDirection = LoginFragmentDirections.actionLoginFragmentToRegisterFragment()
            if (hasSplashAnimationEnded) startAnimation = true
        }

        loginViewModel.newDestination.observe(viewLifecycleOwner, EventObserver {
            loginViewModel.resetLoginClickEvent()
            navController.navigate(it)
        })
    }
}
