package com.viceboy.babble.ui.screens.addExpense


import android.os.Bundle
import android.view.View
import androidx.navigation.fragment.FragmentNavigatorExtras
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import com.viceboy.babble.R
import com.viceboy.babble.databinding.FragmentAddExpenseBinding
import com.viceboy.babble.di.Injectable
import com.viceboy.babble.ui.base.BaseFragment
import java.io.File

class AddExpenseFragment : BaseFragment<AddExpenseViewModel, FragmentAddExpenseBinding>(),
    Injectable {

    private var imageFile: File? = null
    private var imageFileName: String? = null

    private val args by navArgs<AddExpenseFragmentArgs>()

    override fun layoutRes(): Int = R.layout.fragment_add_expense

    override fun onCreateView() = Unit

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        setUpBinding()
        setUpExpenseImage()

        super.onViewCreated(view, savedInstanceState)
    }

    override fun observeLiveData(
        viewModel: AddExpenseViewModel,
        binding: FragmentAddExpenseBinding
    ) {
        //TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }

    override val viewModelClass: Class<AddExpenseViewModel> = AddExpenseViewModel::class.java

    @Suppress("UNUSED_PARAMETER")
    fun onImageClick(view: View) {
        imageFile?.let {
            val extras = FragmentNavigatorExtras(
                binding.ivItemImageGlide to it.name,
                binding.tvFileName to it.absolutePath
            )
            findNavController().navigate(
                AddExpenseFragmentDirections.actionAddExpenseFragmentToCaptureExpensePreviewFragment(
                    it
                ), extras
            )
        }
    }

    private fun setUpBinding() {
        binding.apply {
            lifecycleOwner = viewLifecycleOwner
            presenter = this@AddExpenseFragment
        }
    }

    private fun setUpExpenseImage() {
        arguments?.let {
            imageFile = args.photoFile
            imageFile?.let {
                binding.imageFile = it
                binding.tvFileName.text = it.name
                imageFileName = it.name
            }
        }
    }
}
