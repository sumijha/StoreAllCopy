package com.viceboy.babble.ui.screens.addExpense

import android.app.Activity
import android.content.Intent
import android.graphics.BitmapFactory
import android.graphics.Rect
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.PopupWindow
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.Observer
import androidx.navigation.fragment.FragmentNavigatorExtras
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.viceboy.babble.R
import com.viceboy.babble.databinding.FragmentAddExpenseBinding
import com.viceboy.babble.databinding.LayoutSplitAmountBinding
import com.viceboy.babble.di.Injectable
import com.viceboy.babble.ui.base.BaseFragment
import com.viceboy.babble.ui.base.EventObserver
import com.viceboy.babble.ui.state.Resource
import com.viceboy.babble.ui.util.Constants
import com.viceboy.babble.ui.util.ImageUtil
import com.viceboy.babble.ui.util.toggleBottomNavVisibility
import com.viceboy.data_repo.model.Groups
import com.viceboy.data_repo.model.User


class AddExpenseFragment : BaseFragment<AddExpenseViewModel, FragmentAddExpenseBinding>(),
    Injectable {

    private lateinit var bottomNavigationView: BottomNavigationView

    private var isSplitByMenuShowing = false
    private var totalParticipants = 0
    private var currentNoOfParticipants = 0
    private var amountPaid = 0f

    private var selectedGroup: Groups? = null
    private var argfromScreen: String? = null
    private var argimageUri: Uri? = null
    private var popUpWindow: PopupWindow? = null
    private var groupListAdapter: GroupListAdapter? = null
    private var expensePaidByAdapter: ExpenseOwnerListAdapter? = null
    private var expensePaidForAdapter: NewExpenseParticipantPaidForAdapter? = null
    private var listOfParticipantsShare = ArrayList<Float>()

    private val args by navArgs<AddExpenseFragmentArgs>()

    override fun layoutRes(): Int = R.layout.fragment_add_expense

    override fun onCreateView() {
        initFromScreenArgs()
        initBottomNavigationView()
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        setUpBottomNavVisibility()
        setUpBinding()
        setUpSplitAmountByDropdown()
        setUpExpenseImage()
        setUpGroupNamesAdapter()
        setUpExpensePaidByAdapter()
        super.onViewCreated(view, savedInstanceState)
    }

    override fun onPause() {
        hideSplitByPopUp()
        super.onPause()
    }

    override fun observeLiveData(
        viewModel: AddExpenseViewModel,
        binding: FragmentAddExpenseBinding
    ) {
        viewModel.datePickerLiveData.observe(viewLifecycleOwner, EventObserver {
            binding.tvSelectDate.text = it
        })

        viewModel.imageUriLiveData.observe(viewLifecycleOwner, Observer {
            it?.let {
                argimageUri = it
                binding.imageFile = it
                binding.tvFileName.text = it.lastPathSegment ?: ""
            }
        })

        viewModel.mutableAmountPaidLiveData.observe(viewLifecycleOwner, Observer {
            if (it.isNotEmpty()) {
                amountPaid = it.toFloat()
                dispatchUpdateToExpenseParticipantsAdapter()
            }
        })

        viewModel.participantsCountLiveData.observe(viewLifecycleOwner, Observer {
            currentNoOfParticipants = it
        })

        viewModel.participantsShareLiveData.observe(viewLifecycleOwner, Observer {
            listOfParticipantsShare = it
        })

        viewModel.requestFocusLiveData.observe(viewLifecycleOwner, Observer {
            if (it) activity?.window?.decorView?.clearFocus()
        })
    }

    override fun onDestroy() {
        showBottomNavigation()
        deleteImageFile()
        disposeAll()
        super.onDestroy()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (resultCode == Activity.RESULT_OK) {
            when (requestCode) {
                Constants.KEY_IMAGE_REQUEST_CODE -> handleImageRequestResult(data)
            }
        }
    }

    override val viewModelClass: Class<AddExpenseViewModel> = AddExpenseViewModel::class.java

    @Suppress("UNUSED_PARAMETER")
    fun onImageClick(view: View) {
        if (argimageUri != null) {
            argimageUri?.let {
                val extras = FragmentNavigatorExtras(
                    binding.ivItemImageGlide to it.scheme.toString(),
                    binding.tvFileName to it.encodedPath.toString()
                )
                findNavController().navigate(
                    AddExpenseFragmentDirections.actionAddExpenseFragmentToCaptureExpensePreviewFragment(
                        it
                    ), extras
                )
            }
        } else {
            setUpImagePicker()
        }
    }

    @Suppress("UNUSED_PARAMETER")
    fun onSelectDateTextViewClick(view: View) {
        findNavController().navigate(AddExpenseFragmentDirections.actionAddExpenseFragmentToSelectDateFragment())
    }

    private fun showBottomNavigation() {
        if (argfromScreen != null) {
            if (!argfromScreen.equals(Constants.KEY_FROM_CAPTURE_FRAGMENT)) {
                bottomNavigationView.toggleBottomNavVisibility(
                    View.VISIBLE,
                    bottomNavigationView
                )
            }
        } else {
            bottomNavigationView.toggleBottomNavVisibility(
                View.VISIBLE,
                bottomNavigationView
            )
        }
    }

    private fun setUpImagePicker() {
        val chooseIntent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
        chooseIntent.type = "image/*"
        startActivityForResult(
            Intent.createChooser(
                chooseIntent,
                resources.getString(R.string.select_image)
            ), Constants.KEY_IMAGE_REQUEST_CODE
        )
    }

    private fun setUpBinding() {
        binding.apply {
            lifecycleOwner = viewLifecycleOwner
            presenter = this@AddExpenseFragment
            addExpenseViewModel = viewModel
        }
    }

    private fun setUpExpenseImage() {
        arguments?.let {
            try {
                if (argimageUri == null)
                    argimageUri = args.photoFile
                argimageUri?.let {
                    viewModel.setMutableImageUri(it)
                }
            } catch (ignored: Exception) {
            }
        }
    }

    private fun setUpBottomNavVisibility() {
        if (bottomNavigationView.visibility == View.VISIBLE)
            bottomNavigationView.visibility = View.GONE
    }

    private fun setUpExpensePaidByAdapter() {
        this.expensePaidByAdapter =
            ExpenseOwnerListAdapter(selectedGroup?.groupAdmin?.keys?.elementAt(0) ?: "") {
                Toast.makeText(
                    requireContext(),
                    "Selected Group is ${it.name}",
                    Toast.LENGTH_LONG
                ).show()
            }

        expensePaidByAdapter?.let { binding.customExpandExpensePaidBy.setRecyclerAdapter(it) }

        initExpensePaidByList()
    }

    private fun initExpensePaidByList() {
        viewModel.groupMembersLiveData().observe(viewLifecycleOwner, Observer { userResource ->
            if (userResource != null) {
                when (userResource) {
                    is Resource.Success -> {
                        expensePaidByAdapter?.submitList(userResource.data)
                    }
                }
            } else {
                expensePaidByAdapter?.submitList(emptyList())
            }
        })
    }

    private fun setUpGroupNamesAdapter() {
        this.groupListAdapter = GroupListAdapter {
            Toast.makeText(
                requireContext(),
                "Selected Group is ${it.groupName}",
                Toast.LENGTH_LONG
            ).show()
            viewModel.onGroupNameSelected(it.id)
            onGroupSelected(it)
        }
        val innerView = binding.customExpandGroupNames.innerView
        if (innerView is RecyclerView) {
            innerView.adapter = groupListAdapter
        }

        initGroupListAdapterObserver()
    }

    private fun initGroupListAdapterObserver() {
        viewModel.groupsLiveData().observe(viewLifecycleOwner, Observer { groupResource ->
            if (groupResource != null) {
                when (groupResource) {
                    is Resource.Success -> {
                        groupListAdapter?.submitList(groupResource.data)
                    }
                }
            } else {
                groupListAdapter?.submitList(emptyList())
            }
        })
    }

    private fun setUpExpensePaidForAdapter() {
        this.expensePaidForAdapter =
            NewExpenseParticipantPaidForAdapter(
                viewLifecycleOwner,
                viewModel,
                listOfParticipantsShare
            ) {
                //TODO: Update the required callback
                Toast.makeText(
                    requireContext(),
                    "Selected Group is $it",
                    Toast.LENGTH_LONG
                ).show()
            }

        expensePaidForAdapter?.disposeAll()
        expensePaidForAdapter?.let { binding.customExpandExpensePaidFor.setRecyclerAdapter(it) }

        initExpenseParticipantsAdapterObserver()
    }

    private fun setUpSplitAmountByDropdown() {
        initSplitByPopUpWindow()
        binding.ibSplitAmountBy.setOnClickListener {
            if (!isSplitByMenuShowing)
                showSplitByPopUp()
            else
                hideSplitByPopUp()
        }
    }

    private fun initExpenseParticipantsAdapterObserver() {
        viewModel.splitAmountByLiveData.observe(viewLifecycleOwner, Observer {
            expensePaidForAdapter?.splitBy = it
            expensePaidForAdapter?.notifyDataSetChanged()
        })

        viewModel.groupMembersLiveData().observe(viewLifecycleOwner, Observer { userResource ->
            if (userResource != null) {
                when (userResource) {
                    is Resource.Success -> {
                        //TODO: Needs refactor
                        val data = userResource.data?.toMutableList()
                        data?.add(User("PARTICIPANT","","","","","",null,null))
                        expensePaidForAdapter?.submitList(data)
                    }
                }
            } else {
                expensePaidForAdapter?.submitList(emptyList())
            }
        })
    }

    private fun initBottomNavigationView() {
        bottomNavigationView = requireActivity().findViewById(R.id.bottom_nav)
    }


    private fun initFromScreenArgs() {
        try {
            argfromScreen = args.fromScreen
        } catch (ignored: Exception) {
        }
    }

    private fun deleteImageFile() = ImageUtil.deleteFileFromUri(requireContext(), argimageUri)

    private fun handleImageRequestResult(data: Intent?) {
        val imageUri: Uri = data?.data ?: return
        val inputStream = requireContext().contentResolver.openInputStream(imageUri)
        val inputBitmap = BitmapFactory.decodeStream(inputStream)
        val outputFile = ImageUtil.writeBitmapToFile(inputBitmap, requireContext())
        viewModel.setMutableImageUri(Uri.fromFile(outputFile))
    }

    private fun onGroupSelected(group: Groups) {
        //initParticipantShareObserver()
        resetDependentCollapsingViews()
        initRequiredFields(group)
        setUpExpensePaidForAdapter()
        shareAmountPaidToParticipants()
    }

    private fun initRequiredFields(group: Groups) {
        initParticipantsSharedLiveData(group)
        initSelectedGroup(group)
        initCurrencyCode(group)
        initAdminUserId()
    }

    private fun shareAmountPaidToParticipants() {
        val amountPerParticipant = amountPaid / currentNoOfParticipants
        if (listOfParticipantsShare.isNullOrEmpty()) {
            for (i in 0 until currentNoOfParticipants)
                listOfParticipantsShare.add(amountPerParticipant)
        } else {
            listOfParticipantsShare.forEachIndexed { index, fl ->
                if (fl != 0f || totalParticipants == currentNoOfParticipants)
                    listOfParticipantsShare[index] = amountPerParticipant
            }
        }

        viewModel.setParticipantsShareList(listOfParticipantsShare)
    }

    private fun initAdminUserId() {
        expensePaidByAdapter?.setAdminUserId(
            selectedGroup?.groupAdmin?.keys?.elementAtOrNull(0) ?: ""
        )
    }

    private fun initCurrencyCode(group: Groups) {
        binding.currency = group.currency
    }

    private fun initParticipantsSharedLiveData(group: Groups) {
        // Including admin
        val newListOfParticipantShare = ArrayList<Float>()
        val participantsCount = group.groupMembers.keys.size + 1
        viewModel.setParticipantsCount(participantsCount)
        viewModel.setParticipantsShareList(newListOfParticipantShare)

        totalParticipants = participantsCount
    }


    private fun initSelectedGroup(group: Groups) {
        selectedGroup = group
    }

    private fun dispatchUpdateToExpenseParticipantsAdapter() {
        shareAmountPaidToParticipants()
        expensePaidForAdapter?.notifyDataSetChanged()
    }

    private fun resetDependentCollapsingViews() {
        binding.customExpandExpensePaidBy.resetState()
        binding.customExpandExpensePaidFor.resetState()
    }

    private fun initSplitByPopUpWindow() {
        val popupWidth = resources.getDimension(R.dimen.split_menu_width).toInt()
        val popUpBinding = DataBindingUtil.inflate<LayoutSplitAmountBinding>(
            layoutInflater,
            R.layout.layout_split_amount,
            null,
            false
        )

        popUpWindow = PopupWindow(
            popUpBinding.root,
            ViewGroup.LayoutParams.WRAP_CONTENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )

        popUpWindow?.apply {
            isOutsideTouchable = true
            animationStyle = R.style.popup_split
            width = popupWidth
            setBackgroundDrawable(
                ContextCompat.getDrawable(
                    requireContext(),
                    R.drawable.bg_popup_menu
                )
            )
        }

        popUpBinding.apply {
            addExpenseViewModel = viewModel
            lifecycleOwner = viewLifecycleOwner
            radEqually.setOnClickListener { hideSplitByPopUp() }
            radUnequally.setOnClickListener { hideSplitByPopUp() }
        }
    }

    private fun showSplitByPopUp() {
        val btnSplit = binding.ibSplitAmountBy
        val loc = locateView(btnSplit)
        popUpWindow?.showAtLocation(
            view,
            Gravity.TOP or Gravity.CENTER,
            btnSplit.width * 2,
            loc.bottom
        )
        popUpWindow?.showAsDropDown(btnSplit)
        isSplitByMenuShowing = true
    }

    private fun hideSplitByPopUp() {
        popUpWindow?.dismiss()
        isSplitByMenuShowing = false
    }

    private fun locateView(view: View): Rect {
        val arrLoc = IntArray(2)
        view.getLocationOnScreen(arrLoc)
        val location = Rect()
        location.left = arrLoc[0]
        location.top = arrLoc[1]
        location.right = location.left + view.width
        location.bottom = location.top + view.height

        return location
    }

    private fun disposeAll() {
        compositeDisposable.clear()
        expensePaidForAdapter?.disposeAll()
    }

    /*private fun initParticipantShareObserver() {
        expensePaidForAdapter?.participantShareListLiveData?.observe(
            viewLifecycleOwner,
            Observer { listOfShare ->
                if (expensePaidForAdapter?.splitBy != KEY_EQUAL) {
                    var totalAmount = 0f
                    listOfShare?.forEach { perShare -> totalAmount += perShare }
                    if (totalAmount != amountPaid && totalAmount != 0f)
                        binding.etAddExpenseAmountPaid.text = totalAmount.toString().toEditable()
                }
            })
    }*/
}
