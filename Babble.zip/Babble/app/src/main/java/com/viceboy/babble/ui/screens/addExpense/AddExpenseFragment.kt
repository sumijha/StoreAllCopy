package com.viceboy.babble.ui.screens.addExpense

import android.app.Activity
import android.content.Intent
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.view.View
import android.widget.Toast
import androidx.lifecycle.Observer
import androidx.navigation.fragment.FragmentNavigatorExtras
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.viceboy.babble.R
import com.viceboy.babble.databinding.FragmentAddExpenseBinding
import com.viceboy.babble.di.Injectable
import com.viceboy.babble.ui.base.BaseFragment
import com.viceboy.babble.ui.base.EventObserver
import com.viceboy.babble.ui.state.Resource
import com.viceboy.babble.ui.util.Constants
import com.viceboy.babble.ui.util.ImageUtil
import com.viceboy.babble.ui.util.toggleBottomNavVisibility
import com.viceboy.data_repo.model.Groups

class AddExpenseFragment : BaseFragment<AddExpenseViewModel, FragmentAddExpenseBinding>(),
    Injectable {

    private lateinit var bottomNavigationView: BottomNavigationView

    private var amountPaid = 0f

    private var argfromScreen: String? = null
    private var argimageUri: Uri? = null
    private var groupListAdapter: GroupListAdapter? = null
    private var expensePaidByAdapter: ExpenseOwnerListAdapter? = null
    private var expensePaidForAdapter: ExpenseParticipantListAdapter? = null

    private val listOfParticipantsShare = ArrayList<Float>()
    private val args by navArgs<AddExpenseFragmentArgs>()

    override fun layoutRes(): Int = R.layout.fragment_add_expense

    override fun onCreateView() {
        initArgFromScreenStr()
        initBottomNavigationView()
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        setUpBottomNavVisibility()
        setUpBinding()
        setUpExpenseImage()
        setUpGroupNamesAdapter()
        setUpExpensePaidByAdapter()
        setUpExpensePaidForAdapter()
        super.onViewCreated(view, savedInstanceState)
    }

    override fun observeLiveData(
        viewModel: AddExpenseViewModel,
        binding: FragmentAddExpenseBinding
    ) {
        viewModel.datePickerLiveData.observe(viewLifecycleOwner, EventObserver {
            binding.tvSelectDate.text = it
        })

        viewModel.imageUriLiveData.observe(viewLifecycleOwner, Observer {
            it?.let {
                argimageUri = it
                binding.imageFile = it
                binding.tvFileName.text = it.lastPathSegment ?: ""
            }
        })

        viewModel.mutableAmountPaidLiveData.observe(viewLifecycleOwner, Observer {
            amountPaid = it.toFloat()
        })
    }


    override fun onDestroy() {
        showBottomNavigation()
        deleteImageFile()
        super.onDestroy()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (resultCode == Activity.RESULT_OK) {
            when (requestCode) {
                Constants.KEY_IMAGE_REQUEST_CODE -> handleImageRequestResult(data)
            }
        }
    }

    override val viewModelClass: Class<AddExpenseViewModel> = AddExpenseViewModel::class.java

    @Suppress("UNUSED_PARAMETER")
    fun onImageClick(view: View) {
        if (argimageUri != null) {
            argimageUri?.let {
                val extras = FragmentNavigatorExtras(
                    binding.ivItemImageGlide to it.scheme.toString(),
                    binding.tvFileName to it.encodedPath.toString()
                )
                findNavController().navigate(
                    AddExpenseFragmentDirections.actionAddExpenseFragmentToCaptureExpensePreviewFragment(
                        it
                    ), extras
                )
            }
        } else {
            setUpImagePicker()
        }
    }

    @Suppress("UNUSED_PARAMETER")
    fun onSelectDateTextViewClick(view: View) {
        findNavController().navigate(AddExpenseFragmentDirections.actionAddExpenseFragmentToSelectDateFragment())
    }

    private fun showBottomNavigation() {
        if (argfromScreen != null) {
            if (!argfromScreen.equals(Constants.KEY_FROM_CAPTURE_FRAGMENT)) {
                bottomNavigationView.toggleBottomNavVisibility(
                    View.VISIBLE,
                    bottomNavigationView
                )
            }
        } else {
            bottomNavigationView.toggleBottomNavVisibility(
                View.VISIBLE,
                bottomNavigationView
            )
        }
    }

    private fun setUpImagePicker() {
        val chooseIntent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
        chooseIntent.type = "image/*"
        startActivityForResult(
            Intent.createChooser(
                chooseIntent,
                resources.getString(R.string.select_image)
            ), Constants.KEY_IMAGE_REQUEST_CODE
        )
    }

    private fun setUpBinding() {
        binding.apply {
            lifecycleOwner = viewLifecycleOwner
            presenter = this@AddExpenseFragment
            addExpenseViewModel = viewModel
        }
    }

    private fun setUpExpenseImage() {
        arguments?.let {
            try {
                if (argimageUri == null)
                    argimageUri = args.photoFile
                argimageUri?.let {
                    viewModel.setMutableImageUri(it)
                }
            } catch (ignored: Exception) {
            }
        }
    }

    private fun setUpBottomNavVisibility() {
        if (bottomNavigationView.visibility == View.VISIBLE)
            bottomNavigationView.visibility = View.GONE
    }

    private fun setUpExpensePaidByAdapter() {
        this.expensePaidByAdapter = ExpenseOwnerListAdapter {
            Toast.makeText(
                requireContext(),
                "Selected Group is ${it.name}",
                Toast.LENGTH_LONG
            ).show()
        }

        expensePaidByAdapter?.let { binding.customExpandExpensePaidBy.setRecyclerAdapter(it) }

        initExpensePaidByList()
    }

    private fun initExpensePaidByList() {
        viewModel.groupMembersLiveData().observe(viewLifecycleOwner, Observer { userResource ->
            if (userResource != null) {
                when (userResource) {
                    is Resource.Success -> {
                        expensePaidByAdapter?.submitList(userResource.data)
                    }
                }
            } else {
                expensePaidByAdapter?.submitList(emptyList())
            }
        })
    }

    private fun setUpGroupNamesAdapter() {
        this.groupListAdapter = GroupListAdapter {
            Toast.makeText(
                requireContext(),
                "Selected Group is ${it.groupName}",
                Toast.LENGTH_LONG
            ).show()
            viewModel.onGroupNameSelected(it.id)
            onGroupSelected(it)
        }
        val innerView = binding.customExpandGroupNames.innerView
        if (innerView is RecyclerView) {
            innerView.adapter = groupListAdapter
        }

        initGroupNamesList()
    }

    private fun initGroupNamesList() {
        viewModel.groupsLiveData().observe(viewLifecycleOwner, Observer { groupResource ->
            if (groupResource != null) {
                when (groupResource) {
                    is Resource.Success -> {
                        groupListAdapter?.submitList(groupResource.data)
                    }
                }
            } else {
                groupListAdapter?.submitList(emptyList())
            }
        })
    }

    private fun setUpExpensePaidForAdapter() {
        this.expensePaidForAdapter = ExpenseParticipantListAdapter(listOfParticipantsShare) {
            Toast.makeText(
                requireContext(),
                "Selected Group is ${it.name}",
                Toast.LENGTH_LONG
            ).show()
        }

        expensePaidForAdapter?.let { binding.customExpandExpensePaidFor.setRecyclerAdapter(it) }

        initExpenseParticipantsList()
    }

    private fun initExpenseParticipantsList() {
        viewModel.groupMembersLiveData().observe(viewLifecycleOwner, Observer { userResource ->
            if (userResource != null) {
                when (userResource) {
                    is Resource.Success -> {
                        expensePaidForAdapter?.submitList(userResource.data)
                    }
                }
            } else {
                expensePaidForAdapter?.submitList(emptyList())
            }
        })
    }

    private fun initBottomNavigationView() {
        bottomNavigationView = requireActivity().findViewById(R.id.bottom_nav)
    }


    private fun initArgFromScreenStr() {
        try {
            argfromScreen = args.fromScreen
        } catch (ignored: Exception) {
        }
    }

    private fun deleteImageFile() = ImageUtil.deleteFileFromUri(requireContext(), argimageUri)

    private fun handleImageRequestResult(data: Intent?) {
        val imageUri: Uri = data?.data ?: return
        val inputStream = requireContext().contentResolver.openInputStream(imageUri)
        val inputBitmap = BitmapFactory.decodeStream(inputStream)
        val outputFile = ImageUtil.writeBitmapToFile(inputBitmap, requireContext())
        viewModel.setMutableImageUri(Uri.fromFile(outputFile))
    }

    private fun onGroupSelected(group: Groups) {
        resetDependentCollapsingViews()
        setCurrencyCode(group)
        shareAmountPaidToParticipants(group)
    }

    private fun shareAmountPaidToParticipants(group: Groups) {
        val listOfAmountPerParticipant = ArrayList<Float>()
        val noOfParticipants = group.groupMembers.keys.size+1
        val amountPerParticipant = amountPaid / noOfParticipants
        listOfAmountPerParticipant.removeAll(listOfAmountPerParticipant)
        for (i in 0 until noOfParticipants) {
            listOfAmountPerParticipant.add(amountPerParticipant)
        }
        expensePaidForAdapter?.setSplitAmountList(listOfAmountPerParticipant)
    }

    private fun setCurrencyCode(group: Groups) {
        binding.currency = group.currency
    }

    private fun resetDependentCollapsingViews() {
        binding.customExpandExpensePaidBy.resetState()
        binding.customExpandExpensePaidFor.resetState()
    }

}
