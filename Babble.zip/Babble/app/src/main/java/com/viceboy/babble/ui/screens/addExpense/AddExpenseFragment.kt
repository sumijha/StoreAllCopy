package com.viceboy.babble.ui.screens.addExpense

import android.app.Activity
import android.content.Intent
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.view.View
import androidx.lifecycle.Observer
import androidx.navigation.fragment.FragmentNavigatorExtras
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.viceboy.babble.R
import com.viceboy.babble.databinding.FragmentAddExpenseBinding
import com.viceboy.babble.di.Injectable
import com.viceboy.babble.ui.base.BaseFragment
import com.viceboy.babble.ui.base.EventObserver
import com.viceboy.babble.ui.util.Constants
import com.viceboy.babble.ui.util.ImageUtil
import com.viceboy.babble.ui.util.toggleBottomNavVisibility

class AddExpenseFragment : BaseFragment<AddExpenseViewModel, FragmentAddExpenseBinding>(),
    Injectable {

    private lateinit var bottomNavigationView: BottomNavigationView

    private var argfromScreen: String? = null
    private var argimageUri: Uri? = null

    private val args by navArgs<AddExpenseFragmentArgs>()

    override fun layoutRes(): Int = R.layout.fragment_add_expense

    override fun onCreateView() {
        initArgFromScreenStr()
        initBottomNavigationView()
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        setUpBottomNavVisibility()
        setUpBinding()
        setUpExpenseImage()
        super.onViewCreated(view, savedInstanceState)
    }

    override fun observeLiveData(
        viewModel: AddExpenseViewModel,
        binding: FragmentAddExpenseBinding
    ) {
        viewModel.datePickerLiveData.observe(viewLifecycleOwner, EventObserver {
            binding.tvSelectDate.text = it
        })
        viewModel.imageUriLiveData.observe(viewLifecycleOwner, Observer {
            it?.let {
                argimageUri = it
                binding.imageFile = it
                binding.tvFileName.text = it.lastPathSegment ?: ""
            }
        })
    }


    override fun onDestroy() {
        showBottomNavigation()
        deleteImageFile()
        super.onDestroy()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (resultCode == Activity.RESULT_OK) {
            when (requestCode) {
                Constants.KEY_IMAGE_REQUEST_CODE -> handleImageRequestResult(data)
            }
        }
    }

    override val viewModelClass: Class<AddExpenseViewModel> = AddExpenseViewModel::class.java

    @Suppress("UNUSED_PARAMETER")
    fun onImageClick(view: View) {
        if (argimageUri != null) {
            argimageUri?.let {
                val extras = FragmentNavigatorExtras(
                    binding.ivItemImageGlide to it.scheme.toString(),
                    binding.tvFileName to it.encodedPath.toString()
                )
                findNavController().navigate(
                    AddExpenseFragmentDirections.actionAddExpenseFragmentToCaptureExpensePreviewFragment(
                        it
                    ), extras
                )
            }
        } else {
            setUpImagePicker()
        }
    }

    @Suppress("UNUSED_PARAMETER")
    fun onSelectDateTextViewClick(view: View) {
        findNavController().navigate(AddExpenseFragmentDirections.actionAddExpenseFragmentToSelectDateFragment())
    }

    private fun setUpImagePicker() {
        val chooseIntent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
        chooseIntent.type = "image/*"
        startActivityForResult(
            Intent.createChooser(
                chooseIntent,
                resources.getString(R.string.select_image)
            ), Constants.KEY_IMAGE_REQUEST_CODE
        )
    }

    private fun setUpBinding() {
        binding.apply {
            lifecycleOwner = viewLifecycleOwner
            presenter = this@AddExpenseFragment
        }
    }

    private fun setUpExpenseImage() {
        arguments?.let {
            try {
                if (argimageUri == null)
                    argimageUri = args.photoFile
                argimageUri?.let {
                    viewModel.setMutableImageUri(it)
                }
            } catch (ignored: Exception) {
            }
        }
    }

    private fun setUpBottomNavVisibility() {
        if (bottomNavigationView.visibility == View.VISIBLE)
            bottomNavigationView.visibility = View.GONE
    }

    private fun initBottomNavigationView() {
        bottomNavigationView = requireActivity().findViewById(R.id.bottom_nav)
    }

    private fun initArgFromScreenStr() {
        try {
            argfromScreen = args.fromScreen
        } catch (ignored: Exception) {
        }
    }

    private fun showBottomNavigation() {
        if (argfromScreen != null) {
            if (!argfromScreen.equals(Constants.KEY_FROM_CAPTURE_FRAGMENT)) {
                bottomNavigationView.toggleBottomNavVisibility(
                    View.VISIBLE,
                    bottomNavigationView
                )
            }
        } else {
            bottomNavigationView.toggleBottomNavVisibility(
                View.VISIBLE,
                bottomNavigationView
            )
        }
    }

    private fun deleteImageFile() = ImageUtil.deleteFileFromUri(requireContext(), argimageUri)

    private fun handleImageRequestResult(data: Intent?) {
        val imageUri: Uri = data?.data ?: return
        val inputStream = requireContext().contentResolver.openInputStream(imageUri)
        val inputBitmap = BitmapFactory.decodeStream(inputStream)
        val outputFile = ImageUtil.writeBitmapToFile(inputBitmap, requireContext())
        viewModel.setMutableImageUri(Uri.fromFile(outputFile))
    }
}
