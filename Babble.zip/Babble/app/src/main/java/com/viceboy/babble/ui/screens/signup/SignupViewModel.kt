package com.viceboy.babble.ui.screens.signup

import androidx.lifecycle.ViewModel
import javax.inject.Inject

class SignupViewModel @Inject constructor(): ViewModel() {

}