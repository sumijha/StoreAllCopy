package com.viceboy.babble.ui.screens.groupDetails

import android.graphics.drawable.Drawable
import androidx.navigation.fragment.FragmentNavigator
import androidx.navigation.fragment.FragmentNavigatorExtras
import androidx.recyclerview.widget.DiffUtil
import com.bumptech.glide.load.DataSource
import com.bumptech.glide.load.engine.GlideException
import com.bumptech.glide.request.RequestListener
import com.bumptech.glide.request.target.Target
import com.viceboy.babble.R
import com.viceboy.babble.databinding.ItemGroupDetailsExpenseListBinding
import com.viceboy.babble.ui.base.DataBoundStateListAdapter
import com.viceboy.data_repo.model.uiModel.ExpenseLoadState
import com.viceboy.data_repo.model.uiModel.GroupExpense
import java.util.concurrent.atomic.AtomicBoolean


class ExpenseDetailsAdapter(
    private val callback: (ExpenseLoadState, FragmentNavigator.Extras) -> Unit
) :
    DataBoundStateListAdapter<ExpenseLoadState, ItemGroupDetailsExpenseListBinding>(
        diffCallback = object : DiffUtil.ItemCallback<ExpenseLoadState>() {
            override fun areItemsTheSame(
                oldItem: ExpenseLoadState,
                newItem: ExpenseLoadState
            ): Boolean =
                if (oldItem is GroupExpense && newItem is GroupExpense) {
                    oldItem.id == newItem.id
                } else false

            override fun areContentsTheSame(
                oldItem: ExpenseLoadState,
                newItem: ExpenseLoadState
            ): Boolean =
                if (oldItem is GroupExpense && newItem is GroupExpense) {
                    oldItem.itemName == newItem.itemName && oldItem.itemImage == newItem.itemImage
                } else false

        }
    ) {

    private val loadReady = AtomicBoolean(false)
    private var imageListener: RequestListener<Drawable>? = null

    init {
        imageListener = object : RequestListener<Drawable> {
            override fun onLoadFailed(
                e: GlideException?,
                model: Any?,
                target: Target<Drawable>?,
                isFirstResource: Boolean
            ): Boolean {
                loadReady.getAndSet(true)
                return false
            }

            override fun onResourceReady(
                resource: Drawable?,
                model: Any?,
                target: Target<Drawable>?,
                dataSource: DataSource?,
                isFirstResource: Boolean
            ): Boolean {
                loadReady.getAndSet(true)
                return false
            }
        }
    }

    override val progressLayoutRes: Int = R.layout.layout_progress_data_load
    override val emptyDataLayoutRes: Int = R.layout.layout_no_expense
    override val dataLayoutRes: Int = R.layout.item_group_details_expense_list

    override fun onSuccessDataBind(
        binding: ItemGroupDetailsExpenseListBinding,
        item: ExpenseLoadState
    ) {
        binding.expense = item as GroupExpense
        binding.imageRequestListener = imageListener
        binding.root.setOnClickListener {
            binding.expense?.let { groupExpense ->
                val extras = FragmentNavigatorExtras(
                    binding.ivItemLogo to groupExpense.id
                )
                if (loadReady.get()) callback(groupExpense, extras)
            }
        }
    }


}

