package com.viceboy.babble.ui.screens.groupDetails

import com.viceboy.babble.ui.base.DataBoundListAdapter

/*
class ExpenseDetailsAdapter : DataBoundListAdapter {

}*/
