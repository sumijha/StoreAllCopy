package com.viceboy.babble.ui.screens.dashboard.model

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
data class DashboardGroup(
    var groupId : String,
    var groupName: String,
    var groupCurrency: String,
    var owedText : String,
    var amountOwedByCurrentUser: Float,
    var lastTransactionBy: String?,
    var lastTransaction: Float?
) : Parcelable