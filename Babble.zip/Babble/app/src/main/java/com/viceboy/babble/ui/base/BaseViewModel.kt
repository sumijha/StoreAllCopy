package com.viceboy.babble.ui.base

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import io.reactivex.disposables.CompositeDisposable

abstract class BaseViewModel<ND> : ViewModel() {

    /**
     * Setting up LiveData for Navigation
     */
    private val _navigateToDestination = MutableLiveData<SingleLiveEvent<ND>>()
    val navigateToDestination: LiveData<SingleLiveEvent<ND>>
        get() = _navigateToDestination

    fun setNavigationFlag(destination: ND) {
        _navigateToDestination.value = SingleLiveEvent(destination)
    }


    /**
     * Setting up LiveData for SignUp Click Event
     */
    private val isClickedOnButton = MutableLiveData<Boolean>(false)
    val onClickEvent: LiveData<Boolean>
        get() = isClickedOnButton

    fun onButtonClick() {
        isClickedOnButton.value = true
    }

    fun resetButtonClickEvent() {
        isClickedOnButton.value = false
    }

    protected val compositeDisposable = CompositeDisposable()
    protected fun dispose() {
        if (!compositeDisposable.isDisposed)
            compositeDisposable.clear()
    }
}