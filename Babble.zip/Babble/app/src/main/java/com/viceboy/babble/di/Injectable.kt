package com.viceboy.babble.di

interface Injectable