package com.viceboy.babble.di

import dagger.Module

@Module
abstract class MainFragmentBindingModule {

}