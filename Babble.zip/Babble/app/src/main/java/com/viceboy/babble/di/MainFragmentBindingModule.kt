package com.viceboy.babble.di

import com.viceboy.babble.ui.dialog.SelectDateFragment
import com.viceboy.babble.ui.screens.addExpense.AddExpenseFragment
import com.viceboy.babble.ui.screens.addGroup.AddGroupFragment
import com.viceboy.babble.ui.screens.captureExpense.CaptureExpenseFragment
import com.viceboy.babble.ui.screens.dashboard.DashboardFragment
import dagger.Module
import dagger.android.ContributesAndroidInjector

@Module
abstract class MainFragmentBindingModule {
    @ContributesAndroidInjector
    abstract fun contributeLoginFragment(): DashboardFragment

    @ContributesAndroidInjector
    abstract fun contributeAddDashboardFragment(): AddGroupFragment

    @ContributesAndroidInjector
    abstract fun contributeAddExpenseFragment(): AddExpenseFragment

    @ContributesAndroidInjector
    abstract fun contributeCaptureExpenseFragment(): CaptureExpenseFragment

    @ContributesAndroidInjector
    abstract fun contributeSelectDateFragment(): SelectDateFragment
}