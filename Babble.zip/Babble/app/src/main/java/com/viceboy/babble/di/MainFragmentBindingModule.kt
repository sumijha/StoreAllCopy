package com.viceboy.babble.di

import com.viceboy.babble.ui.screens.dashboard.DashboardFragment
import com.viceboy.babble.ui.screens.login.LoginFragment
import dagger.Module
import dagger.android.ContributesAndroidInjector

@Module
abstract class MainFragmentBindingModule {
    @ContributesAndroidInjector
    abstract fun contributeLoginFragment(): DashboardFragment
}