package com.viceboy.babble.ui.screens.addExpense

import android.net.Uri
import androidx.lifecycle.LiveData
import androidx.lifecycle.MediatorLiveData
import androidx.lifecycle.MutableLiveData
import com.viceboy.babble.ui.base.BaseViewModel
import com.viceboy.babble.ui.base.SingleLiveEvent
import com.viceboy.babble.ui.state.Resource
import com.viceboy.babble.ui.util.Constants.KEY_EQUAL
import com.viceboy.babble.ui.util.Constants.KEY_UNEQUAL
import com.viceboy.babble.ui.util.addToCompositeDisposable
import com.viceboy.babble.ui.util.scheduleOnBackAndOutOnMain
import com.viceboy.data_repo.model.Groups
import com.viceboy.data_repo.model.User
import com.viceboy.data_repo.repository.GroupsRepository
import com.viceboy.data_repo.repository.UserRepository
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class AddExpenseViewModel @Inject constructor(
    private val userRepository: UserRepository,
    private val groupsRepository: GroupsRepository
) : BaseViewModel<Boolean>() {

    //Mutable LiveData to setup list of unchecked fields
    private val mutableListOfUncheckedFieldsLiveData = MutableLiveData<ArrayList<Int>>()
    val listOfUncheckedFieldsLiveData: LiveData<ArrayList<Int>>
        get() = mutableListOfUncheckedFieldsLiveData

    //Mutable LiveData to setup NoOfParticipants
    private val mutableParticipantsCountLiveData = MutableLiveData<Int>()
    val participantsCountLiveData: LiveData<Int>
        get() = mutableParticipantsCountLiveData

    //Mutable LiveData to setup Participants Share
    private val mutableParticipantsShareLiveData = MutableLiveData<ArrayList<Float>>()
    val participantsShareLiveData: LiveData<ArrayList<Float>>
        get() = mutableParticipantsShareLiveData

    // LiveData to setup two way binding in Amount Paid field
    val mutableAmountPaidLiveData = MutableLiveData<String>()

    // LiveData to setup two way binding in Split Amount Equally Radio
    val mutableSplitAmountEquallyRadLiveData = MutableLiveData<Boolean>(true)

    // LiveData to setup two way binding in Split Amount Unequally Radio
    val mutableSplitAmountUnequallyRadLiveData = MutableLiveData<Boolean>()

    // Mediator LiveData to observe Split Amount By RadioButtons
    private val mediatorOnSplitAmountBySelectLiveData = MediatorLiveData<String>()
    val splitAmountByLiveData: LiveData<String>
        get() = mediatorOnSplitAmountBySelectLiveData

    //Mutable LiveData to set Selected Group
    private var selectedGroupId = MutableLiveData<String>()

    //Mutable LiveData to setup image Uri received from image picker/Camera
    private val mutableImageUriLiveData = MutableLiveData<Uri>()
    val imageUriLiveData: LiveData<Uri>
        get() = mutableImageUriLiveData

    // Mutable LiveData to setup date received from SELECT DATE Dialog
    private val mutableDatePickerValLiveData = MutableLiveData<SingleLiveEvent<String>>()
    val datePickerLiveData: LiveData<SingleLiveEvent<String>>
        get() = mutableDatePickerValLiveData


    //Mutable LiveData to request focus on Base Amount
    private val mutableRequestFocusLiveData = MutableLiveData<Boolean>()
    val requestFocusLiveData: LiveData<Boolean>
        get() = mutableRequestFocusLiveData

    fun setMutableListOfUncheckedFields(list: ArrayList<Int>) {
        mutableListOfUncheckedFieldsLiveData.value = list
    }

    fun setMutableDate(value: String) {
        mutableDatePickerValLiveData.value = SingleLiveEvent(value)
    }

    fun setMutableRequestFocus(flag: Boolean) {
        mutableRequestFocusLiveData.value = flag
    }

    fun setMutableImageUri(uri: Uri) {
        mutableImageUriLiveData.value = uri
    }

    fun onGroupNameSelected(groupId: String) {
        selectedGroupId.value = groupId
    }

    fun setParticipantsCount(count: Int) {
        mutableParticipantsCountLiveData.value = count
    }

    fun setParticipantsShareList(list: ArrayList<Float>) {
        mutableParticipantsShareLiveData.value = list
    }

    /* Get List of Groups from Repository and returns a LiveData wrapped in Resource State */
    fun groupsLiveData(): LiveData<Resource<List<Groups>>> {
        val groupLiveData = MutableLiveData<Resource<List<Groups>>>()
        groupLiveData.value = Resource.Loading()
        userRepository.loadGroups(userRepository.getCurrentUserId())
            .scheduleOnBackAndOutOnMain()
            .addToCompositeDisposable(compositeDisposable, { listOfGroupId ->
                groupsRepository.loadGroupList(listOfGroupId.toTypedArray())
                    .scheduleOnBackAndOutOnMain()
                    .addToCompositeDisposable(compositeDisposable,
                        {
                            groupLiveData.value = Resource.Success(it)
                        }, {})
            }, {
                groupLiveData.value = Resource.Failure(it.message)
            })
        return groupLiveData
    }


    /* Get List of Users for a particular group from Repository and returns a LiveData wrapped in Resource State */
    fun groupMembersLiveData(): LiveData<Resource<List<User>>> {
        val groupMembersLiveData = MediatorLiveData<Resource<List<User>>>()
        groupMembersLiveData.addSource(selectedGroupId) { groupId ->
            groupId?.let { inputGroupId ->
                groupMembersLiveData.value = Resource.Loading()
                groupsRepository.loadGroupMembers(inputGroupId)
                    .scheduleOnBackAndOutOnMain()
                    .addToCompositeDisposable(compositeDisposable,
                        { listOfUserId ->
                            userRepository.loadUserList(listOfUserId.toTypedArray())
                                .scheduleOnBackAndOutOnMain()
                                .addToCompositeDisposable(compositeDisposable,
                                    {
                                        groupMembersLiveData.value = Resource.Success(it)
                                    }, {})
                        }, {
                            groupMembersLiveData.value = Resource.Failure(it.message)
                        }
                    )
            }
        }
        return groupMembersLiveData
    }

    private fun resetImageUriData() {
        mutableImageUriLiveData.value = null
    }

    init {
        mediatorOnSplitAmountBySelectLiveData.apply {
            addSource(mutableSplitAmountEquallyRadLiveData) {
                if (it) value = KEY_EQUAL
            }
        }

        mediatorOnSplitAmountBySelectLiveData.apply {
            addSource(mutableSplitAmountUnequallyRadLiveData) {
                if (it) value = KEY_UNEQUAL
            }
        }
    }

    override fun onCleared() {
        super.onCleared()
        resetImageUriData()
    }
}