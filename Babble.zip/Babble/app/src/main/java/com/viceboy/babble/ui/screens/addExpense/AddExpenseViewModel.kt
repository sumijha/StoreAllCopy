package com.viceboy.babble.ui.screens.addExpense

import android.net.Uri
import androidx.lifecycle.LiveData
import androidx.lifecycle.MediatorLiveData
import androidx.lifecycle.MutableLiveData
import com.viceboy.babble.ui.base.BaseViewModel
import com.viceboy.babble.ui.base.SingleLiveEvent
import com.viceboy.babble.ui.state.Resource
import com.viceboy.babble.ui.util.addToCompositeDisposable
import com.viceboy.babble.ui.util.scheduleOnBackAndOutOnMain
import com.viceboy.data_repo.model.Groups
import com.viceboy.data_repo.model.User
import com.viceboy.data_repo.repository.GroupsRepository
import com.viceboy.data_repo.repository.UserRepository
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class AddExpenseViewModel @Inject constructor(
    private val userRepository: UserRepository,
    private val groupsRepository: GroupsRepository
) : BaseViewModel<Boolean>() {

    // LiveData to setup two way binding in Amount Paid field
    val mutableAmountPaidLiveData = MutableLiveData<String>()

    private var selectedGroupId = MutableLiveData<String>()

    private val mutableImageUriLiveData = MutableLiveData<Uri>()
    val imageUriLiveData: LiveData<Uri>
        get() = mutableImageUriLiveData

    private val mutableDatePickerValLiveData = MutableLiveData<SingleLiveEvent<String>>()
    val datePickerLiveData: LiveData<SingleLiveEvent<String>>
        get() = mutableDatePickerValLiveData

    fun setMutableDate(value: String) {
        mutableDatePickerValLiveData.value = SingleLiveEvent(value)
    }

    fun setMutableImageUri(uri: Uri) {
        mutableImageUriLiveData.value = uri
    }

    fun onGroupNameSelected(groupId: String) {
        selectedGroupId.value = groupId
    }

    /* Get List of Groups from Repository and returns a LiveData wrapped in Resource State */
    fun groupsLiveData(): LiveData<Resource<List<Groups>>> {
        val groupLiveData = MutableLiveData<Resource<List<Groups>>>()
        groupLiveData.value = Resource.Loading()
        userRepository.loadGroups(userRepository.getCurrentUserId())
            .scheduleOnBackAndOutOnMain()
            .addToCompositeDisposable(compositeDisposable, { listOfGroupId ->
                groupsRepository.loadGroupList(listOfGroupId.toTypedArray())
                    .scheduleOnBackAndOutOnMain()
                    .addToCompositeDisposable(compositeDisposable,
                        {
                            groupLiveData.value = Resource.Success(it)
                        }, {})
            }, {
                groupLiveData.value = Resource.Failure(it.message)
            })
        return groupLiveData
    }


    /* Get List of Users for a particular group from Repository and returns a LiveData wrapped in Resource State */
    fun groupMembersLiveData(): LiveData<Resource<List<User>>> {
        val groupMembersLiveData = MediatorLiveData<Resource<List<User>>>()
        groupMembersLiveData.addSource(selectedGroupId) { groupId ->
            groupId?.let { inputGroupId ->
                groupMembersLiveData.value = Resource.Loading()
                groupsRepository.loadGroupMembers(inputGroupId)
                    .scheduleOnBackAndOutOnMain()
                    .addToCompositeDisposable(compositeDisposable,
                        { listOfUserId ->
                            userRepository.loadUserList(listOfUserId.toTypedArray())
                                .scheduleOnBackAndOutOnMain()
                                .addToCompositeDisposable(compositeDisposable,
                                    {
                                        groupMembersLiveData.value = Resource.Success(it)
                                    }, {})
                        }, {
                            groupMembersLiveData.value = Resource.Failure(it.message)
                        }
                    )
            }
        }
        return groupMembersLiveData
    }

    private fun resetImageUriData() {
        mutableImageUriLiveData.value = null
    }


    override fun onCleared() {
        super.onCleared()
        resetImageUriData()
    }
}