package com.viceboy.babble.ui.screens.addExpense

import android.net.Uri
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.viceboy.babble.ui.base.BaseViewModel
import com.viceboy.babble.ui.base.SingleLiveEvent
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class AddExpenseViewModel @Inject constructor() : BaseViewModel<Boolean>() {

    private val mutableImageUriLiveData = MutableLiveData<Uri>()
    val imageUriLiveData: LiveData<Uri>
        get() = mutableImageUriLiveData

    private val mutableDatePickerValLiveData = MutableLiveData<SingleLiveEvent<String>>()
    val datePickerLiveData: LiveData<SingleLiveEvent<String>>
        get() = mutableDatePickerValLiveData

    fun setMutableDate(value: String) {
        mutableDatePickerValLiveData.value = SingleLiveEvent(value)
    }

    fun setMutableImageUri(uri: Uri) {
        mutableImageUriLiveData.value = uri
    }

    private fun resetImageUriData() {
        mutableImageUriLiveData.value = null
    }

    override fun onCleared() {
        super.onCleared()
        resetImageUriData()
    }
}