package com.viceboy.babble.ui.screens.addExpense

import com.viceboy.babble.ui.base.BaseViewModel
import javax.inject.Inject

class AddExpenseViewModel @Inject constructor(): BaseViewModel<Boolean>() {

}