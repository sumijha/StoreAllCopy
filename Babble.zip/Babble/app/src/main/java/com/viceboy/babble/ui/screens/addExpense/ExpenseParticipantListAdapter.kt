package com.viceboy.babble.ui.screens.addExpense

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.DiffUtil
import com.jakewharton.rxbinding3.widget.textChanges
import com.viceboy.babble.R
import com.viceboy.babble.databinding.ItemNewExpenseAmountPaidForListBinding
import com.viceboy.babble.ui.base.DataBoundListAdapter
import com.viceboy.babble.ui.base.DataBoundViewHolder
import com.viceboy.babble.ui.util.Constants.KEY_EQUAL
import com.viceboy.babble.ui.util.Constants.KEY_UNEQUAL
import com.viceboy.babble.ui.util.toEditable
import com.viceboy.data_repo.model.User
import io.reactivex.disposables.CompositeDisposable


class ExpenseParticipantListAdapter constructor(
    private val viewLifecycleOwner: LifecycleOwner,
    private val addExpenseViewModel: AddExpenseViewModel,
    private var listOfParticipantShare: ArrayList<Float>,
    private val onCheckBoxClick: (Int) -> Unit
) :
    DataBoundListAdapter<User, ItemNewExpenseAmountPaidForListBinding>(
        diffCallback = object : DiffUtil.ItemCallback<User>() {
            override fun areItemsTheSame(oldItem: User, newItem: User): Boolean = false

            override fun areContentsTheSame(oldItem: User, newItem: User): Boolean = false
        }
    ) {


    private var textDisposable = CompositeDisposable()
    private var totalAmount = 0f
    private var noOfParticipants = 0
    var splitBy: String = ""


    override fun inflateBinding(viewGroup: ViewGroup): ItemNewExpenseAmountPaidForListBinding {
        initRequiredObserver()
        return DataBindingUtil.inflate(
            LayoutInflater.from(viewGroup.context),
            R.layout.item_new_expense_amount_paid_for_list,
            viewGroup,
            false
        )
    }

    override fun onBindViewHolder(
        holder: DataBoundViewHolder<ItemNewExpenseAmountPaidForListBinding>,
        position: Int
    ) {
        initCheckBoxListener(holder)
        initEditTextFocusChangeListener(holder)
        initTextDisposable(holder)
        setParticipantShareText(holder, position)
        setUpViewBasedOnSplitBy(holder)

        super.onBindViewHolder(holder, position)
    }

    override fun bind(binding: ItemNewExpenseAmountPaidForListBinding, item: User) {
        binding.user = item
    }

    private fun resetSplitAmount(position: Int, checked: Boolean) {
        val perShare: Float
        if (checked) {
            perShare = totalAmount / noOfParticipants
            listOfParticipantShare[position] = perShare
        } else {
            listOfParticipantShare[position] = 0f
            perShare = totalAmount / noOfParticipants
        }

        listOfParticipantShare.forEachIndexed { index, fl ->
            if (fl != 0f) listOfParticipantShare[index] = perShare
        }

        notifyObservers(noOfParticipants, listOfParticipantShare)
    }


    private fun initCheckBoxListener(holder: DataBoundViewHolder<ItemNewExpenseAmountPaidForListBinding>) {
        holder.binding.cbAmountPaidForSelectParticipant.setOnCheckedChangeListener { _, isChecked ->
            when (splitBy) {
                KEY_EQUAL -> handleSplitEqually(holder, isChecked)

                KEY_UNEQUAL -> handleSplitUnequally(holder, isChecked)
            }
        }
    }

    private fun initTextDisposable(holder: DataBoundViewHolder<ItemNewExpenseAmountPaidForListBinding>) {
        if (splitBy != KEY_EQUAL && textDisposable.size() < itemCount)
            textDisposable.add(
                holder.binding.etAmountPaidForParticipantShare.textChanges()
                    .subscribe({
                        listOfParticipantShare[holder.adapterPosition] = it.toString().toFloat()
                        addExpenseViewModel.setParticipantsShareList(listOfParticipantShare)
                        //notifyDataSetChanged()
                    }, {})
            )
    }

    private fun setParticipantShareText(
        holder: DataBoundViewHolder<ItemNewExpenseAmountPaidForListBinding>,
        position: Int
    ) {
        holder.binding.etAmountPaidForParticipantShare.text =
            listOfParticipantShare[position].toString().toEditable()
    }

    private fun setUpViewBasedOnSplitBy(holder: DataBoundViewHolder<ItemNewExpenseAmountPaidForListBinding>) {
        if (splitBy == KEY_EQUAL) {
            textDisposable.clear()
            holder.binding.etAmountPaidForParticipantShare.isEnabled = false
        } else {
            val etParticipant = holder.binding.etAmountPaidForParticipantShare
            val cbParticipant = holder.binding.cbAmountPaidForSelectParticipant
            etParticipant.clearFocus()
            if (!etParticipant.isEnabled && cbParticipant.isChecked) {
                etParticipant.isEnabled = true
            }
        }
    }

    private fun initRequiredObserver() {
        addExpenseViewModel.participantsCountLiveData.observe(viewLifecycleOwner, Observer {
            noOfParticipants = it
        })

        addExpenseViewModel.mutableAmountPaidLiveData.observe(viewLifecycleOwner, Observer {
            totalAmount = it.toFloat()
        })

        addExpenseViewModel.participantsShareLiveData.observe(viewLifecycleOwner, Observer {
            listOfParticipantShare = it
        })
    }

    private fun handleSplitUnequally(
        holder: DataBoundViewHolder<ItemNewExpenseAmountPaidForListBinding>,
        isChecked: Boolean
    ) {
        if (!isChecked) {
            listOfParticipantShare[holder.adapterPosition] = 0f
            addExpenseViewModel.setParticipantsShareList(listOfParticipantShare)
            holder.binding.etAmountPaidForParticipantShare.clearFocus()
            holder.binding.etAmountPaidForParticipantShare.isEnabled = false
            addExpenseViewModel.setMutableRequestFocus(true)
            notifyDataSetChanged()
        } else {
            if (!holder.binding.etAmountPaidForParticipantShare.isEnabled)
                holder.binding.etAmountPaidForParticipantShare.isEnabled = true
        }
    }

    private fun handleSplitEqually(
        holder: DataBoundViewHolder<ItemNewExpenseAmountPaidForListBinding>,
        isChecked: Boolean
    ) {
        if (isChecked) {
            if (noOfParticipants < itemCount) {
                noOfParticipants++
                resetSplitAmount(holder.adapterPosition, isChecked)
            }
        } else {
            noOfParticipants--
            resetSplitAmount(holder.adapterPosition, isChecked)
        }
    }

    private fun notifyObservers(count: Int, listOfParticipantShare: ArrayList<Float>) {
        addExpenseViewModel.setParticipantsCount(count)
        addExpenseViewModel.setParticipantsShareList(listOfParticipantShare)
        notifyDataSetChanged()
    }

    private fun initEditTextFocusChangeListener(holder: DataBoundViewHolder<ItemNewExpenseAmountPaidForListBinding>) {
        holder.binding.etAmountPaidForParticipantShare.setOnFocusChangeListener { v, hasFocus ->
            if (!hasFocus && splitBy == KEY_UNEQUAL)
                notifyDataSetChanged()
        }
    }

    fun disposeAll() {
        textDisposable.clear()
    }
}