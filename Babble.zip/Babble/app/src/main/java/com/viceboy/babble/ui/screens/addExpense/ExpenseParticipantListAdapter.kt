package com.viceboy.babble.ui.screens.addExpense

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.DiffUtil
import com.viceboy.babble.R
import com.viceboy.babble.databinding.ItemNewExpenseAmountPaidForListBinding
import com.viceboy.babble.ui.base.DataBoundListAdapter
import com.viceboy.babble.ui.base.DataBoundViewHolder
import com.viceboy.babble.ui.util.toEditable
import com.viceboy.data_repo.model.User

class ExpenseParticipantListAdapter(private var amountSplitArray : ArrayList<Float> ,private val callback: (User) -> Unit) :
    DataBoundListAdapter<User, ItemNewExpenseAmountPaidForListBinding>(
        diffCallback = object : DiffUtil.ItemCallback<User>() {
            override fun areItemsTheSame(oldItem: User, newItem: User): Boolean {
                return oldItem.id == newItem.id
            }

            override fun areContentsTheSame(oldItem: User, newItem: User): Boolean {
                return oldItem.name == newItem.name && oldItem.email == newItem.email
            }
        }
    ) {

    override fun inflateBinding(viewGroup: ViewGroup): ItemNewExpenseAmountPaidForListBinding {
        val binding =
            DataBindingUtil.inflate<ItemNewExpenseAmountPaidForListBinding>(
                LayoutInflater.from(viewGroup.context),
                R.layout.item_new_expense_amount_paid_for_list,
                viewGroup,
                false
            )
        binding.rootItemExpensePaidFor.setOnClickListener {
            binding.user.let {
                it?.let { callback.invoke(it) }
            }
        }
        return binding
    }

    override fun onBindViewHolder(
        holder: DataBoundViewHolder<ItemNewExpenseAmountPaidForListBinding>,
        position: Int
    ) {
        holder.binding.etAmountPaidForParticipantShare.text = amountSplitArray[position].toString().toEditable()
        super.onBindViewHolder(holder, position)
    }

    override fun bind(binding: ItemNewExpenseAmountPaidForListBinding, item: User) {
        binding.user = item
    }

    fun setSplitAmountList(listOfAmount:ArrayList<Float>) {
        amountSplitArray = listOfAmount
    }

}