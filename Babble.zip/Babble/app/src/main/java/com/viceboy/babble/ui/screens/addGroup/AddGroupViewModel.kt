package com.viceboy.babble.ui.screens.addGroup

import androidx.lifecycle.LiveData
import androidx.lifecycle.MediatorLiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Transformations
import com.viceboy.babble.ui.base.BaseViewModel
import com.viceboy.babble.ui.state.Resource
import com.viceboy.babble.ui.state.SearchState
import com.viceboy.babble.ui.util.addToCompositeDisposable
import com.viceboy.babble.ui.util.isEmailPattern
import com.viceboy.data_repo.model.User
import com.viceboy.data_repo.repository.UserRepository
import javax.inject.Inject

class AddGroupViewModel @Inject constructor(
    private val userRepository: UserRepository
) : BaseViewModel<Boolean>() {

    private var emailText: String = ""

    // Setting up two way binding for Add Participants text field
    val mutableSearchParticipantsTextLiveData = MutableLiveData<String>()

    // Setting up mutableLiveData to trigger search event
    private val mutableSearchClickEventLiveData = MutableLiveData<Boolean>()

    private val mutableSearchStateLiveData = MutableLiveData<SearchState>()
    val searchStateLiveData: LiveData<SearchState>
        get() = mutableSearchStateLiveData

    private val mutableUserLiveData = MutableLiveData<Resource<User>>()
    private val mutableListOfCheckedEvents = mutableListOf<String>()
    private val listOfCheckedSearchEvent = listOf(KEY_CLICK_EVENT, KEY_TEXT_EVENT)
    private val mediatorListOfCheckedEventLiveData = MediatorLiveData<List<String>>()
    val listOfCheckedEventLiveData = Transformations.switchMap(mediatorListOfCheckedEventLiveData) {
        if (it.containsAll(listOfCheckedSearchEvent)) {
            mutableUserLiveData.value = Resource.Loading()
            userRepository.loadUserByEmail(emailText).addToCompositeDisposable(compositeDisposable,
                { user ->
                    mutableUserLiveData.value = Resource.Success(user)
                }, { throwable ->
                    mutableUserLiveData.value = Resource.Failure(throwable.message)
                }, {
                    mutableUserLiveData.value =
                        Resource.Failure("Unable to find the searched user $emailText")
                })
        }
        return@switchMap mutableUserLiveData
    }

    fun setSearchState(searchState: SearchState) {
        mutableSearchStateLiveData.value = searchState
    }

    fun onSearchClickEvent() {
        if (emailText.isNotEmpty() && emailText.isEmailPattern())
            mutableSearchClickEventLiveData.value = true
    }

    fun resetSearchClickEvent() {
        mutableSearchClickEventLiveData.value = false
    }

    fun resetSearchStateEventLiveData() {
        mutableSearchStateLiveData.value = SearchState.IDLE
    }


    /** Add sources mediator List of search events LiveData */
    private fun addSourcesToMediatorListOfSearchEvents() {
        mediatorListOfCheckedEventLiveData.apply {
            addSource(mutableSearchParticipantsTextLiveData) {
                if (it.isNotEmpty() && it.isEmailPattern()) {
                    mutableListOfCheckedEvents.add(KEY_TEXT_EVENT)
                    emailText = it
                } else
                    mutableListOfCheckedEvents.remove(KEY_TEXT_EVENT)
                value = mutableListOfCheckedEvents
            }

            addSource(mutableSearchClickEventLiveData) {
                if (it)
                    mutableListOfCheckedEvents.add(KEY_CLICK_EVENT)
                else
                    mutableListOfCheckedEvents.remove(KEY_CLICK_EVENT)
                value = mutableListOfCheckedEvents
            }
        }
    }

    init {
        addSourcesToMediatorListOfSearchEvents()
    }

    companion object {
        private const val KEY_CLICK_EVENT = "click_event"
        private const val KEY_TEXT_EVENT = "empty_text_event"
    }
}