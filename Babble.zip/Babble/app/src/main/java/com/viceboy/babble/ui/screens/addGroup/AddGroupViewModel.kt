package com.viceboy.babble.ui.screens.addGroup

import com.viceboy.babble.ui.base.BaseViewModel
import javax.inject.Inject

class AddGroupViewModel @Inject constructor(): BaseViewModel<Boolean>() {

}