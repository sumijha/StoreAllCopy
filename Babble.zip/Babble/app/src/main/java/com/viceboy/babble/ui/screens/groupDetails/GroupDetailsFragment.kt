package com.viceboy.babble.ui.screens.groupDetails

import androidx.lifecycle.ViewModelProviders
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup

import com.viceboy.babble.R
import com.viceboy.babble.databinding.FragmentGroupDetailsBinding
import com.viceboy.babble.ui.base.BaseHomeFragment

class GroupDetailsFragment : BaseHomeFragment<GroupDetailsViewModel,FragmentGroupDetailsBinding>() {
    override fun layoutRes(): Int =  R.layout.fragment_group_details

    override fun onCreateView() = Unit

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        setUpViewPager()
        super.onViewCreated(view, savedInstanceState)
    }

    override fun observeLiveData(
        viewModel: GroupDetailsViewModel,
        binding: FragmentGroupDetailsBinding
    ) {
        TODO("Not yet implemented")
    }

    override val viewModelClass: Class<GroupDetailsViewModel> = GroupDetailsViewModel::class.java
    override val hasBottomNavigationView: Boolean = false

    private fun setUpViewPager() {

    }

}
