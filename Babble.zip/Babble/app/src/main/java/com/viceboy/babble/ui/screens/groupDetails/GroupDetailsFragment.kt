package com.viceboy.babble.ui.screens.groupDetails

import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.View
import androidx.core.content.ContextCompat
import androidx.lifecycle.Observer
import androidx.navigation.fragment.navArgs
import androidx.viewpager2.widget.ViewPager2
import com.github.mikephil.charting.data.Entry
import com.github.mikephil.charting.data.PieData
import com.github.mikephil.charting.data.PieDataSet
import com.google.android.material.tabs.TabLayoutMediator
import com.viceboy.babble.R
import com.viceboy.babble.databinding.FragmentGroupDetailsBinding
import com.viceboy.babble.di.Injectable
import com.viceboy.babble.ui.base.BaseHomeFragment
import com.viceboy.babble.ui.state.Resource
import com.viceboy.babble.ui.util.toEditable

class GroupDetailsFragment :
    BaseHomeFragment<GroupDetailsViewModel, FragmentGroupDetailsBinding>(), Injectable {

    private lateinit var groupTabAdapter: GroupViewPagerAdapter

    private var mapOfUserAndExpense = mutableMapOf<String, Float>()
    private val listOfTabTitles = listOf("Members", "Expenses", "Transactions")

    private val navArgs by navArgs<GroupDetailsFragmentArgs>()

    override fun layoutRes(): Int = R.layout.fragment_group_details

    override fun onCreateView() = Unit

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        initSelectedGroupValue()
        initGroupDetailsTabAdapter()
        setUpViewPager()
        setUpPieChart()
        super.onViewCreated(view, savedInstanceState)
    }

    override fun observeLiveData(
        viewModel: GroupDetailsViewModel,
        binding: FragmentGroupDetailsBinding
    ) {
        viewModel.groupLiveData.observe(viewLifecycleOwner, Observer {
            viewModel.initDataLoad(it)
        })

        viewModel.groupMembersLiveData.observe(viewLifecycleOwner, Observer {
            when (it) {
                is Resource.Success -> {
                    val listOfGroupMembers = it.data
                    listOfGroupMembers?.forEach {
                        mapOfUserAndExpense[it.name] = Math.abs(it.amountPaid)
                    }
                    if (mapOfUserAndExpense.isNotEmpty()) addDataSet(mapOfUserAndExpense)
                }
            }
        })
    }

    override val viewModelClass: Class<GroupDetailsViewModel> = GroupDetailsViewModel::class.java
    override val hasBottomNavigationView: Boolean = false

    private fun initSelectedGroupValue() {
        arguments?.let {
            val group = navArgs.group
            viewModel.setSelectedGroup(group)
            binding.tvGroupName.text = group.groupName.toEditable()
        }
    }

    private fun initGroupDetailsTabAdapter() {
        groupTabAdapter = GroupViewPagerAdapter(requireActivity())
    }


    private fun setUpViewPager() {
        binding.groupTabsPager.adapter = groupTabAdapter
        TabLayoutMediator(binding.groupDetailsTabLayout, binding.groupTabsPager) { tab, position ->
            tab.text = listOfTabTitles[position]
        }.attach()

        binding.groupTabsPager.registerOnPageChangeCallback(object :
            ViewPager2.OnPageChangeCallback() {
            override fun onPageSelected(position: Int) {
                binding.groupTabsPager.requestLayout()
                viewModel.setPageIndex(position)
                super.onPageSelected(position)
            }
        })
    }

    private fun addDataSet(mapOfExpenseByUser: MutableMap<String, Float>) {
        val listOfEntry = mapOfExpenseByUser.keys.mapIndexed { index, key ->
            Entry(mapOfExpenseByUser[key] ?: 0f, index)
        }
        val dataSet = PieDataSet(listOfEntry, TXT_PIE_DESC)
        dataSet.apply {
            setColors(CUSTOM_PIE_CHART_COLOR)
            sliceSpace = 4f
            selectionShift = 5f
        }
        val groupName = mapOfExpenseByUser.keys.toList()
        val data = PieData(groupName, dataSet)
        data.apply {
            setValueTextSize(12f)
            setValueTypeface(Typeface.SANS_SERIF)
            setValueTextColor(ContextCompat.getColor(requireContext(), R.color.white));
        }
        binding.expensePieChart.apply {
            this.data = data
            invalidate()
        }
    }

    private fun setUpPieChart() {
        binding.expensePieChart.apply {
            setDescription(null)
            setUsePercentValues(false)
            setExtraOffsets(5f, 10f, 5f, 10f)
            setHoleColor(Color.WHITE)
            setTransparentCircleAlpha(110)
            holeRadius = 60f
            transparentCircleRadius = 60f;
            centerText = "$23000"
            setCenterTextSize(21f)
            setCenterTextColor(Color.rgb(80, 150, 80))
            setDrawCenterText(true)
            isDrawHoleEnabled = true

            legend.isEnabled = false
        }
        binding.expensePieChart.animateXY(1000, 1000)
    }

    companion object {

        private const val TXT_PIE_DESC = "Amount paid in each group"
        private val CUSTOM_PIE_CHART_COLOR = intArrayOf(
            Color.rgb(150, 220, 120),
            Color.rgb(130, 212, 110),
            Color.rgb(145, 200, 100),
            Color.rgb(140, 174, 100),
            Color.rgb(146, 179, 100)
        )
    }

}
