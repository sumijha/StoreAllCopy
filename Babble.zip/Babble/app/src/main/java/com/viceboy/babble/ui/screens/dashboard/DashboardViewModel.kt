package com.viceboy.babble.ui.screens.dashboard

import android.content.Context
import android.widget.Toast
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.google.gson.internal.LinkedTreeMap
import com.viceboy.babble.ui.base.BaseViewModel
import com.viceboy.babble.ui.base.SingleLiveEvent
import com.viceboy.babble.ui.screens.dashboard.model.DashboardGroup
import com.viceboy.babble.ui.screens.dashboard.model.DashboardMembers
import com.viceboy.babble.ui.state.ButtonState
import com.viceboy.babble.ui.state.Resource
import com.viceboy.babble.ui.util.addToCompositeDisposable
import com.viceboy.babble.ui.util.scheduleOnBackAndOutOnMain
import com.viceboy.data_repo.repository.ExpenseRepository
import com.viceboy.data_repo.repository.GroupsRepository
import com.viceboy.data_repo.repository.UserRepository
import javax.inject.Inject
import kotlin.collections.List as List1

class DashboardViewModel @Inject constructor(
    private val context: Context,
    private val userRepository: UserRepository,
    private val expenseRepository: ExpenseRepository,
    private val groupsRepository: GroupsRepository
) : BaseViewModel<Int>() {

    private val navigateMutableLiveData = MutableLiveData<SingleLiveEvent<Int>>()
    val navigateLiveData: LiveData<SingleLiveEvent<Int>>
        get() = navigateMutableLiveData

    private var buttonClicked = false

    private val mutableMainFabButtonStateLiveData = MutableLiveData<ButtonState>()
    val mainFabButtonStateLiveData: LiveData<ButtonState>
        get() = mutableMainFabButtonStateLiveData

    private val mutableAnimFabOptionsLiveData = MutableLiveData<SingleLiveEvent<Boolean>>()
    val animFabLiveData: LiveData<SingleLiveEvent<Boolean>>
        get() = mutableAnimFabOptionsLiveData

    fun onMainFabClicked() {
        if (!buttonClicked) {
            mutableMainFabButtonStateLiveData.value = ButtonState.CLICKED
            mutableAnimFabOptionsLiveData.value = SingleLiveEvent(true)
            buttonClicked = true
        } else {
            mutableMainFabButtonStateLiveData.value = ButtonState.ACTIVE
            mutableAnimFabOptionsLiveData.value = SingleLiveEvent(true)
            buttonClicked = false
        }
    }

    fun resetMainFabStateWithAnimation() {
        buttonClicked = false
        mutableMainFabButtonStateLiveData.value = ButtonState.ACTIVE
        mutableAnimFabOptionsLiveData.value = SingleLiveEvent(true)
    }

    fun navigateTo(destinationId: Int) {
        setNavigationFlag(destinationId, navigateMutableLiveData)
    }

    /* Get List of Groups from Repository and returns a LiveData wrapped in Resource State */
    fun groupsLiveData(): LiveData<Resource<List1<DashboardGroup>>> {
        val listOfDashboardGroup = mutableListOf<DashboardGroup>()
        val groupLiveData = MutableLiveData<Resource<List1<DashboardGroup>>>()
        groupLiveData.value = Resource.Loading()
        userRepository.loadGroups(userRepository.getCurrentUserId())
            .flatMap {
                groupsRepository.loadGroupList(it.toTypedArray())
            }
            .flatMapIterable { it }
            .map { group ->
                val mapOfExpense = (group.groupAdmin as LinkedTreeMap<*, *>).entries.firstOrNull {
                    it.key == userRepository.getCurrentUserId()
                }
                    ?: (group.groupMembers as LinkedTreeMap<*, *>).entries.firstOrNull { it.key == userRepository.getCurrentUserId() }
                val amount =
                    (mapOfExpense?.value as LinkedTreeMap<*, *>)["amount"]?.toString()?.toFloat()
                        ?: 0f
                val owedText = if (amount < 0) "You owe" else "You are owed"
                DashboardGroup(
                    group.id,
                    group.groupName,
                    group.currency,
                    owedText,
                    amount,
                    null,
                    null
                )
            }.map {
                val dash = it
                expenseRepository.loadExpenseByGroupId(it.groupId)
                    .map { listOfExpense ->
                        expenseRepository.loadLatestExpense(listOfExpense.toTypedArray())
                    }.flatMap { expense ->
                        dash.amountOwedByCurrentUser = expense.amountPaid
                        userRepository.loadUser(expense.expenseOwner)
                    }.map { user ->
                        val lastTransactionBy = if (user.id == userRepository.getCurrentUserId())
                            "Last Transaction By You"
                        else
                            "Last Transaction By ${user.name}"
                        dash.lastTransactionBy = lastTransactionBy
                        listOfDashboardGroup.add(dash)
                        listOfDashboardGroup
                    }
            }.flatMap { it }
            .scheduleOnBackAndOutOnMain()
            .addToCompositeDisposable(compositeDisposable, {
                groupLiveData.value = Resource.Success(it)
                Toast.makeText(
                    context,
                    "List of dashboard group size is ${it.size}",
                    Toast.LENGTH_SHORT
                ).show()
            }, {
                groupLiveData.value = Resource.Failure(it.message)
                Toast.makeText(context, "Failure is ${it.message}", Toast.LENGTH_SHORT)
                    .show()
            })
        return groupLiveData
    }

    fun loadDashboardUsersLiveData(): LiveData<Resource<List1<DashboardMembers>>> {
        val membersLiveData = MutableLiveData<Resource<List1<DashboardMembers>>>()
        val distinctMembers = mutableSetOf<String>()
        val listOfMembersModel = mutableSetOf<DashboardMembers>()
        membersLiveData.value = Resource.Loading()
        userRepository.loadGroups(userRepository.getCurrentUserId())
            .flatMapIterable { it }
            .flatMap {
                groupsRepository.loadGroupMembers(it)
                    .map {
                        distinctMembers.addAll(it)
                        distinctMembers.filter { it != userRepository.getCurrentUserId() }
                    }
            }.flatMap {
                userRepository.loadUserList(it.toTypedArray())
                    .flatMapIterable { it }
                    .flatMap { user ->
                        val dashboardMemberModel =
                            DashboardMembers(user.id, user.name, user.avatar_url, null)
                        val userGroupsArray = user.groups?.toTypedArray()
                        groupsRepository.loadGroupList(userGroupsArray!!).map {
                            val listOfGroupNames = mutableListOf<String>()
                            it.forEach { listOfGroupNames.add(it.groupName) }
                            dashboardMemberModel.inGroups = listOfGroupNames
                            listOfMembersModel.add(dashboardMemberModel)
                            listOfMembersModel
                        }
                    }
            }.scheduleOnBackAndOutOnMain()
            .addToCompositeDisposable(compositeDisposable, {
                //membersLiveData.value = Resource.Success(it)
                Toast.makeText(
                    context,
                    "Dashboard member list is ${it.size}",
                    Toast.LENGTH_SHORT
                ).show()
            }, {
                //membersLiveData.value = Resource.Failure(it.message)
                Toast.makeText(context, "Failure is ${it.message}", Toast.LENGTH_SHORT)
                    .show()
            })
        return membersLiveData
    }
}
