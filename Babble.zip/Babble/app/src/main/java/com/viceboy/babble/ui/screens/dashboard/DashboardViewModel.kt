package com.viceboy.babble.ui.screens.dashboard

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.viceboy.babble.ui.base.BaseViewModel
import com.viceboy.babble.ui.base.SingleLiveEvent
import com.viceboy.babble.ui.state.ButtonState
import com.viceboy.babble.ui.state.Resource
import com.viceboy.babble.ui.util.addToCompositeDisposable
import com.viceboy.babble.ui.util.scheduleOnBackAndOutOnBack
import com.viceboy.babble.ui.util.scheduleOnBackAndOutOnMain
import com.viceboy.data_repo.converters.DashboardExpenseBeanConverter
import com.viceboy.data_repo.converters.DashboardGroupBeanConverter
import com.viceboy.data_repo.converters.DashboardMemberBeanConverter
import com.viceboy.data_repo.model.dataModel.Expense
import com.viceboy.data_repo.model.uiModel.DashboardExpense
import com.viceboy.data_repo.model.uiModel.DashboardGroup
import com.viceboy.data_repo.model.uiModel.DashboardMembers
import com.viceboy.data_repo.repository.ExpenseRepository
import com.viceboy.data_repo.repository.GroupsRepository
import com.viceboy.data_repo.repository.UserRepository
import com.viceboy.data_repo.util.DataConstants
import com.viceboy.data_repo.util.DataUtils
import io.reactivex.FlowableTransformer
import kotlinx.coroutines.Dispatchers
import javax.inject.Inject

class DashboardViewModel @Inject constructor(
    private val userRepository: UserRepository,
    private val expenseRepository: ExpenseRepository,
    private val groupsRepository: GroupsRepository
) : BaseViewModel<Int>() {

    @Inject
    lateinit var dashboardGroupBeanConverter: DashboardGroupBeanConverter

    @Inject
    lateinit var dashboardMemberBeanConverter: DashboardMemberBeanConverter

    @Inject
    lateinit var dashboardExpenseBeanConverter: DashboardExpenseBeanConverter

    private val ioContext = Dispatchers.IO + viewModelScope.coroutineContext
    private val emptyMessage = ""
    private var buttonClicked = false

    /**
     * Setting up mutable LiveData to handle latest expense by current user wrapped in LiveData
     */
    private val mutableLatestExpenseLiveData = MutableLiveData<Resource<DashboardExpense>>()
    val latestExpenseLiveData: LiveData<Resource<DashboardExpense>>
        get() = mutableLatestExpenseLiveData

    /**
     * Setting up mutable LiveData to handle group tab data list wrapped in Resource state
     */
    private val mutableGroupTabResourceLiveData =
        MutableLiveData<Resource<MutableSet<DashboardGroup>>>()
    val groupTabResourceLiveData: LiveData<Resource<MutableSet<DashboardGroup>>>
        get() = mutableGroupTabResourceLiveData

    /**
     * Setting up mutable LiveData to handle Members tab data list wrapped in Resource state
     */
    private val mutableMembersTabResourceLiveData =
        MutableLiveData<Resource<MutableSet<DashboardMembers>>>()
    val memberTabResourceLiveData: LiveData<Resource<MutableSet<DashboardMembers>>>
        get() = mutableMembersTabResourceLiveData

    /**
     * Setting up mutable LiveData to trigger tab(Groups/Members) click events
     */
    private val mutableOnGroupTabClickedLiveData = MutableLiveData(true)
    val onGroupTabClickedLiveDataLiveData: LiveData<Boolean>
        get() = mutableOnGroupTabClickedLiveData

    /**
     * Setting up mutable LiveData to manage navigation between fragments
     */
    private val navigateMutableLiveData = MutableLiveData<SingleLiveEvent<Int>>()
    val navigateLiveData: LiveData<SingleLiveEvent<Int>>
        get() = navigateMutableLiveData

    /**
     * Setting up mutable LiveData to manage Button State for fabShowOptions button
     */
    private val mutableMainFabButtonStateLiveData = MutableLiveData<ButtonState>()
    val mainFabButtonStateLiveData: LiveData<ButtonState>
        get() = mutableMainFabButtonStateLiveData


    /**
     * Setting up mutable LiveData to initiate fabShowOptions functionality
     */
    private val mutableAnimFabOptionsLiveData = MutableLiveData<SingleLiveEvent<Boolean>>()
    val animFabLiveData: LiveData<SingleLiveEvent<Boolean>>
        get() = mutableAnimFabOptionsLiveData


    /**
     * Called when fabShowOptions button is clicked and update button state
     */
    fun onFabShowOptionsClicked() {
        if (!buttonClicked) {
            mutableMainFabButtonStateLiveData.value = ButtonState.CLICKED
            mutableAnimFabOptionsLiveData.value = SingleLiveEvent(true)
            buttonClicked = true
        } else {
            mutableMainFabButtonStateLiveData.value = ButtonState.ACTIVE
            mutableAnimFabOptionsLiveData.value = SingleLiveEvent(true)
            buttonClicked = false
        }
    }

    /**
     * Reset fabShowOptions button state and reset button state and animation state
     */
    fun resetMainFabStateWithAnimation() {
        buttonClicked = false
        mutableMainFabButtonStateLiveData.value = ButtonState.ACTIVE
        mutableAnimFabOptionsLiveData.value = SingleLiveEvent(true)
    }

    /**
     * Navigate to mentioned destination Id
     */
    fun navigateTo(destinationId: Int) {
        setNavigationFlag(destinationId, navigateMutableLiveData)
    }

    /**
     * Trigger Group Tab selected event
     */
    fun onGroupTabSelected() {
        mutableOnGroupTabClickedLiveData.value = true
    }

    /**
     * Trigger Members Tab selected event
     */
    fun onMemberTabSelected() {
        mutableOnGroupTabClickedLiveData.value = false
    }

    /* Get list of Groups from Repository and returns a LiveData wrapped in Resource State */
    private fun loadDashboardGroupTabData() {
        val listOfDashboardGroup = mutableSetOf<DashboardGroup>()
        mutableGroupTabResourceLiveData.postValue(Resource.Loading())
        userRepository.loadGroups(userRepository.getCurrentUserId())
            .flatMap { groupsRepository.loadGroupList(it.toTypedArray()) }
            .flatMapIterable { it }
            .map {
                val dash = dashboardGroupBeanConverter.fromGroupToDashboardGroup(it)
                expenseRepository.loadExpenseByGroupId(dash.groupId)
                    .flatMap { listOfExpense ->
                        expenseRepository.loadLatestExpense(listOfExpense.toTypedArray())
                    }.flatMap { expense ->
                        dash.lastTransaction = expense.amountPaid
                        userRepository.loadUser(expense.expenseOwner)
                    }.map { user ->
                        val lastTransactionBy = if (user.id == userRepository.getCurrentUserId())
                            DataConstants.TEXT_LAST_EXPENSE_ADDED_SELF
                        else
                            DataConstants.TEXT_LAST_EXPENSE_ADDED + " " + user.name.substringBefore(
                                " "
                            )
                        dash.lastTransactionBy = lastTransactionBy
                        listOfDashboardGroup.add(dash)
                        listOfDashboardGroup.sortedBy { it.groupName }.toMutableSet()
                    }
            }.flatMap { it }
            .scheduleOnBackAndOutOnBack()
            .addToCompositeDisposable(compositeDisposable, {
                mutableGroupTabResourceLiveData.postValue(Resource.Success(it))
            }, {
                mutableGroupTabResourceLiveData.postValue(Resource.Failure(it.message))
            }, {
                //TODO: Complete this block to setup placeholder livedata
                mutableGroupTabResourceLiveData.postValue(Resource.Failure(emptyMessage))
            })
    }

    /** Get list of Members for current user active groups from Repository and returns a LiveData wrapped in Resource State */
    private fun loadDashboardMembersTabData() {
        val listOfMembersModel = mutableSetOf<DashboardMembers>()
        mutableMembersTabResourceLiveData.postValue(Resource.Loading())
        userRepository.loadGroups(userRepository.getCurrentUserId())
            .flatMapIterable { it }
            .compose(getGroupMembers())
            .compose(getDashboardMember())
            .map {
                listOfMembersModel.add(it)
                listOfMembersModel.sortedBy { it.name }.toMutableSet()
            }
            .scheduleOnBackAndOutOnBack()
            .addToCompositeDisposable(compositeDisposable, {
                mutableMembersTabResourceLiveData.postValue(Resource.Success(it))
            }, {
                mutableMembersTabResourceLiveData.postValue(Resource.Failure(it.message))
            },{
                //TODO: Complete this block to setup placeholder livedata
                mutableMembersTabResourceLiveData.postValue(Resource.Failure(emptyMessage))
            })
    }

    /** Get latest expense for current user and returns a LiveData wrapped in Resource State*/
    private fun loadLatestExpenseForCurrentUser() {
        mutableLatestExpenseLiveData.postValue(Resource.Loading())
        expenseRepository.loadExpenseByUserId(userRepository.getCurrentUserId())
            .compose(getLatestExpense())
            .compose(getDashboardExpenseFromExpense())
            .scheduleOnBackAndOutOnMain()
            .addToCompositeDisposable(compositeDisposable,
                {
                    mutableLatestExpenseLiveData.postValue(Resource.Success(it))
                },
                {
                    mutableLatestExpenseLiveData.postValue(Resource.Failure(it.message))
                }, {
                    //TODO: Complete this block to setup placeholder livedata
                    mutableLatestExpenseLiveData.postValue(Resource.Failure(emptyMessage))
                })
    }

    private fun getGroupMembers(): FlowableTransformer<String, List<String>> {
        return FlowableTransformer {
            it.flatMap {
                groupsRepository.loadGroupMembers(it)
            }
        }
    }

    private fun getDashboardMember(): FlowableTransformer<List<String>, DashboardMembers> {
        return FlowableTransformer {
            it.flatMap { listOfMemberId ->
                val newList = listOfMemberId.toMutableList()
                newList.remove(userRepository.getCurrentUserId())
                userRepository.loadUserList(newList.toTypedArray())
                    .flatMapIterable { it }
                    .compose(dashboardMemberBeanConverter.fromUserToFlowableDashboardMember())
            }
        }
    }

    private fun getLatestExpense(): FlowableTransformer<List<Expense>, Expense> =
        FlowableTransformer {
            it.flatMap { listOfExpense ->
                expenseRepository.loadLatestExpense(listOfExpense.toTypedArray())
            }
        }

    private fun getDashboardExpenseFromExpense() = FlowableTransformer<Expense, DashboardExpense> {
        it.flatMap { inObject ->
            val dateInString = DataUtils.getDateFromMilliSec(inObject.expenseDate)
            groupsRepository.loadGroupList(arrayOf(inObject.groupId))
                .map { listOfGroups ->
                    DashboardExpense(
                        inObject.id,
                        inObject.itemName,
                        dateInString,
                        inObject.expenseOwner,
                        inObject.currency,
                        listOfGroups.first().groupName,
                        inObject.amountPaid
                    )
                }
        }
    }

    init {
        loadDashboardGroupTabData()
        loadDashboardMembersTabData()
        loadLatestExpenseForCurrentUser()
    }
}

