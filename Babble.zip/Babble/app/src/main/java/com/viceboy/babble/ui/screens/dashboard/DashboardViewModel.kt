package com.viceboy.babble.ui.screens.dashboard

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.viceboy.babble.ui.base.BaseViewModel
import com.viceboy.babble.ui.base.SingleLiveEvent
import com.viceboy.babble.ui.state.ButtonState
import javax.inject.Inject

class DashboardViewModel @Inject constructor() : BaseViewModel<Int>() {

    private val navigateMutableLiveData = MutableLiveData<SingleLiveEvent<Int>>()
    val navigateLiveData: LiveData<SingleLiveEvent<Int>>
        get() = navigateMutableLiveData

    private var buttonClicked = false

    private val mutableMainFabButtonStateLiveData = MutableLiveData<ButtonState>()
    val mainFabButtonStateLiveData: LiveData<ButtonState>
        get() = mutableMainFabButtonStateLiveData

    private val mutableAnimFabOptionsLiveData = MutableLiveData<SingleLiveEvent<Boolean>>()
    val animFabLiveData: LiveData<SingleLiveEvent<Boolean>>
        get() = mutableAnimFabOptionsLiveData

    fun onMainFabClicked() {
        if (!buttonClicked) {
            mutableMainFabButtonStateLiveData.value = ButtonState.CLICKED
            mutableAnimFabOptionsLiveData.value = SingleLiveEvent(true)
            buttonClicked = true
        } else {
            mutableMainFabButtonStateLiveData.value = ButtonState.ACTIVE
            mutableAnimFabOptionsLiveData.value = SingleLiveEvent(true)
            buttonClicked = false
        }
    }

    fun resetMainFabStateWithAnimation() {
        buttonClicked = false
        mutableMainFabButtonStateLiveData.value = ButtonState.ACTIVE
        mutableAnimFabOptionsLiveData.value = SingleLiveEvent(true)
    }

    fun navigateTo(destinationId: Int) {
        setNavigationFlag(destinationId, navigateMutableLiveData)
    }

    fun resetMainFabState() {
        buttonClicked = false
        mutableMainFabButtonStateLiveData.value = ButtonState.ACTIVE
        mutableAnimFabOptionsLiveData.value = SingleLiveEvent(false)
    }
}