package com.viceboy.babble.ui.screens.captureExpense

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.hardware.display.DisplayManager
import android.os.Bundle
import android.util.DisplayMetrics
import android.util.Rational
import android.view.LayoutInflater
import android.view.TextureView
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.Toast
import androidx.camera.core.*
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.viceboy.babble.R
import com.viceboy.babble.ui.util.AnimationUtil
import com.viceboy.babble.ui.util.AutoFitPreviewBuilder
import com.viceboy.babble.ui.util.ImageUtil
import io.reactivex.Observable
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.schedulers.Schedulers
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

class CaptureExpenseFragment : Fragment() {

    private val compositeDisposable = CompositeDisposable()
    private val mapOfFlashMode = mapOf(0 to FlashMode.AUTO, 1 to FlashMode.ON, 2 to FlashMode.OFF)

    private lateinit var container: ConstraintLayout
    private lateinit var viewFinder: TextureView
    private lateinit var outputDir: File
    private lateinit var displayManager: DisplayManager

    private var displayId = -1
    private var currentFlashModeIndex = 0
    private var currentFlashMode = mapOfFlashMode[currentFlashModeIndex]
    private var currentCameraLens = CameraX.LensFacing.BACK

    private var containerUiVisibility: Int = 0
    private var preview: Preview? = null
    private var imageCapture: ImageCapture? = null
    private var imageAnalysis: ImageAnalysis? = null

    /**
     * Setting up a display listener for orientation changes that do not trigger a configuration
     * change, for example if we choose to override config change in manifests for 180 rotation
     */
    private val displayListener = object : DisplayManager.DisplayListener {
        override fun onDisplayChanged(displayId: Int) {
            view?.let {
                if (displayId == this@CaptureExpenseFragment.displayId) {
                    preview?.setTargetRotation(it.display.rotation)
                    imageCapture?.setTargetRotation(it.display.rotation)
                    imageAnalysis?.setTargetRotation(it.display.rotation)
                }
            }
        }

        override fun onDisplayAdded(displayId: Int) = Unit
        override fun onDisplayRemoved(displayId: Int) = Unit
    }

    private val imageSavedListener = object : ImageCapture.OnImageSavedListener {
        override fun onImageSaved(file: File) = sendImageFileToAddExpense(file)

        override fun onError(
            useCaseError: ImageCapture.UseCaseError,
            message: String,
            cause: Throwable?
        ) = Toast.makeText(
            requireContext(),
            "Failed to capture image $message",
            Toast.LENGTH_SHORT
        ).show()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!PermissionsFragment.hasPermissions(requireContext())) {
            findNavController().navigate(R.id.action_captureExpense_to_permissionsFragment)
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_capture_expense, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        container = view as ConstraintLayout
        viewFinder = container.findViewById(R.id.view_finder)

        displayManager =
            viewFinder.context.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
        displayManager.registerDisplayListener(displayListener, null)

        outputDir = getOutputDirectory(requireContext())

        //Lets wait for the views to be properly laid out
        viewFinder.post {
            //Keep track of the display in which view is attached
            displayId = viewFinder.display.displayId

            //Build UI Controls and bind all camera usecases
            updateCameraUI()
            bindCameraUseCases()
        }
    }

    override fun onResume() {
        super.onResume()
        containerUiVisibility = container.systemUiVisibility
        /* container.postDelayed(
             {
                 activity?.window?.apply {
                     getStatusColor = statusBarColor
                     clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS)
                     addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
                     decorView.systemUiVisibility =
                         View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                     statusBarColor = Color.TRANSPARENT
                 }
             }, 200
         )*/
        container.postDelayed(
            { container.systemUiVisibility = FLAGS_FULLSCREEN }, 500L
        )
        if (!PermissionsFragment.hasPermissions(requireContext())) {
            findNavController().navigate(R.id.action_captureExpense_to_permissionsFragment)
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        /* container.post {
             activity?.window?.apply {
                 //clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
                 //addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
                 decorView.systemUiVisibility = containerUiVisibility
                 statusBarColor = getStatusColor
             }
         }*/

        activity?.window?.decorView?.systemUiVisibility = containerUiVisibility
        displayManager.unregisterDisplayListener(displayListener)
    }

    override fun onDestroy() {
        super.onDestroy()
        compositeDisposable.clear()
    }

    @SuppressLint("RestrictedApi")
    private fun updateCameraUI() {
        //Remove previous UI, if any
        container.findViewById<ConstraintLayout>(R.id.camera_container)?.let {
            container.removeView(it)
        }

        //Inflating a new View to control camera buttons
        val cameraControls = View.inflate(requireContext(), R.layout.camera_ui_container, container)

        //Setup listener for Image Capture button
        cameraControls.findViewById<ImageButton>(R.id.ibShutter).setOnClickListener {
            imageCapture?.let {

                //Create output file to hold the image
                //TODO:Not required
                val photoFile = createFile(outputDir, FILENAME, ".jpg")

                //Flip image if using front camera
                val metaData = ImageCapture.Metadata().apply {
                    isReversedHorizontal = currentCameraLens == CameraX.LensFacing.FRONT
                }

                //Setup image capture listener triggered after image is captured
                it.takePicture(photoFile, imageSavedListener, metaData)

                //Show the white flash on capture image
                container.postDelayed({
                    container.foreground = ColorDrawable(Color.WHITE)
                    container.postDelayed({ container.foreground = null }, ANIMATION_FAST_MILLIS)
                }, ANIMATION_SLOW_MILLIS)
            }
        }

        //Setup Listener to switch camera lens
        cameraControls.findViewById<ImageButton>(R.id.ibSwitchCamera).setOnClickListener {
            it.post {
                AnimationUtil.rotateViewInCircularMotion(it)
            }
            currentCameraLens = if (currentCameraLens == CameraX.LensFacing.FRONT)
                CameraX.LensFacing.BACK
            else
                CameraX.LensFacing.FRONT

            //Now bind uses if front or back lens is available
            try {
                //Check if camera has lens facing
                CameraX.getCameraWithLensFacing(currentCameraLens)

                //Unbind all and bind with new configuration changes
                CameraX.unbindAll()
                bindCameraUseCases()
            } catch (e: Exception) {
                //Do nothing
            }
        }

        //TODO:Set up flash controller
        //Setup Listener to switch camera lens
        cameraControls.findViewById<ImageButton>(R.id.flFlashController).setOnClickListener {
            it.post {
                AnimationUtil.hideViewByScale(it)
            }

            currentFlashModeIndex = if (currentFlashModeIndex == 2) 0 else currentFlashModeIndex+1
            currentFlashMode = mapOfFlashMode[currentFlashModeIndex]

            //Now bind uses if front or back lens is available
            try {
                CameraX.unbindAll()
                bindCameraUseCases()
            } catch (e: Exception) {
            }
        }
    }

    // Declare bind, preview, capture and analyze use cases
    private fun bindCameraUseCases() {
        //Get Screen metrics used to setup camera for full screen resolution
        val metrics = DisplayMetrics().also { viewFinder.display.getRealMetrics(it) }
        val screenAspectRatio = Rational(metrics.widthPixels, metrics.heightPixels)

        val viewFinderConfig = PreviewConfig.Builder().apply {
            setLensFacing(currentCameraLens)
            //We request aspect ratio but no resolution to let camerax optimize our use cases
            setTargetAspectRatio(screenAspectRatio)
            //Set target rotation initially and we have to change the rotation for any changes in display
            setTargetRotation(viewFinder.display.rotation)
        }.build()

        val preview = AutoFitPreviewBuilder.build(viewFinderConfig, viewFinder)

        //Set up capture use case to allow users to take photos
        val imageCaptureConfig = ImageCaptureConfig.Builder().apply {
            setLensFacing(currentCameraLens)
            setFlashMode(currentFlashMode)
            setCaptureMode(ImageCapture.CaptureMode.MIN_LATENCY)
            setTargetAspectRatio(screenAspectRatio)
            setTargetRotation(viewFinder.display.rotation)
        }.build()

        imageCapture = ImageCapture(imageCaptureConfig)

        CameraX.bindToLifecycle(viewLifecycleOwner, preview, imageCapture)
    }

    //TODO: Complete the method body
    private fun sendImageFileToAddExpense(file: File) {
        compositeDisposable.add(Observable.create<File> { emitter ->
            emitter.onNext(ImageUtil.compressImage(requireContext(), file))
        }
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe({
                findNavController().navigate(
                    CaptureExpenseFragmentDirections.actionCaptureExpenseToAddExpenseFragment(
                        it
                    )
                )
            }, {
                Toast.makeText(
                    requireContext(),
                    "An error occurred while capturing expense : ${it.message}",
                    Toast.LENGTH_SHORT
                ).show()
            }))
    }

    companion object {

        @Suppress("SameParameterValue")
        fun createFile(baseFolder: File, fileName: String, fileExt: String): File {
            return File(
                baseFolder,
                FILENAME_STARTS_WITH + SimpleDateFormat(
                    fileName,
                    Locale.US
                ).format(System.currentTimeMillis()) + fileExt
            )
        }

        fun getOutputDirectory(context: Context): File {
            val appContext = context.applicationContext
            val mediaDir = context.externalMediaDirs.firstOrNull()?.let {
                File(it, appContext.resources.getString(R.string.app_name)).apply { mkdirs() }
            }
            return if (mediaDir != null && mediaDir.exists()) mediaDir else appContext.filesDir
        }

        private const val FILENAME_STARTS_WITH = "Receipt_"
        private const val FILENAME = "yyyy-MM-dd-HH-mm-ss-SSS"
        private const val ANIMATION_FAST_MILLIS = 50L
        private const val ANIMATION_SLOW_MILLIS = 100L
        private const val FLAGS_FULLSCREEN = View.SYSTEM_UI_FLAG_LOW_PROFILE or
                View.SYSTEM_UI_FLAG_FULLSCREEN
    }
}
