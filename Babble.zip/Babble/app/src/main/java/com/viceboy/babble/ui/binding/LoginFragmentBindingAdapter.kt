package com.viceboy.babble.ui.binding

import android.os.Handler
import android.view.View
import android.widget.ImageView
import androidx.databinding.BindingAdapter
import androidx.lifecycle.MutableLiveData
import com.google.android.material.textfield.TextInputEditText
import com.viceboy.babble.ui.util.animateButtonClick
import com.viceboy.babble.ui.util.animateLogo
import com.viceboy.babble.ui.util.toggleVisibility

@SuppressWarnings()
object LoginFragmentBindingAdapter {

    @JvmStatic
    @BindingAdapter("animateVisibility")
    fun setAnimatedVisibility(view: View, flag: Boolean) {
        if (flag)
            Handler().postDelayed({
                view.toggleVisibility()
            }, 300)
    }

    @JvmStatic
    @BindingAdapter(value = ["errorFlag", "animateButtonClick", "enableProgressBar"])
    fun setAnimationOnClick(
        view: View,
        errorFlag: Boolean?,
        showAnimation: MutableLiveData<Boolean>,
        enableProgress: MutableLiveData<Boolean>
    ) {
        if (errorFlag == false)
            if (showAnimation.value == true)
                view.animateButtonClick(enableProgress, showAnimation)
    }

    @JvmStatic
    @BindingAdapter("animateLogo")
    fun setAnimatedLogo(view: ImageView, flag: Boolean) {
        if (flag)
            view.animateLogo()
    }

    @JvmStatic
    @BindingAdapter(value = ["fieldValidation", "validationFlag", "isValidField"])
    fun setFieldValidation(
        view: TextInputEditText,
        validationType: String,
        checkFlag: MutableLiveData<Boolean>?,
        liveData: MutableLiveData<Boolean>
    ) {
        checkFlag?.let {
            if (it.value == true) {
                when (validationType) {
                    "email" -> {
                        if (view.text.toString() == "") {
                            view.error = "Email is a required field"
                        } else
                            liveData.value = true
                    }

                    "password" -> {
                        if (view.text.toString() == "") {
                            view.error = "Please enter your password to login"
                        } else
                            liveData.value = true
                    }
                }
            }
        }
    }

}
