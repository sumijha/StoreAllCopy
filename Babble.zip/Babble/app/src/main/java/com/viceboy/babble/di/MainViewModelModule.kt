package com.viceboy.babble.di

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.viceboy.babble.ui.base.ViewModelFactory
import com.viceboy.babble.ui.screens.dashboard.DashboardViewModel
import dagger.Binds
import dagger.Module
import dagger.multibindings.IntoMap

@Module
abstract class MainViewModelModule {

    @Binds
    @IntoMap
    @ViewModelKey(DashboardViewModel::class)
    abstract fun bindsDashboardViewModelModule(viewModel: DashboardViewModel): ViewModel

    @Binds
    abstract fun bindsViewModelFactory(viewModelFactory: ViewModelFactory): ViewModelProvider.Factory
}