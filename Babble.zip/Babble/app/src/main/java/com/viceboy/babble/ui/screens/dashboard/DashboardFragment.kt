package com.viceboy.babble.ui.screens.dashboard


import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.animation.AlphaAnimation
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.widget.Toolbar
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.coordinatorlayout.widget.CoordinatorLayout
import androidx.core.content.ContextCompat
import androidx.lifecycle.Observer
import com.google.android.material.appbar.AppBarLayout
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.viceboy.babble.R
import com.viceboy.babble.databinding.FragmentDashboardBinding
import com.viceboy.babble.di.Injectable
import com.viceboy.babble.ui.base.BaseFragment
import com.viceboy.babble.ui.base.EventObserver
import com.viceboy.babble.ui.custom.CustomAvatarSwipeBehavior
import com.viceboy.babble.ui.state.ButtonState
import kotlinx.android.synthetic.main.content_fab_menu.view.*
import kotlinx.android.synthetic.main.fragment_dashboard.*
import kotlinx.android.synthetic.main.fragment_dashboard.view.*
import kotlin.math.abs

class DashboardFragment : BaseFragment<DashboardViewModel, FragmentDashboardBinding>(), Injectable,
    AppBarLayout.OnOffsetChangedListener {

    private var bottomSheetCorner: Float = 0f
    private var fabButtonState: ButtonState? = null

    private lateinit var tvOverviewTab: TextView
    private lateinit var tvMembersTab: TextView
    private lateinit var btnToolbarDetails: Button
    private lateinit var toolbarMain: Toolbar
    private lateinit var tvUsernameHead: TextView
    private lateinit var bgFabOptions: ConstraintLayout
    private lateinit var bottomSheet: LinearLayout
    private lateinit var customAvatarSwipeBehavior: CustomAvatarSwipeBehavior
    private lateinit var bottomSheetBehavior: BottomSheetBehavior<LinearLayout>


    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        setUpBinding()

        if (bottomSheetCorner == 0f)
            bottomSheetCorner =
                resources.getDimensionPixelSize(R.dimen.bottomSheet_corner).toFloat()


        bgFabOptions = view.root_fab_options
        tvUsernameHead = view.tvToolbar_username
        tvOverviewTab = view.tvOverview
        tvMembersTab = view.tvMembers
        btnToolbarDetails = view.btnToolbar_viewDetails
        toolbarMain = view.toolbar_dashboard
        toolbarMain.inflateMenu(R.menu.dashboard_menu)
        toolbarMain.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                R.id.profile_menu -> {
                    Toast.makeText(context, "Profile clicked", Toast.LENGTH_SHORT).show()
                }
                else -> Toast.makeText(context, "Profile clicked", Toast.LENGTH_SHORT).show()
            }
            return@setOnMenuItemClickListener true
        }

        bottomSheet = view.findViewById(R.id.root_bottomsheet_transactions) as LinearLayout
        bottomSheetBehavior = BottomSheetBehavior.from(bottomSheet)

        initTabSelector()
        initBottomSheetCallback()
        initDashboardTouchListener(bgFabOptions)

        initAlphaAnimation(tvUsernameHead, 0, View.VISIBLE)

        val coordinatorParams = civProfilePhoto.layoutParams as CoordinatorLayout.LayoutParams
        coordinatorParams.behavior = customAvatarSwipeBehavior

        view.app_bar_dashboard.addOnOffsetChangedListener(this)
        super.onViewCreated(view, savedInstanceState)
    }

    override fun onOffsetChanged(appBarLayout: AppBarLayout, offset: Int) {
        val maxScroll = appBarLayout.totalScrollRange.toFloat()
        val percentage = abs(offset.toFloat() / maxScroll)

        handleToolbarMenuVisibility(percentage)
        handleTitleVisibility(percentage)
        handleButtonResize(percentage)
    }

    override fun layoutRes(): Int = R.layout.fragment_dashboard

    override fun observeLiveData(viewModel: DashboardViewModel, binding: FragmentDashboardBinding) {
        viewModel.mainFabButtonStateLiveData.observe(viewLifecycleOwner, Observer {
            binding.fabButtonState = it
            fabButtonState = it
            if (it == ButtonState.CLICKED)
                bgFabOptions.background =
                    ContextCompat.getDrawable(context!!, R.color.color_bg_progress)
            else
                bgFabOptions.background =
                    ContextCompat.getDrawable(context!!, android.R.color.transparent)

        })

        viewModel.animFabLiveData.observe(viewLifecycleOwner, EventObserver {
            binding.startAnimationFlag = it
        })
    }

    override fun onCreateView() {
        setHasOptionsMenu(true)
        customAvatarSwipeBehavior = CustomAvatarSwipeBehavior(context!!)
    }

    override fun onPause() {
        viewModel.resetMainFabStateWithAnimation()
        super.onPause()
    }



    override val viewModelClass: Class<DashboardViewModel> = DashboardViewModel::class.java

    private fun handleToolbarMenuVisibility(percentage: Float) {
        if (percentage > MIN_TOOLBAR_MENU_VISIBILITY) {
            toolbarMain.menu.setGroupVisible(R.id.toolbar_menu, true)
            toolbarMain.invalidate()
        } else {
            toolbarMain.menu.setGroupVisible(R.id.toolbar_menu, false)
            toolbarMain.invalidate()
        }
    }

    private fun handleButtonResize(percentage: Float) {
        btnToolbarDetails.scaleY = 1f - percentage
        btnToolbarDetails.scaleX = 1f - percentage
    }

    private fun handleTitleVisibility(percentage: Float) {
        if (percentage > MIN_AVATAR_PERCENTAGE_SIZE) {
            initAlphaAnimation(tvUsernameHead, ALPHA_ANIMATION_DURATION, View.VISIBLE)
        } else {
            initAlphaAnimation(tvUsernameHead, ALPHA_ANIMATION_DURATION, View.INVISIBLE)
        }
    }

    private fun initAlphaAnimation(view: View, animDuration: Long, visibility: Int) {
        if (visibility == View.INVISIBLE) {
            val alphaAnimation = AlphaAnimation(0f, 1f).apply {
                duration = animDuration
                fillAfter = true
            }
            view.startAnimation(alphaAnimation)
        } else {
            val alphaAnimation = AlphaAnimation(1f, 0f).apply {
                duration = animDuration
                fillAfter = true
            }
            view.startAnimation(alphaAnimation)
        }
    }

    //TODO: Test this junk code and arrange accordingly
    private fun handleCornerRadiusOnScroll(offset: Float) {
        val cornerRad = bottomSheetCorner - bottomSheetCorner * offset
        val drawable = bottomSheet.background as GradientDrawable
        drawable.cornerRadius = cornerRad
        bottomSheet.background = drawable
    }

    //TODO: Test this junk code and arrange accordingly
    private fun initBottomSheetCallback() {
        bottomSheetBehavior.setBottomSheetCallback(object :
            BottomSheetBehavior.BottomSheetCallback() {
            override fun onSlide(p0: View, p1: Float) {
                handleCornerRadiusOnScroll(p1)
            }

            override fun onStateChanged(p0: View, p1: Int) {
            }
        })
    }

    private fun initTabSelector() {
        tvOverviewTab.isSelected = true
        tvOverviewTab.setOnClickListener {
            if (!it.isSelected) {
                it.isSelected = true
                tvMembersTab.isSelected = false
            }
        }

        tvMembersTab.setOnClickListener {
            if (!it.isSelected) {
                it.isSelected = true
                tvOverviewTab.isSelected = false
            }
        }
    }

    private fun setUpBinding() {
        binding.apply {
            dashViewModel = viewModel
            lifecycleOwner = viewLifecycleOwner
        }
    }

    private fun initDashboardTouchListener(view: View) {
        view.setOnTouchListener { v, event ->
            if (event.action == MotionEvent.ACTION_DOWN && fabButtonState == ButtonState.CLICKED) {
                viewModel.resetMainFabStateWithAnimation()
                true
            } else
                false
        }
    }


    companion object {
        private const val MIN_AVATAR_PERCENTAGE_SIZE = 0.8f
        private const val MIN_TOOLBAR_MENU_VISIBILITY = 0.9f
        private const val ALPHA_ANIMATION_DURATION: Long = 500
    }
}

