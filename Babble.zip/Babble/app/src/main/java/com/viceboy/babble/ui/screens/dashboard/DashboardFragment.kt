package com.viceboy.babble.ui.screens.dashboard

import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.MotionEvent
import android.view.View
import android.view.animation.AlphaAnimation
import android.widget.Toast
import androidx.appcompat.widget.Toolbar
import androidx.coordinatorlayout.widget.CoordinatorLayout
import androidx.core.content.ContextCompat
import androidx.lifecycle.Observer
import androidx.navigation.fragment.findNavController
import com.google.android.material.appbar.AppBarLayout
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.viceboy.babble.R
import com.viceboy.babble.databinding.FragmentDashboardBinding
import com.viceboy.babble.di.Injectable
import com.viceboy.babble.ui.base.BaseFragment
import com.viceboy.babble.ui.base.EventObserver
import com.viceboy.babble.ui.custom.behavior.CustomAvatarSwipeBehavior
import com.viceboy.babble.ui.state.ButtonState
import kotlin.math.abs

class DashboardFragment : BaseFragment<DashboardViewModel, FragmentDashboardBinding>(), Injectable {

    private lateinit var customAvatarSwipeBehavior: CustomAvatarSwipeBehavior

    private var bottomSheetCorner: Float = 0f
    private var fabButtonState: ButtonState? = null

    private val toolbarMenuItemListener = Toolbar.OnMenuItemClickListener { item ->
        when (item.itemId) {
            R.id.profile_menu -> {
                Toast.makeText(context, "Profile clicked", Toast.LENGTH_SHORT).show()
            }
            else -> Toast.makeText(context, "Profile clicked", Toast.LENGTH_SHORT).show()
        }
        true
    }

    private val appBarOffsetChangeListener =
        AppBarLayout.OnOffsetChangedListener { appBarLayout: AppBarLayout, offset: Int ->
            val maxScroll = appBarLayout.totalScrollRange.toFloat()
            val percentage = abs(offset.toFloat() / maxScroll)

            handleToolbarMenuVisibility(percentage)
            handleTitleVisibility(percentage)
            handleButtonResize(percentage)
        }

    private val dashboardTouchListener =  View.OnTouchListener { _, event ->
        if (event.action == MotionEvent.ACTION_DOWN && fabButtonState == ButtonState.CLICKED) {
            viewModel.resetMainFabStateWithAnimation()
            true
        } else {
            false
        }
    }

    private val dashboardBottomSheetCallback = object :
        BottomSheetBehavior.BottomSheetCallback() {
        override fun onSlide(p0: View, p1: Float) {
            handleCornerRadiusOnScroll(p1)
        }

        override fun onStateChanged(p0: View, p1: Int) {
        }
    }

    override val viewModelClass: Class<DashboardViewModel> = DashboardViewModel::class.java

    override fun layoutRes(): Int = R.layout.fragment_dashboard

    override fun onCreateView() {
        initCustomAvatarSwipeBehavior()
        setHasOptionsMenu(true)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        setUpBinding()

        initBottomSheetCorner()
        initTabSelector()
        initAlphaAnimation(binding.tvToolbarUsername, 0, View.VISIBLE)

        attachAvatarSwipeBehavior()

        super.onViewCreated(view, savedInstanceState)
    }

    override fun onPause() {
        if (isFabMenuExpanded())
            viewModel.resetMainFabStateWithAnimation()
        super.onPause()
    }

    override fun observeLiveData(viewModel: DashboardViewModel, binding: FragmentDashboardBinding) {
        viewModel.mainFabButtonStateLiveData.observe(viewLifecycleOwner, Observer {
            binding.fabButtonState = it
            fabButtonState = it
            if (isFabMenuExpanded())
                binding.dashFabMenu.rootFabOptions.background =
                    ContextCompat.getDrawable(requireContext(), R.color.color_bg_progress)
            else
                binding.dashFabMenu.rootFabOptions.background =
                    ContextCompat.getDrawable(requireContext(), android.R.color.transparent)

        })

        viewModel.animFabLiveData.observe(viewLifecycleOwner, EventObserver {
            binding.startAnimationFlag = it
        })

        viewModel.navigateLiveData.observe(viewLifecycleOwner, EventObserver {
            findNavController().navigate(it)
        })
    }

    private fun setUpBinding() {
        binding.apply {
            dashViewModel = viewModel
            lifecycleOwner = viewLifecycleOwner
            menuItemListener = toolbarMenuItemListener
            onAppBarOffSetChangeListener = appBarOffsetChangeListener
            bottomSheetTransactions.sheetCallback = dashboardBottomSheetCallback
            dashFabMenu.dashViewModel = viewModel
            dashFabMenu.fabMenuTouchListener = dashboardTouchListener
            dashFabMenu.addExpenseNavDirections =
                DashboardFragmentDirections.actionDashboardFragmentToAddExpense()
            dashFabMenu.addGroupNavDirections =
                DashboardFragmentDirections.actionDashboardFragmentToAddGroupFragment()
        }
    }

    private fun handleToolbarMenuVisibility(percentage: Float) {
        if (percentage > MIN_TOOLBAR_MENU_VISIBILITY) {
            binding.toolbarDashboard.menu.setGroupVisible(R.id.toolbar_menu, true)
            binding.toolbarDashboard.invalidate()
        } else {
            binding.toolbarDashboard.menu.setGroupVisible(R.id.toolbar_menu, false)
            binding.toolbarDashboard.invalidate()
        }
    }

    private fun handleButtonResize(percentage: Float) {
        binding.btnToolbarViewDetails.scaleY = 1f - percentage
        binding.btnToolbarViewDetails.scaleX = 1f - percentage
    }

    private fun handleTitleVisibility(percentage: Float) {
        if (percentage > MIN_AVATAR_PERCENTAGE_SIZE) {
            initAlphaAnimation(binding.tvToolbarUsername, ALPHA_ANIMATION_DURATION, View.VISIBLE)
        } else {
            initAlphaAnimation(binding.tvToolbarUsername, ALPHA_ANIMATION_DURATION, View.INVISIBLE)
        }
    }

    private fun initAlphaAnimation(view: View, animDuration: Long, visibility: Int) {
        if (visibility == View.INVISIBLE) {
            val alphaAnimation = AlphaAnimation(0f, 1f).apply {
                duration = animDuration
                fillAfter = true
            }
            view.startAnimation(alphaAnimation)
        } else {
            val alphaAnimation = AlphaAnimation(1f, 0f).apply {
                duration = animDuration
                fillAfter = true
            }
            view.startAnimation(alphaAnimation)
        }
    }

    private fun initCustomAvatarSwipeBehavior() {
        customAvatarSwipeBehavior = CustomAvatarSwipeBehavior(requireContext())
    }

    private fun initBottomSheetCorner() {
        if (bottomSheetCorner == 0f)
            bottomSheetCorner =
                resources.getDimensionPixelSize(R.dimen.bottomSheet_corner).toFloat()
    }

    //TODO: Test this junk code and arrange accordingly
    private fun handleCornerRadiusOnScroll(offset: Float) {
        val bottomSheet = binding.bottomSheetTransactions.rootBottomsheetTransactions
        val cornerRad = bottomSheetCorner - bottomSheetCorner * offset
        val drawable = bottomSheet.background as GradientDrawable
        drawable.cornerRadius = cornerRad
        bottomSheet.background = drawable
    }

    //TODO: Functionality needs to be updated
    private fun initTabSelector() {
        binding.tvOverview.isSelected = true
        binding.tvOverview.setOnClickListener {
            if (!it.isSelected) {
                it.isSelected = true
                binding.tvMembers.isSelected = false
            }
        }

        binding.tvMembers.setOnClickListener {
            if (!it.isSelected) {
                it.isSelected = true
                binding.tvOverview.isSelected = false
            }
        }
    }

    private fun attachAvatarSwipeBehavior() {
        val coordinatorParams =
            binding.civProfilePhoto.layoutParams as CoordinatorLayout.LayoutParams
        coordinatorParams.behavior = customAvatarSwipeBehavior
    }

    private fun isFabMenuExpanded() = fabButtonState == ButtonState.CLICKED

    companion object {
        private const val MIN_AVATAR_PERCENTAGE_SIZE = 0.8f
        private const val MIN_TOOLBAR_MENU_VISIBILITY = 0.9f
        private const val ALPHA_ANIMATION_DURATION: Long = 500
    }
}

