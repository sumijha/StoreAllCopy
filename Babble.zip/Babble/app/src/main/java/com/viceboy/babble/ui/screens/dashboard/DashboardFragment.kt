package com.viceboy.babble.ui.screens.dashboard

import android.graphics.Color
import android.os.Bundle
import android.view.MotionEvent
import android.view.View
import android.widget.Toast
import androidx.appcompat.widget.Toolbar
import androidx.coordinatorlayout.widget.CoordinatorLayout
import androidx.core.content.ContextCompat
import androidx.core.widget.NestedScrollView
import androidx.lifecycle.Observer
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.DividerItemDecoration.VERTICAL
import com.github.mikephil.charting.components.XAxis
import com.github.mikephil.charting.components.XAxis.XAxisPosition
import com.github.mikephil.charting.data.BarData
import com.github.mikephil.charting.data.BarDataSet
import com.github.mikephil.charting.data.BarEntry
import com.google.android.material.appbar.AppBarLayout
import com.viceboy.babble.R
import com.viceboy.babble.databinding.FragmentDashboardBinding
import com.viceboy.babble.di.Injectable
import com.viceboy.babble.ui.base.BaseHomeFragment
import com.viceboy.babble.ui.base.EventObserver
import com.viceboy.babble.ui.custom.behavior.CustomAvatarSwipeBehavior
import com.viceboy.babble.ui.custom.widgets.CustomDashboardLinearLayoutManager
import com.viceboy.babble.ui.state.ButtonState
import com.viceboy.babble.ui.state.Resource
import com.viceboy.babble.ui.util.scrollToTop
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlin.math.abs

class DashboardFragment : BaseHomeFragment<DashboardViewModel, FragmentDashboardBinding>(),
    Injectable {

    private lateinit var customAvatarSwipeBehavior: CustomAvatarSwipeBehavior

    private val recyclerContext = lifecycleScope.coroutineContext + Dispatchers.Main

    private var groupTabItemHeight: Int = 0
    private var groupTabViewRefreshJob: Job? = null
    private var memberTabViewRefreshJob: Job? = null
    private var memberTabListAdapter: DashboardMemberTabListAdapter? = null
    private var groupTabListAdapter: DashboardGroupTabListAdapter? = null
    private var fabButtonState: ButtonState? = null

    private val toolbarMenuItemListener = Toolbar.OnMenuItemClickListener { item ->
        when (item.itemId) {
            R.id.profile_menu -> Toast.makeText(
                context,
                "Profile clicked",
                Toast.LENGTH_SHORT
            ).show()
            else -> Toast.makeText(context, "Profile clicked", Toast.LENGTH_SHORT).show()
        }
        true
    }

    private val appBarOffsetChangeListener =
        AppBarLayout.OnOffsetChangedListener { appBarLayout: AppBarLayout, offset: Int ->
            val maxScroll = appBarLayout.totalScrollRange.toFloat()
            val percentage = abs(offset.toFloat() / maxScroll)

            handleBottomNavigationView(percentage)
            handleToolbarMenuVisibility(percentage)
            handleTitleVisibility(percentage)
        }

    private val dashboardTouchListener = View.OnTouchListener { _, event ->
        if (event.action == MotionEvent.ACTION_DOWN && fabButtonState == ButtonState.CLICKED) {
            viewModel.resetMainFabStateWithAnimation()
            true
        } else {
            false
        }
    }

    override val hasBottomNavigationView: Boolean = true
    override val viewModelClass: Class<DashboardViewModel> = DashboardViewModel::class.java

    override fun layoutRes(): Int = R.layout.fragment_dashboard

    override fun onCreateView() {
        initGroupTabAdapter()
        initMemberTabAdapter()
        initCustomAvatarSwipeBehavior()
        setHasOptionsMenu(true)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        setUpBinding()
        setUpRecyclerView()
        setUpDashboardBarChart()
        setUpScrollUpFabClickListener()
        setUpNestedScrollItemListener()
        attachAvatarSwipeBehavior()

        super.onViewCreated(view, savedInstanceState)
    }

    override fun onPause() {
        resetFabMenu()
        super.onPause()
    }

    override fun observeLiveData(viewModel: DashboardViewModel, binding: FragmentDashboardBinding) {
        viewModel.mainFabButtonStateLiveData.observe(viewLifecycleOwner, Observer {
            binding.fabButtonState = it
            fabButtonState = it
            if (isFabMenuExpanded())
                binding.dashFabMenu.rootFabOptions.background =
                    ContextCompat.getDrawable(requireContext(), R.color.color_bg_progress)
            else
                binding.dashFabMenu.rootFabOptions.background =
                    ContextCompat.getDrawable(requireContext(), android.R.color.transparent)

        })

        viewModel.animFabLiveData.observe(viewLifecycleOwner, EventObserver {
            binding.startAnimationFlag = (it && binding.dashFabMenu.rootFabOptions.alpha == 1f)
        })

        viewModel.navigateLiveData.observe(viewLifecycleOwner, EventObserver {
            findNavController().navigate(it)
        })

        viewModel.latestExpenseLiveData.observe(viewLifecycleOwner, Observer {
            when (it) {
                is Resource.Success -> it.data?.let { dashboardExpense ->
                    binding.userLatestExpense = dashboardExpense
                }
                is Resource.Failure -> if (it.message.isNullOrEmpty())
                    Toast.makeText(requireContext(),"No expense added yet",Toast.LENGTH_LONG).show()
            }
        })

        viewModel.groupTabResourceLiveData.observe(viewLifecycleOwner, Observer {
            when (it) {
                is Resource.Loading -> binding.isDataLoading = true

                is Resource.Success -> {
                    binding.isDataLoading = false
                    groupTabListAdapter?.submitList(it.data?.toMutableList())
                }

                is Resource.Failure -> binding.isDataLoading = false
            }
        })

        viewModel.onGroupTabClickedLiveDataLiveData.observe(viewLifecycleOwner, Observer {
            if (it) setUpGroupsTabAdapter() else {
                setUpMembersTabAdapter()
                startObservingMembersTabLiveData()
            }
        })
    }

    private fun initGroupTabAdapter() {
        groupTabListAdapter = DashboardGroupTabListAdapter()
    }

    private fun initMemberTabAdapter() {
        memberTabListAdapter = DashboardMemberTabListAdapter {
            //TODO: Complete callback body
        }
    }

    private fun startObservingMembersTabLiveData() {
        if (viewModel.memberTabResourceLiveData.hasObservers())
            viewModel.memberTabResourceLiveData.removeObservers(viewLifecycleOwner)
        viewModel.memberTabResourceLiveData.observe(viewLifecycleOwner, Observer {
            when (it) {
                is Resource.Loading -> binding.isDataLoading = true
                is Resource.Success -> {
                    binding.isDataLoading = false
                    memberTabListAdapter?.submitList(it.data?.toMutableList())
                }
                is Resource.Failure -> binding.isDataLoading = false
            }
        })
    }

    private fun setUpScrollUpFabClickListener() {
        binding.fabScrollUp.setOnClickListener {
            if (it.visibility == View.VISIBLE) {
                binding.nsvRecyclerItemContainer.scrollToTop()
            }
        }
    }

    private fun setUpNestedScrollItemListener() {
        binding.nsvRecyclerItemContainer.setOnScrollChangeListener { _: NestedScrollView?, _: Int, scrollY: Int, _: Int, _: Int ->
            binding.scrollToTopFabVisibility = scrollY > groupTabItemHeight && scrollY > 0
        }
    }

    private fun setUpBinding() {
        binding.apply {
            dashViewModel = viewModel
            lifecycleOwner = viewLifecycleOwner
            menuItemListener = toolbarMenuItemListener
            onAppBarOffSetChangeListener = appBarOffsetChangeListener
            dashFabMenu.dashViewModel = viewModel
            dashFabMenu.fabMenuTouchListener = dashboardTouchListener
            dashFabMenu.addExpenseNavDirections =
                DashboardFragmentDirections.actionDashboardFragmentToAddExpense()
            dashFabMenu.addGroupNavDirections =
                DashboardFragmentDirections.actionDashboardFragmentToAddGroupFragment()
        }
    }

    private fun setUpRecyclerView() {
        binding.rvGroupList.addItemDecoration(DividerItemDecoration(requireContext(), VERTICAL))
        binding.rvGroupList.layoutManager = CustomDashboardLinearLayoutManager(requireContext()) {
            groupTabItemHeight = this
        }
    }

    private fun setUpGroupsTabAdapter() {
        if (memberTabViewRefreshJob?.isActive == true) memberTabViewRefreshJob?.cancel()

        groupTabViewRefreshJob = viewLifecycleOwner.lifecycleScope.launch(recyclerContext) {
            binding.rvGroupList.recycledViewPool.clear()
            binding.rvGroupList.adapter?.notifyDataSetChanged()
            binding.rvGroupList.adapter = groupTabListAdapter
        }
    }

    private fun setUpMembersTabAdapter() {
        if (groupTabViewRefreshJob?.isActive == true) groupTabViewRefreshJob?.cancel()

        memberTabViewRefreshJob = viewLifecycleOwner.lifecycleScope.launch(recyclerContext) {
            binding.rvGroupList.recycledViewPool.clear()
            binding.rvGroupList.adapter?.notifyDataSetChanged()
            binding.rvGroupList.adapter = memberTabListAdapter
        }
    }

    private fun resetFabMenu() {
        if (isFabMenuExpanded()) viewModel.resetMainFabStateWithAnimation()
    }

    private fun handleBottomNavigationView(percentage: Float) {
        bottomNavigationView.translationY = bottomNavigationView.height.toFloat() * percentage
        binding.dashFabMenu.rootFabOptions.translationY =
            bottomNavigationView.height.toFloat() * percentage
    }

    private fun handleToolbarMenuVisibility(percentage: Float) {
        if (percentage > MIN_TOOLBAR_MENU_VISIBILITY) {
            binding.toolbarDashboard.menu.setGroupVisible(R.id.toolbar_menu, true)
            binding.toolbarDashboard.invalidate()
        } else {
            binding.toolbarDashboard.menu.setGroupVisible(R.id.toolbar_menu, false)
            binding.toolbarDashboard.invalidate()
        }
    }

    private fun handleTitleVisibility(percentage: Float) {
        binding.tvToolbarUsername.alpha = percentage
        binding.dashFabMenu.rootFabOptions.alpha = 1 - percentage
    }

    private fun initCustomAvatarSwipeBehavior() {
        customAvatarSwipeBehavior = CustomAvatarSwipeBehavior(requireContext())
    }

    private fun attachAvatarSwipeBehavior() {
        val circleImageViewParams =
            binding.civProfilePhoto.layoutParams as CoordinatorLayout.LayoutParams
        circleImageViewParams.behavior = customAvatarSwipeBehavior
    }

    private fun isFabMenuExpanded() = fabButtonState == ButtonState.CLICKED

    private fun setUpDashboardBarChart() {
        lifecycleScope.launch {
            val entryList = mutableListOf(
                BarEntry(125f, 0),
                BarEntry(250f, 1),
                BarEntry(300f, 2),
                BarEntry(125f, 3),
                BarEntry(250f, 4),
                BarEntry(300f, 5),
                BarEntry(125f, 6),
                BarEntry(250f, 7),
                BarEntry(300f, 8),
                BarEntry(125f, 9),
                BarEntry(250f, 10),
                BarEntry(300f, 11)
            )

            val groupName = mutableListOf(
                "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
            )
            val dataSet = BarDataSet(entryList, "Expense for current year")

            binding.barChart.apply {

                setNoDataTextDescription("")
                setMaxVisibleValueCount(60)
                setDrawBarShadow(false)
                setDrawGridBackground(false);
                setPinchZoom(false)
                setScaleEnabled(false)

                val xAxis: XAxis = this.xAxis
                xAxis.position = XAxisPosition.BOTTOM
                xAxis.setDrawGridLines(false)

                setDescription(null)

                axisLeft.setDrawGridLines(false)

                animateY(1500)
            }
            val data = BarData(groupName, dataSet)
            dataSet.setColors(LIBERTY_COLORS)
            binding.barChart.data = data
        }
    }

    companion object {
        private const val MIN_TOOLBAR_MENU_VISIBILITY = 0.9f
        private val LIBERTY_COLORS = intArrayOf(
            Color.rgb(207, 248, 100),
            Color.rgb(148, 212, 100),
            Color.rgb(136, 180, 100),
            Color.rgb(118, 174, 100),
            Color.rgb(42, 109, 100)
        )
    }

    /*private fun setUpDashboardPieChart() {
        val entryList = mutableListOf(
            Entry(125f, 0),
            Entry(250f, 1),
            Entry(300f, 3)
        )

        val dataSet = PieDataSet(entryList, "Amount paid in each group")
        val groupName = mutableListOf(
            "Weekend Expense",
            "Trip to Goa",
            "Saturday-Sunday Dinner"
        )
        val data = PieData(groupName, dataSet)
        binding.pieChart.apply {
            setData(data)
            setUsePercentValues(false)
            setExtraOffsets(5f, 10f, 5f, 10f)
            setHoleColor(Color.WHITE)
            setTransparentCircleAlpha(110)
            holeRadius = 58f
            transparentCircleRadius = 61f;
            setDrawCenterText(true)
            isDrawHoleEnabled = true
            dragDecelerationFrictionCoef = 0.9f
        }
        //dataSet.setColors(ColorTemplate.COLORFUL_COLORS)
        pieChart.animateXY(1000, 1000)
    }*/


}

