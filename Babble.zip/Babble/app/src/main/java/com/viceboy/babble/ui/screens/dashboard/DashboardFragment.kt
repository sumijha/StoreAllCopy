package com.viceboy.babble.ui.screens.dashboard

import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.MotionEvent
import android.view.View
import android.widget.Toast
import androidx.appcompat.widget.Toolbar
import androidx.coordinatorlayout.widget.CoordinatorLayout
import androidx.core.content.ContextCompat
import androidx.core.widget.NestedScrollView
import androidx.lifecycle.Observer
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.DividerItemDecoration.VERTICAL
import com.github.mikephil.charting.charts.Chart
import com.github.mikephil.charting.components.XAxis
import com.github.mikephil.charting.components.XAxis.XAxisPosition
import com.github.mikephil.charting.data.BarData
import com.github.mikephil.charting.data.BarDataSet
import com.github.mikephil.charting.data.BarEntry
import com.google.android.material.appbar.AppBarLayout
import com.viceboy.babble.R
import com.viceboy.babble.databinding.FragmentDashboardBinding
import com.viceboy.babble.di.Injectable
import com.viceboy.babble.ui.base.BaseHomeFragment
import com.viceboy.babble.ui.base.EventObserver
import com.viceboy.babble.ui.custom.behavior.CustomAvatarSwipeBehavior
import com.viceboy.babble.ui.custom.widgets.CustomDashboardLinearLayoutManager
import com.viceboy.babble.ui.state.ButtonState
import com.viceboy.babble.ui.state.Resource
import com.viceboy.babble.ui.util.scrollToTop
import com.viceboy.data_repo.model.dataModel.Expense
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import java.util.*
import kotlin.math.abs

class DashboardFragment : BaseHomeFragment<DashboardViewModel, FragmentDashboardBinding>(),
    Injectable {

    private lateinit var customAvatarSwipeBehavior: CustomAvatarSwipeBehavior

    private val recyclerContext = lifecycleScope.coroutineContext + Dispatchers.Main

    private var groupTabItemHeight: Int = 0
    private var groupTabViewRefreshJob: Job? = null
    private var memberTabViewRefreshJob: Job? = null
    private var memberTabListAdapter: DashboardMemberTabListAdapter? = null
    private var groupTabListAdapter: DashboardGroupTabListAdapter? = null
    private var fabButtonState: ButtonState? = null

    private val toolbarMenuItemListener = Toolbar.OnMenuItemClickListener { item ->
        when (item.itemId) {
            R.id.profile_menu -> Toast.makeText(
                context,
                "Profile clicked",
                Toast.LENGTH_SHORT
            ).show()
            else -> Toast.makeText(context, "Profile clicked", Toast.LENGTH_SHORT).show()
        }
        true
    }

    private val appBarOffsetChangeListener =
        AppBarLayout.OnOffsetChangedListener { appBarLayout: AppBarLayout, offset: Int ->
            val maxScroll = appBarLayout.totalScrollRange.toFloat()
            val percentage = abs(offset.toFloat() / maxScroll)

            handleBottomNavigationView(percentage)
            handleToolbarMenuVisibility(percentage)
            handleTitleVisibility(percentage)
        }

    private val dashboardTouchListener = View.OnTouchListener { _, event ->
        if (event.action == MotionEvent.ACTION_DOWN && fabButtonState == ButtonState.CLICKED) {
            viewModel.resetMainFabStateWithAnimation()
            true
        } else {
            false
        }
    }

    override val hasBottomNavigationView: Boolean = true
    override val viewModelClass: Class<DashboardViewModel> = DashboardViewModel::class.java

    override fun layoutRes(): Int = R.layout.fragment_dashboard

    override fun onCreateView() {
        initGroupTabAdapter()
        initMemberTabAdapter()
        initCustomAvatarSwipeBehavior()
        setHasOptionsMenu(true)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        setUpBinding()
        setUpRecyclerView()
        setUpDashboardBarChart()
        setUpScrollUpFabClickListener()
        setUpNestedScrollItemListener()
        attachAvatarSwipeBehavior()

        super.onViewCreated(view, savedInstanceState)
    }

    override fun onPause() {
        resetFabMenu()
        super.onPause()
    }

    override fun observeLiveData(viewModel: DashboardViewModel, binding: FragmentDashboardBinding) {
        viewModel.mainFabButtonStateLiveData.observe(viewLifecycleOwner, Observer {
            binding.fabButtonState = it
            fabButtonState = it
            if (isFabMenuExpanded())
                binding.dashFabMenu.rootFabOptions.background =
                    ContextCompat.getDrawable(requireContext(), R.color.color_bg_progress)
            else
                binding.dashFabMenu.rootFabOptions.background =
                    ContextCompat.getDrawable(requireContext(), android.R.color.transparent)

        })

        viewModel.animFabLiveData.observe(viewLifecycleOwner, EventObserver {
            binding.startAnimationFlag = (it && binding.dashFabMenu.rootFabOptions.alpha == 1f)
        })

        viewModel.navigateLiveData.observe(viewLifecycleOwner, EventObserver {
            findNavController().navigate(it)
        })

        viewModel.latestExpenseLiveData.observe(viewLifecycleOwner, Observer {
            when (it) {
                is Resource.Success -> it.data?.let { dashboardExpense ->
                    binding.userLatestExpense = dashboardExpense
                }
                is Resource.Failure -> if (it.message.isNullOrEmpty())
                    Toast.makeText(requireContext(), "No expense added yet", Toast.LENGTH_LONG)
                        .show()
            }
        })

        observeDashboardBarChartData()
        observeCurrencySelectorLiveData()

        viewModel.groupTabResourceLiveData.observe(viewLifecycleOwner, Observer {
            when (it) {
                is Resource.Loading -> binding.isDataLoading = true

                is Resource.Success -> {
                    binding.isDataLoading = false
                    groupTabListAdapter?.submitList(it.data?.toMutableList())
                }

                is Resource.Failure -> binding.isDataLoading = false
            }
        })

        viewModel.onGroupTabClickedLiveDataLiveData.observe(viewLifecycleOwner, Observer {
            if (it) setUpGroupsTabAdapter() else {
                setUpMembersTabAdapter()
                startObservingMembersTabLiveData()
            }
        })
    }

    private fun initGroupTabAdapter() {
        groupTabListAdapter = DashboardGroupTabListAdapter()
    }

    private fun initMemberTabAdapter() {
        memberTabListAdapter = DashboardMemberTabListAdapter {
            //TODO: Complete callback body
        }
    }

    private fun startObservingMembersTabLiveData() {
        if (viewModel.memberTabResourceLiveData.hasObservers())
            viewModel.memberTabResourceLiveData.removeObservers(viewLifecycleOwner)
        viewModel.memberTabResourceLiveData.observe(viewLifecycleOwner, Observer {
            when (it) {
                is Resource.Loading -> binding.isDataLoading = true
                is Resource.Failure -> binding.isDataLoading = false
                is Resource.Success -> {
                    binding.isDataLoading = false
                    memberTabListAdapter?.submitList(it.data?.toMutableList())
                }
            }
        })
    }

    private fun setUpScrollUpFabClickListener() {
        binding.fabScrollUp.setOnClickListener {
            if (it.visibility == View.VISIBLE) {
                binding.nsvRecyclerItemContainer.scrollToTop()
            }
        }
    }

    private fun setUpNestedScrollItemListener() {
        binding.nsvRecyclerItemContainer.setOnScrollChangeListener { _: NestedScrollView?, _: Int, scrollY: Int, _: Int, _: Int ->
            binding.scrollToTopFabVisibility = scrollY > groupTabItemHeight && scrollY > 0
        }
    }

    private fun setUpBinding() {
        binding.apply {
            dashViewModel = viewModel
            lifecycleOwner = viewLifecycleOwner
            menuItemListener = toolbarMenuItemListener
            onAppBarOffSetChangeListener = appBarOffsetChangeListener
            dashFabMenu.dashViewModel = viewModel
            dashFabMenu.fabMenuTouchListener = dashboardTouchListener
            dashFabMenu.addExpenseNavDirections =
                DashboardFragmentDirections.actionDashboardFragmentToAddExpense()
            dashFabMenu.addGroupNavDirections =
                DashboardFragmentDirections.actionDashboardFragmentToAddGroupFragment()
        }
    }

    private fun setUpRecyclerView() {
        binding.rvGroupList.addItemDecoration(DividerItemDecoration(requireContext(), VERTICAL))
        binding.rvGroupList.layoutManager = CustomDashboardLinearLayoutManager(requireContext()) {
            groupTabItemHeight = this
        }
    }

    private fun setUpGroupsTabAdapter() {
        if (memberTabViewRefreshJob?.isActive == true) memberTabViewRefreshJob?.cancel()

        groupTabViewRefreshJob = viewLifecycleOwner.lifecycleScope.launch(recyclerContext) {
            binding.rvGroupList.recycledViewPool.clear()
            binding.rvGroupList.adapter?.notifyDataSetChanged()
            binding.rvGroupList.adapter = groupTabListAdapter
        }
    }

    private fun setUpMembersTabAdapter() {
        if (groupTabViewRefreshJob?.isActive == true) groupTabViewRefreshJob?.cancel()

        memberTabViewRefreshJob = viewLifecycleOwner.lifecycleScope.launch(recyclerContext) {
            binding.rvGroupList.recycledViewPool.clear()
            binding.rvGroupList.adapter?.notifyDataSetChanged()
            binding.rvGroupList.adapter = memberTabListAdapter
        }
    }

    private fun resetFabMenu() {
        if (isFabMenuExpanded()) viewModel.resetMainFabStateWithAnimation()
    }

    /**
     * Start observing currencySelectorLiveData
     */
    private fun observeCurrencySelectorLiveData() {
        viewModel.currencySelectorLiveData.observe(viewLifecycleOwner, Observer {
            when (it) {
                is Resource.Success -> {
                    binding.isExpenseFoundInCurrentYr = true
                    binding.tvBarCurrency.text = it.data
                }
                is Resource.Failure -> {
                    binding.isExpenseFoundInCurrentYr = false
                }
            }
        })
    }

    /**
     * Start observing userExpenseListForCurrentYrLiveData
     */
    private fun observeDashboardBarChartData() {
        viewModel.userExpenseListForCurrentYrLiveData.observe(viewLifecycleOwner, Observer {
            when (it) {
                is Resource.Success -> handleUserExpenseListForCurrentYr(it.data)
                is Resource.Failure -> {
                    if (it.message?.isNotEmpty() == true) Toast.makeText(
                        requireContext(),
                        it.message,
                        Toast.LENGTH_LONG
                    ).show()
                }
            }
        })
    }

    /**
     * Convert expense data list to data set required by BarChart
     */
    private fun handleUserExpenseListForCurrentYr(data: List<Expense>?) {
        data?.let {
            val dataMap = convertExpenseListToMonthlyExpenseMap(it)
            addBarDataSet(dataMap)
        }
    }


    private fun handleBottomNavigationView(percentage: Float) {
        bottomNavigationView.translationY = bottomNavigationView.height.toFloat() * percentage
        binding.dashFabMenu.rootFabOptions.translationY =
            bottomNavigationView.height.toFloat() * percentage
    }

    private fun handleToolbarMenuVisibility(percentage: Float) {
        if (percentage > MIN_TOOLBAR_MENU_VISIBILITY) {
            binding.toolbarDashboard.menu.setGroupVisible(R.id.toolbar_menu, true)
            binding.toolbarDashboard.invalidate()
        } else {
            binding.toolbarDashboard.menu.setGroupVisible(R.id.toolbar_menu, false)
            binding.toolbarDashboard.invalidate()
        }
    }

    private fun handleTitleVisibility(percentage: Float) {
        binding.tvToolbarUsername.alpha = percentage
        binding.dashFabMenu.rootFabOptions.alpha = 1 - percentage
    }

    private fun initCustomAvatarSwipeBehavior() {
        customAvatarSwipeBehavior = CustomAvatarSwipeBehavior(requireContext())
    }

    private fun attachAvatarSwipeBehavior() {
        val circleImageViewParams =
            binding.civProfilePhoto.layoutParams as CoordinatorLayout.LayoutParams
        circleImageViewParams.behavior = customAvatarSwipeBehavior
    }

    private fun isFabMenuExpanded() = fabButtonState == ButtonState.CLICKED

    private fun setUpDashboardBarChart() {
        binding.barChart.apply {

            setNoDataText("No Expenses found in Current Year")
            val paint = getPaint(Chart.PAINT_INFO)
            paint.typeface = Typeface.DEFAULT_BOLD
            paint.color = requireContext().getColor(R.color.colorPrimary)

            setMaxVisibleValueCount(60)
            setDrawBarShadow(false)
            setDrawGridBackground(false);
            setPinchZoom(false)
            setScaleEnabled(false)
            setDescription(null)

            val xAxis: XAxis = this.xAxis
            xAxis.position = XAxisPosition.BOTTOM
            xAxis.setDrawGridLines(false)

            axisLeft.setDrawGridLines(false)

            animateXY(1000, 1500)
        }
    }

    /**
     * Convert expense list to map of expense with key as month and value as expense amount
     */
    private fun convertExpenseListToMonthlyExpenseMap(listOfExpense: List<Expense>): MutableMap<Int, Float> {
        val mapOfExpenseByMonth = mutableMapOf<Int, Float>()
        listOfExpense.forEach { expense ->
            val month = Calendar.getInstance().run {
                timeInMillis = expense.expenseDate
                this.get(Calendar.MONTH)
            }
            if (mapOfExpenseByMonth.containsKey(month)) {
                val newAmount = mapOfExpenseByMonth[month]?.plus(expense.amountPaid)
                mapOfExpenseByMonth[month] = newAmount ?: expense.amountPaid
            } else {
                mapOfExpenseByMonth[month] = expense.amountPaid
            }
        }
        return mapOfExpenseByMonth
    }


    /**
     * Add monthly expense data map to BarDataSet and notifies the BarChart
     */
    private fun addBarDataSet(listOfMonthlyExpenseMap: MutableMap<Int, Float>) {
        val listOfBarEntry = mutableListOf<BarEntry>()
        repeat(12) {
            listOfBarEntry.add(BarEntry(listOfMonthlyExpenseMap[it] ?: 0f, it))
        }
        val barDataSet = BarDataSet(listOfBarEntry, TXT_GRAPH_DESC)
        val barData = BarData(listOfMonthsInShortFormat, barDataSet)

        barDataSet.setColors(LIBERTY_COLORS)
        binding.barChart.apply {
            data = barData
            notifyDataSetChanged()
            invalidate()
        }
    }


    companion object {
        private const val MIN_TOOLBAR_MENU_VISIBILITY = 0.9f
        private const val TXT_GRAPH_DESC = "Total Expenses in Current Yr."

        private val listOfMonthsInShortFormat = mutableListOf(
            "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
        )
        private val LIBERTY_COLORS = intArrayOf(
            Color.rgb(207, 248, 100),
            Color.rgb(148, 212, 100),
            Color.rgb(136, 180, 100),
            Color.rgb(118, 174, 100),
            Color.rgb(42, 109, 100)
        )
    }

    /*private fun setUpDashboardPieChart() {
        val entryList = mutableListOf(
            Entry(125f, 0),
            Entry(250f, 1),
            Entry(300f, 3)
        )

        val dataSet = PieDataSet(entryList, "Amount paid in each group")
        val groupName = mutableListOf(
            "Weekend Expense",
            "Trip to Goa",
            "Saturday-Sunday Dinner"
        )
        val data = PieData(groupName, dataSet)
        binding.pieChart.apply {
            setData(data)
            setUsePercentValues(false)
            setExtraOffsets(5f, 10f, 5f, 10f)
            setHoleColor(Color.WHITE)
            setTransparentCircleAlpha(110)
            holeRadius = 58f
            transparentCircleRadius = 61f;
            setDrawCenterText(true)
            isDrawHoleEnabled = true
            dragDecelerationFrictionCoef = 0.9f
        }
        //dataSet.setColors(ColorTemplate.COLORFUL_COLORS)
        pieChart.animateXY(1000, 1000)
    }*/
}

