package com.viceboy.babble.auth

import android.content.Context
import com.viceboy.babble.ui.base.AuthProvider
import com.viceboy.babble.ui.model.User
import com.viceboy.babble.ui.util.scheduleOnBackAndOutOnMain
import io.reactivex.Completable
import javax.inject.Inject

class MockAuthProvider @Inject constructor(
    private val context: Context
) : AuthProvider {

    private val method = "get_users"
    private val endPoint = "auth/get_users"

    private lateinit var authenticatedUser: User

    override fun authenticateUser(
        username: String,
        password: String
    ): Completable {
        return Completable.defer {
            Completable.create { emitter ->
                val users = MockResourceLoader.getResponseFrom(
                    context,
                    method,
                    endPoint.split("/").toTypedArray()
                )
                users?.let { listOfUsers ->
                    for (user in listOfUsers) {
                        if ((user.email == username || user.phone.toString() == username) && user.password == password) {
                            authenticatedUser = user
                            emitter.onComplete()
                            return@create
                        }
                    }
                    emitter.onError(RuntimeException("User has not registered yet"))
                }
            }.scheduleOnBackAndOutOnMain()
        }
    }
}