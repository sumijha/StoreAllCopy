package com.viceboy.babble.auth

import android.os.SystemClock.sleep
import com.viceboy.babble.ui.base.SignUpAuthProvider
import com.viceboy.babble.ui.model.User
import com.viceboy.babble.ui.util.scheduleOnBackAndOutOnMain
import io.reactivex.Completable
import javax.inject.Inject

class MockSignUpProvider @Inject constructor(): SignUpAuthProvider {
    override fun createNewUser(user: User) : Completable {
        return Completable.defer {
            Completable.create {emitter ->
                if (registerUser(user.email,user.password))
                    emitter.onComplete()
                else
                    emitter.onError(RuntimeException("Failed to create new user, kindly check if you are connected to internet"))
            }
        }.scheduleOnBackAndOutOnMain()
    }

    private fun registerUser(user: String?,password:String?):Boolean {
        sleep(1000)
        return true
    }
}