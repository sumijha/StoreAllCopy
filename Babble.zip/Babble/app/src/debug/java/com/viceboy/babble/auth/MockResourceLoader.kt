package com.viceboy.babble.auth

import android.content.Context
import com.google.gson.Gson
import com.google.gson.GsonBuilder
import com.google.gson.reflect.TypeToken
import com.viceboy.babble.ui.model.User
import timber.log.Timber
import java.io.BufferedReader
import java.io.IOException
import java.io.InputStreamReader

class MockResourceLoader private constructor() {

    companion object {
        private val gson = GsonBuilder().create()

        @JvmStatic
        fun getResponseFrom(
            context: Context,
            method: String,
            endPoints: Array<String>
        ): List<User>? {
            try {
                var currentPath = "mock"
                var mockLists = context.assets.list(currentPath)

                for (endpoint in endPoints) {
                    if (mockLists!!.contains(endpoint)) {
                        currentPath = "$currentPath/$endpoint"
                        mockLists = context.assets.list(currentPath)
                    }
                }

                var finalPath: String? = null
                for (path in mockLists!!) {
                    if (path.contains(method)) {
                        finalPath = "$currentPath/$path"
                        break
                    }
                }
                if (!finalPath.isNullOrEmpty()) {
                    val descriptor  = context.assets.open(finalPath)
                    val reader = BufferedReader(InputStreamReader(descriptor))
                    val sb=  reader.use {
                        it.readText()
                    }
                    val type = object : TypeToken<List<User>>() {}.type
                    return gson.fromJson<List<User>>(sb, type)
                }
                return null
            } catch (e: IOException) {
                Timber.e("Error loading mock response from assets")
                return null
            }
        }
    }
}