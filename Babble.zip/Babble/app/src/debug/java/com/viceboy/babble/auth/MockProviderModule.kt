package com.viceboy.babble.auth

import com.viceboy.babble.ui.base.AuthProvider
import com.viceboy.babble.ui.base.PhoneAuthProvider
import dagger.Binds
import dagger.Module

@Module
abstract class  AuthProviderModule {

    @Binds
    abstract fun bindsAuthProviderModule(authProvider: MockAuthProvider): AuthProvider

    @Binds
    abstract fun bindsPhoneAuthProviderModule(phoneAuthProvider: MockPhoneAuthProvider):PhoneAuthProvider
}