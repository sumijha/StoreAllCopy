package com.viceboy.babble.auth

import android.content.Context
import com.viceboy.babble.ui.base.PhoneAuthProvider
import com.viceboy.babble.ui.util.scheduleOnBackAndOutOnMain
import io.reactivex.Completable
import io.reactivex.Observable
import javax.inject.Inject

class MockPhoneAuthProvider @Inject constructor(private val context: Context) : PhoneAuthProvider {

    private val method = "get_users"
    private val endPoint = "auth/get_users"

    override fun requestVerificationOtp(phoneNumber: String): Observable<String> {
        return Observable.create<String> { emitter ->
            val users = MockResourceLoader.getResponseFrom(
                context,
                method,
                endPoint.split("/").toTypedArray()
            )
            users?.let { listOfUsers ->
                for (user in listOfUsers) {
                    if (user.phone.toString().contains(phoneNumber)) {
                        emitter.onNext(otp)
                        return@create
                    }
                }
                emitter.onError(RuntimeException("Invalid Mobile Number Entered"))
            }
        }.scheduleOnBackAndOutOnMain()
    }

    override fun verifyOtp(receivedOtp: String, enteredOtp: String): Completable {
        return Completable.defer {
            Completable.create {emitter ->
                if (receivedOtp == enteredOtp)
                    emitter.onComplete()
                else
                    emitter.onError(RuntimeException("Failed to verify Otp, kindly check the otp entered"))
            }
        }
    }

    companion object {
        private const val otp = "123456"
    }
}

