package com.viceboy.babble.data_provider.mockRepository

import android.content.Context
import com.google.gson.internal.LinkedTreeMap
import com.viceboy.babble.data_provider.mockDataLoader.MockResourceLoader
import com.viceboy.data_repo.model.Groups
import com.viceboy.data_repo.repository.GroupsRepository
import io.reactivex.BackpressureStrategy
import io.reactivex.Completable
import io.reactivex.Flowable
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers
import timber.log.Timber
import javax.inject.Inject
import javax.inject.Singleton

@Suppress("UNCHECKED_CAST")
@Singleton
class MockGroupRepository @Inject constructor(val context: Context) : GroupsRepository {

    private val mutableCachedMapOfGroups = HashMap<String, Groups>()
    private var mapOfGroupId: LinkedTreeMap<String, Any>? = null

    override fun loadGroupList(groupId: Array<String>): Flowable<List<Groups>> {
        return Flowable.create({ emitter ->
            mapOfGroupId?.let {
                MockResourceLoader.getModelData<Groups>(
                        groupId,
                        it
                    ).subscribeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe({ listOfGroups ->
                        emitter.onNext(listOfGroups)
                    }, {
                        emitter.onError(it)
                    })

            }
        }, BackpressureStrategy.LATEST)
    }

    override fun loadGroupMembers(groupId: String): Flowable<List<String>> {
        return Flowable.create({ emitter ->
            mapOfGroupId?.let {
                MockResourceLoader.getModelData(
                    groupId,
                    mutableCachedMapOfGroups,
                    it
                ).subscribe { group ->
                    val memberList = group.groupMembers.keys.toMutableList()
                    group.groupAdmin.keys.forEach { memberList.add(it) }
                    memberList.let { emitter.onNext(it) }
                }

            }
        }, BackpressureStrategy.LATEST)
    }

    override fun loadGroupExpenses(groupId: String): Flowable<List<String>> {
        return Flowable.create({ emitter ->
            mapOfGroupId?.let {
                MockResourceLoader.getModelData(
                    groupId,
                    mutableCachedMapOfGroups,
                    it
                ).subscribe { group ->
                    val memberExpenses = ArrayList<String>()
                    group.groupMembers.entries.forEach { entrySet ->
                        val mapOfExpenses = entrySet.value as LinkedTreeMap<String, Any>
                        val expenses = mapOfExpenses["expenses"] as ArrayList<String>
                        memberExpenses.addAll(expenses)
                    }
                    group.groupAdmin.entries.forEach { entrySet ->
                        val mapOfExpenses = entrySet.value as LinkedTreeMap<String, Any>
                        val expenses = mapOfExpenses["expenses"] as ArrayList<String>
                        memberExpenses.addAll(expenses)
                    }
                    emitter.onNext(memberExpenses)
                }

            }
        }, BackpressureStrategy.LATEST)
    }

    override fun loadUserExpenseMap(groupId: String): Flowable<MutableMap<String, Float>> {
        return Flowable.create({ emitter ->
            mapOfGroupId?.let {
                MockResourceLoader.getModelData(groupId, mutableCachedMapOfGroups, it)
                    .subscribe { group ->
                        val mapOfExpense = mutableMapOf<String, Float>()
                        group.groupMembers.entries.forEach { entrySet ->
                            val mapOfExpenses = entrySet.value as LinkedTreeMap<String, Any>
                            val expenseAmount = mapOfExpenses["amount"] as Float
                            mapOfExpense[entrySet.key] = expenseAmount
                        }
                        group.groupAdmin.entries.forEach { entrySet ->
                            val mapOfExpenses = entrySet.value as LinkedTreeMap<String, Any>
                            val expenseAmount = mapOfExpenses["amount"] as Float
                            mapOfExpense[entrySet.key] = expenseAmount
                        }
                        emitter.onNext(mapOfExpense)
                    }
            }
        }, BackpressureStrategy.LATEST)
    }

    override fun saveGroup(groups: Groups): Completable {
        return Completable.create {}
    }

    override fun remove(groups: Groups): Completable {
        return Completable.create {}
    }

    private fun mapOfGroups(): LinkedTreeMap<String, Any> {
        val mapOfGroups = MockResourceLoader.getDummyResponseFrom(
            context,
            method,
            endPoint.split("/").toTypedArray()
        )
        return mapOfGroups?.get(NODE_GROUPS) as LinkedTreeMap<String, Any>
    }

    init {
        mapOfGroupId = mapOfGroups()
    }

    companion object {
        private const val NODE_GROUPS = "groups"

        private const val method = "users_groups"
        private const val endPoint = "data/users_groups"
    }
}