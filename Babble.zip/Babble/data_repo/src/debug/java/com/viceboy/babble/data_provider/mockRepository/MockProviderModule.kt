package com.viceboy.babble.data_provider.mockRepository

import com.viceboy.babble.data_provider.mockRepository.MockExpenseRepository
import com.viceboy.babble.data_provider.mockRepository.MockGroupRepository
import com.viceboy.babble.data_provider.mockRepository.MockUserRepository
import com.viceboy.data_repo.repository.ExpenseRepository
import com.viceboy.data_repo.repository.GroupsRepository
import com.viceboy.data_repo.repository.UserRepository
import dagger.Binds
import dagger.Module

@Module
abstract class RepositoryProviderModule {

    @Binds
    abstract fun bindsMockUserRepo(userRepository: MockUserRepository): UserRepository

    @Binds
    abstract fun bindsMockGroupRepo(groupRepository: MockGroupRepository): GroupsRepository

    @Binds
    abstract fun bindsMockExpenseRepo(expenseRepository: MockExpenseRepository): ExpenseRepository
}