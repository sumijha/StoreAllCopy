package com.viceboy.babble.data_provider.mockDataLoader

import com.google.gson.*
import com.google.gson.reflect.TypeToken
import java.io.Serializable
import java.lang.reflect.Type

class CustomInterfaceAdapter<T : Serializable> : JsonSerializer<T>, JsonDeserializer<T> {

    private val CLASSNAME = "CLASSNAME"
    private val DATA = "DATA"

    override fun serialize(
        src: T,
        typeOfSrc: Type?,
        context: JsonSerializationContext?
    ): JsonElement {
        val jsonObject = JsonObject()
        jsonObject.addProperty(CLASSNAME, src.javaClass.name)
        jsonObject.add(DATA, context?.serialize(src))
        return jsonObject
    }

    override fun deserialize(
        json: JsonElement,
        typeOfT: Type,
        context: JsonDeserializationContext
    ): T {
        val jsonObject = json.asJsonObject
        val prim = jsonObject.get(CLASSNAME) as JsonPrimitive
        val className = prim.asString
        val kClass = getObjectClass(className)
        return context.deserialize(jsonObject[DATA], kClass)
    }

    private fun getObjectClass(className: String): Class<*> {
        return try {
            Class.forName(className)
        } catch (ce: ClassNotFoundException) {
            throw JsonParseException(ce.message)
        }
    }

}