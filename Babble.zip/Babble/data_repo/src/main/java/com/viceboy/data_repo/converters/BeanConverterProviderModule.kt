package com.viceboy.data_repo.converters

import dagger.Binds
import dagger.Module


@Module
abstract class BeanConverterProviderModule {

    @Binds
    abstract fun bindsDashboardGroupBeanConverter(dashboardGroupBeanConverterImpl: DashboardGroupBeanConverterImpl): DashboardGroupBeanConverter

    @Binds
    abstract fun bindsDashboardMemberBeanConverter(dashboardMemberBeanConverterImpl: DashboardMemberBeanConverterImpl): DashboardMemberBeanConverter

    @Binds
    abstract fun bindsDashboardExpenseBeanConverter(dashboardExpenseBeanConverterImpl: DashboardExpenseBeanConverterImpl): DashboardExpenseBeanConverter
}
