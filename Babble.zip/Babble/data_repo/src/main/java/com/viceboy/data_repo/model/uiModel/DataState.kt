package com.viceboy.data_repo.model.uiModel

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
class ProgressModel : Parcelable, TransactionLoadState, ExpenseLoadState , MemberLoadState

@Parcelize
class EmptyDataModel : Parcelable, TransactionLoadState, ExpenseLoadState , MemberLoadState

interface TransactionLoadState : Parcelable

interface ExpenseLoadState : Parcelable

interface MemberLoadState : Parcelable