package com.viceboy.data_repo.model

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize
import java.io.Serializable


@Parcelize
data class Expense(
    val id : String,
    val itemName: String,
    val expenseImageUrl: String?,
    val expenseDate: Long,
    val amountPaid: Float,
    val currency: String,
    val groupId: String,
    val expenseOwner: String,
    val expenseSharedBy: HashMap<String, Float>
) : Parcelable, Serializable