package com.viceboy.data_repo.converters

import com.google.gson.internal.LinkedTreeMap
import com.viceboy.data_repo.model.uiModel.DashboardGroup
import com.viceboy.data_repo.model.dataModel.Groups
import com.viceboy.data_repo.repository.UserRepository
import com.viceboy.data_repo.util.DataConstants
import javax.inject.Inject

interface DashboardGroupBeanConverter {
    fun fromGroupToDashboardGroup(groups: Groups): DashboardGroup
}

class DashboardGroupBeanConverterImpl @Inject constructor() :
    BaseDataConverterImpl<Groups, DashboardGroup>(), DashboardGroupBeanConverter {

    @Inject
    lateinit var userRepository: UserRepository

    override fun processConversionFromInToOut(inObject: Groups): DashboardGroup {
        val mapOfExpense = (inObject.groupAdmin as LinkedTreeMap<*, *>).entries.firstOrNull {
            it.key == userRepository.getCurrentUserId()
        }
            ?: (inObject.groupMembers as LinkedTreeMap<*, *>).entries.firstOrNull { it.key == userRepository.getCurrentUserId() }
        val amount =
            (mapOfExpense?.value as LinkedTreeMap<*, *>)[DataConstants.KEY_AMOUNT]?.toString()
                ?.toFloat() ?: 0f
        val owedText =
            if (amount < 0) DataConstants.TEXT_YOU_OWE else DataConstants.TEXT_YOU_ARE_OWED
        return DashboardGroup(
            inObject.id,
            inObject.groupName,
            inObject.currency,
            owedText,
            amount,
            null,
            null
        )
    }

    override fun processConversionFromOutToIn(inObject: DashboardGroup): Groups {
        val empty = ""
        val emptyMap = LinkedTreeMap<String, LinkedTreeMap<String, Any>>()
        return Groups(
            inObject.groupId,
            inObject.groupName,
            empty,
            empty,
            emptyMap,
            emptyMap
        )
    }

    override fun fromGroupToDashboardGroup(groups: Groups) = processConversionFromInToOut(groups)

}
