package com.viceboy.data_repo.repository

import com.viceboy.data_repo.model.Groups
import io.reactivex.Completable
import io.reactivex.Flowable

interface GroupsRepository {
    fun loadGroupList(groupId: Array<String>) : Flowable<List<Groups>>
    fun loadGroupMembers(groupId: String): Flowable<List<String>>
    fun loadGroupExpenses(groupId: String): Flowable<List<String>>
    fun saveGroup(groups: Groups): Completable
    fun remove(groups: Groups): Completable
}