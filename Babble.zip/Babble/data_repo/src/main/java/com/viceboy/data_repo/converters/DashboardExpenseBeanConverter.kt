package com.viceboy.data_repo.converters

import com.viceboy.data_repo.model.dataModel.Expense
import com.viceboy.data_repo.model.uiModel.DashboardExpense
import com.viceboy.data_repo.repository.GroupsRepository
import com.viceboy.data_repo.util.DataUtils
import io.reactivex.FlowableTransformer
import javax.inject.Inject

interface DashboardExpenseBeanConverter {
    fun getDashboardExpenseFromExpense(): FlowableTransformer<Expense, DashboardExpense>
}

class DashboardExpenseBeanConverterImpl @Inject constructor() :
    BaseDataConverterImpl<Expense, DashboardExpense>(),
    DashboardExpenseBeanConverter {

    @Inject
    lateinit var groupsRepository: GroupsRepository

    override fun processConversionFromInToOut(inObject: Expense): DashboardExpense {
        TODO("Not yet implemented")
    }

    override fun processConversionFromOutToIn(inObject: DashboardExpense): Expense {
        TODO("Not yet implemented")
    }

    override fun getDashboardExpenseFromExpense() = FlowableTransformer<Expense, DashboardExpense> {
        it.flatMap { inObject ->
            val dateInString = DataUtils.getDateFromMilliSec(inObject.expenseDate)
            groupsRepository.loadGroupList(arrayOf(inObject.groupId))
                .map { listOfGroups ->
                    DashboardExpense(
                        inObject.id,
                        inObject.itemName,
                        dateInString,
                        inObject.expenseOwner,
                        inObject.currency,
                        listOfGroups.first().groupName,
                        inObject.amountPaid
                    )
                }
        }
    }

}