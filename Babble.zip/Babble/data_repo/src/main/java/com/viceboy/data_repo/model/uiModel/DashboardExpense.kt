package com.viceboy.data_repo.model.uiModel

data class DashboardExpense(
    val id: String,
    val itemName: String,
    val expenseDate: String,
    var expenseOwner: String?,
    val inCurrency: String,
    var inGroup: String?,
    var itemAmount: Float
)