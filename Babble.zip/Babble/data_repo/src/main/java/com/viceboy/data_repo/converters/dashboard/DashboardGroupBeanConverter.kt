package com.viceboy.data_repo.converters.dashboard

import com.google.gson.internal.LinkedTreeMap
import com.viceboy.data_repo.converters.BaseDataConverterImpl
import com.viceboy.data_repo.model.dataModel.Groups
import com.viceboy.data_repo.model.uiModel.DashboardGroup
import com.viceboy.data_repo.repository.GroupsRepository
import com.viceboy.data_repo.repository.UserRepository
import com.viceboy.data_repo.util.DataConstants
import io.reactivex.BackpressureStrategy
import io.reactivex.Flowable
import io.reactivex.FlowableTransformer
import javax.inject.Inject

interface DashboardGroupBeanConverter {
    fun fromGroupToDashboardGroup(groups: Groups): DashboardGroup
    fun mapGroupToDashboardGroup() : FlowableTransformer<Groups, DashboardGroup>
}

class DashboardGroupBeanConverterImpl @Inject constructor() :
    BaseDataConverterImpl<Groups, DashboardGroup>(),
    DashboardGroupBeanConverter {

    @Inject
    lateinit var userRepository: UserRepository

    @Inject
    lateinit var groupRepository: GroupsRepository

    override fun processConversionFromInToOut(inObject: Groups): DashboardGroup {
        val mapOfExpense = (inObject.groupAdmin as LinkedTreeMap<*, *>).entries.firstOrNull {
            it.key == userRepository.getCurrentUserId()
        }
            ?: (inObject.groupMembers as LinkedTreeMap<*, *>).entries.firstOrNull { it.key == userRepository.getCurrentUserId() }
        val amount =
            (mapOfExpense?.value as LinkedTreeMap<*, *>)[DataConstants.KEY_AMOUNT]?.toString()
                ?.toFloat() ?: 0f
        val owedText =
            if (amount < 0) DataConstants.TEXT_YOU_OWE else DataConstants.TEXT_YOU_ARE_OWED


        return DashboardGroup(
            inObject.id,
            inObject.groupName,
            inObject.currency,
            owedText,
            null,
            amount,
            null,
            null
        )
    }

    override fun fromGroupToDashboardGroup(groups: Groups) = processConversionFromInToOut(groups)

    override fun processConversionFromInToFlowableOut(inObject: Groups): Flowable<DashboardGroup> {
        val dashGroup = processConversionFromInToOut(inObject)
        return groupRepository.loadUserExpenseMap(inObject.id)
            .map {
                dashGroup.mapOfUserAndAmount = it
                dashGroup
            }
    }

    override fun mapGroupToDashboardGroup(): FlowableTransformer<Groups,DashboardGroup> = convertInToOutFlowableTransformer()

}
