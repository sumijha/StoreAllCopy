package com.viceboy.data_repo.model

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize
import java.io.Serializable

@Parcelize
data class User(
    val id: String,
    val email: String,
    val countryCode: String,
    val country: String,
    val name: String,
    var phone: String,
    val avatar_url: String?,
    val groups: List<String>?
) : Parcelable, Serializable, ForExpenseShared

data class TotalExpenseShared(val id: String="") : ForExpenseShared

interface ForExpenseShared