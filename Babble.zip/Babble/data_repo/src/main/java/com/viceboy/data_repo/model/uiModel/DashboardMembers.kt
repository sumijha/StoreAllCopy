package com.viceboy.data_repo.model.uiModel

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
data class DashboardMembers(
    val id : String,
    val name : String,
    var avatarImage : String?,
    var inGroups : List<String>?
) : Parcelable