package com.viceboy.data_repo.converters

import com.viceboy.data_repo.model.dataModel.User
import com.viceboy.data_repo.model.uiModel.DashboardMembers
import com.viceboy.data_repo.repository.GroupsRepository
import com.viceboy.data_repo.repository.UserRepository
import io.reactivex.FlowableTransformer
import javax.inject.Inject

interface DashboardMemberBeanConverter {
    fun fromUserToFlowableDashboardMember(): FlowableTransformer<User, DashboardMembers>
}

class DashboardMemberBeanConverterImpl @Inject constructor() :
    BaseDataConverterImpl<User, DashboardMembers>(), DashboardMemberBeanConverter {

    @Inject
    lateinit var groupsRepository: GroupsRepository

    @Inject
    lateinit var userRepository: UserRepository

    override fun processConversionFromInToOut(inObject: User): DashboardMembers {
        return DashboardMembers(
            inObject.id,
            inObject.name,
            null,
            null
        )
    }

    override fun processConversionFromOutToIn(inObject: DashboardMembers): User {
        val empty = ""
        return User(
            inObject.id,
            empty,
            empty,
            empty,
            inObject.name,
            empty,
            null,
            null
        )
    }

    override fun fromUserToFlowableDashboardMember(): FlowableTransformer<User, DashboardMembers> {
        return FlowableTransformer {
            it.flatMap { inObject ->
                val dashboardMemberModel =
                    DashboardMembers(
                        inObject.id,
                        inObject.name,
                        inObject.avatar_url,
                        null
                    )
                val userGroupsArray = inObject.groups?.toTypedArray()
                groupsRepository.loadGroupList(userGroupsArray!!)
                    .map {
                        val listOfGroupNames = mutableListOf<String>()
                        it.forEach { listOfGroupNames.add(it.groupName) }
                        dashboardMemberModel.inGroups = listOfGroupNames
                        dashboardMemberModel
                    }
            }
        }
    }
}