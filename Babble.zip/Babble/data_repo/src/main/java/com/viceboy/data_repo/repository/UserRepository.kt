package com.viceboy.data_repo.repository

import com.viceboy.data_repo.model.User
import io.reactivex.Flowable
import io.reactivex.Observable

interface UserRepository {
    fun getCurrentUserId(): String
    fun loadUser(userId: String): Flowable<User>
    fun loadGroups(userId: String): Flowable<List<String>>
}