package com.viceboy.data_repo.util

object DataConstants {
    const val KEY_AMOUNT = "amount"
    const val TEXT_YOU_OWE: String = "You owe"
    const val TEXT_YOU_ARE_OWED = "You are owed"
    const val TEXT_LAST_EXPENSE_ADDED = "Last expense added By"
    const val TEXT_LAST_EXPENSE_ADDED_SELF = "Last expense added By You"
}