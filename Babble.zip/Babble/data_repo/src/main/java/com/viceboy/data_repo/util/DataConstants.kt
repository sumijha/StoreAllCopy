package com.viceboy.data_repo.util

object DataConstants {
    const val KEY_AMOUNT = "amount"
}