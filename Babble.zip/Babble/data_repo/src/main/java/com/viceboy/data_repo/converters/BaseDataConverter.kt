package com.viceboy.data_repo.converters

import io.reactivex.FlowableTransformer

interface BaseDataConverter<IN, OUT> {
    fun convertInToOut(inObject: IN): OUT
    fun convertOutToIn(outObject: OUT): IN
    fun convertOutToInFlowableTransformer(outObject: OUT): FlowableTransformer<OUT, IN>
    fun convertInToOutFlowableTransformer(inObject: IN): FlowableTransformer<IN, OUT>
    fun convertListInToOut(inObjects: List<IN>): List<OUT>
    fun convertListOutToIn(outObjects: List<OUT>): List<IN>
}

abstract class BaseDataConverterImpl<IN, OUT> : BaseDataConverter<IN, OUT> {
    override fun convertInToOut(inObject: IN): OUT = processConversionFromInToOut(inObject)

    override fun convertOutToIn(outObject: OUT): IN = processConversionFromOutToIn(outObject)

    override fun convertListInToOut(inObjects: List<IN>): List<OUT> =
        inObjects.map { processConversionFromInToOut(it) }

    override fun convertListOutToIn(outObjects: List<OUT>): List<IN> =
        outObjects.map { processConversionFromOutToIn(it) }

    override fun convertInToOutFlowableTransformer(inObject: IN)  = FlowableTransformer<IN,OUT> {
        it.map { convertInToOut(inObject)}
    }

    override fun convertOutToInFlowableTransformer(outObject: OUT) = FlowableTransformer<OUT,IN> {
        it.map { convertOutToIn(outObject) }
    }

    protected abstract fun processConversionFromInToOut(inObject: IN): OUT

    protected abstract fun processConversionFromOutToIn(inObject: OUT): IN
}