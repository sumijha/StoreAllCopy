package com.viceboy.data_repo.model.uiModel

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
data class DashboardGroup(
    var groupId : String,
    var groupName: String,
    var groupCurrency: String,
    var owedText : String,
    var amountOwedByCurrentUser: Float,
    var lastTransactionBy: String?,
    var lastTransaction: Float?
) : Parcelable