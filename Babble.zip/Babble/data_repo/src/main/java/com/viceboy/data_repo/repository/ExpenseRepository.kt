package com.viceboy.data_repo.repository

import com.viceboy.data_repo.model.Expense
import io.reactivex.Completable
import io.reactivex.Flowable

interface ExpenseRepository {
    fun saveExpense(expense: Expense) : Completable
    fun remove(expense: Expense) : Completable
    fun loadExpenseParticipants(expenseId:String) : Flowable<HashMap<String,Float>>
    fun loadExpenseByGroupId(groupId : String) : Flowable<List<Expense>>
    fun loadLatestExpense(list : Array<Expense>) : Expense?
    fun loadExpense(expenseId:String) : Flowable<Expense>
}