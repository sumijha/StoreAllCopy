package com.viceboy.data_repo.repository

import com.viceboy.data_repo.model.Expense
import io.reactivex.Completable
import io.reactivex.Flowable

interface ExpenseRepository {
    fun saveExpense(expense: Expense) : Completable
    fun remove(expense: Expense) : Completable
    fun loadExpenseParticipants(expenseId:String) : Flowable<HashMap<String,Float>>
    fun loadExpense(expenseId:String) : Flowable<Expense>
}