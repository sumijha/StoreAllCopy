package com.viceboy.data_repo.converters.group

import com.viceboy.data_repo.converters.BaseDataConverterImpl
import com.viceboy.data_repo.model.dataModel.Expense
import com.viceboy.data_repo.model.uiModel.GroupExpenses
import com.viceboy.data_repo.repository.UserRepository
import com.viceboy.data_repo.util.DataUtils
import io.reactivex.Flowable
import io.reactivex.FlowableTransformer
import javax.inject.Inject

interface GroupExpenseBeanConverter {
    fun mapExpenseToGroupByExpense(): FlowableTransformer<Expense, GroupExpenses>
}

class GroupExpenseBeanConverterImpl @Inject constructor() :
    BaseDataConverterImpl<Expense, GroupExpenses>(), GroupExpenseBeanConverter {

    @Inject
    lateinit var userRepository: UserRepository

    private val emptyString = ""

    override fun processConversionFromInToFlowableOut(inObject: Expense): Flowable<GroupExpenses> {
        val groupExpense = processConversionFromInToOut(inObject)
        return userRepository.loadUser(groupExpense.expenseOwner)
            .map {
                groupExpense.expenseOwner = it.name
                groupExpense
            }.flatMap { groupExpenseModel ->
                val mapOfContributors = mutableMapOf<String, Float>()
                userRepository.loadUserList(
                    groupExpenseModel.expensePaidTo.keys.toList().toTypedArray()
                )
                    .flatMapIterable { it }
                    .map { user ->
                        mapOfContributors[user.name] =
                            groupExpenseModel.expensePaidTo[user.id] ?: 0f
                        groupExpense.expensePaidTo = mapOfContributors
                        groupExpense
                    }
            }
    }

    override fun processConversionFromInToOut(inObject: Expense): GroupExpenses {
        return GroupExpenses(
            inObject.id,
            inObject.itemName,
            inObject.expenseImageUrl ?: emptyString,
            inObject.amountPaid,
            inObject.groupId,
            inObject.currency,
            DataUtils.getDateFromMilliSec(inObject.expenseDate),
            inObject.expenseOwner,
            inObject.expenseSharedBy
        )
    }

    override fun mapExpenseToGroupByExpense() = convertInToOutFlowableTransformer()

}