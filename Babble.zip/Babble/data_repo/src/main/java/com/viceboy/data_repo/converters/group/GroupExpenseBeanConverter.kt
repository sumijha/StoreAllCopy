package com.viceboy.data_repo.converters.group

import com.viceboy.data_repo.converters.base.BaseDataConverterImpl
import com.viceboy.data_repo.model.dataModel.Expense
import com.viceboy.data_repo.model.uiModel.GroupExpense
import com.viceboy.data_repo.repository.GroupsRepository
import com.viceboy.data_repo.repository.UserRepository
import com.viceboy.data_repo.util.DataUtils
import io.reactivex.Flowable
import io.reactivex.FlowableTransformer
import javax.inject.Inject

interface GroupExpenseBeanConverter {
    fun mapExpenseToGroupByExpense(): FlowableTransformer<Expense, GroupExpense>
}

class GroupExpenseBeanConverterImpl @Inject constructor() :
    BaseDataConverterImpl<Expense, GroupExpense>(), GroupExpenseBeanConverter {

    @Inject
    lateinit var userRepository: UserRepository

    @Inject
    lateinit var groupsRepository: GroupsRepository

    private val emptyString = ""

    override fun processConversionFromInToFlowableOut(inObject: Expense): Flowable<GroupExpense> {
        val groupExpense = processConversionFromInToOut(inObject)
        val mapOfContributors = groupExpense.expensePaidTo
        return userRepository.loadUser(groupExpense.expenseOwner)
            .map {
                val paidBy =
                    if (userRepository.getCurrentUserId() == it.id) "You" else it.name
                groupExpense.expenseOwner = paidBy
                groupExpense
            }.flatMap { groupExpenseModel ->
                userRepository.loadUserList(
                    groupExpenseModel.expensePaidTo.keys.toList().toTypedArray()
                )
                    .flatMapIterable { it }
                    .map { user ->
                        val name =
                            if (userRepository.getCurrentUserId() == user.id) "You" else user.name
                        mapOfContributors[name] = mapOfContributors[user.id] ?: 0f
                        mapOfContributors.remove(user.id)
                        groupExpense.expensePaidTo = mapOfContributors
                        groupExpense
                    }.flatMap {
                        groupsRepository.loadGroup(it.group)
                            .map {
                                groupExpense.currencySymbol = it.currencySymbol
                                groupExpense
                            }
                    }
            }
    }

    override fun processConversionFromInToOut(inObject: Expense): GroupExpense {
        return GroupExpense(
            inObject.id,
            inObject.itemName,
            inObject.expenseImageUrl ?: emptyString,
            inObject.amountPaid,
            inObject.groupId,
            inObject.currency,
            emptyString,
            DataUtils.getDateFromMilliSec(inObject.expenseDate),
            inObject.expenseOwner,
            inObject.expenseSharedBy
        )
    }

    override fun mapExpenseToGroupByExpense() = convertInToOutFlowableTransformer()

}